<!DOCTYPE html><!--Sorry!!<br><br>No more Exam Sheduled.</br><br> Last Exam Held on:-->
<html lang="en">
<head>
<head>
<title>QuizBattle : CollegeMitra || make them easy...</title>
<?php include "metatag.php"; ?>
<meta name="keywords" content="CollegeMitra.com, virtual, virtual classes, online education, books, online class, onine books, GATE, Engineering notes, class notes, online preparation,virtual learning " />
<?php include "landingtitle.php"; ?>
</head>

<style>
h1, h2 {
    margin: 40px 0px 20px;
    text-align: center;
}
</style>

<body>
<?php include "landingnav.php"; ?>

<!--Common File which include common code to every page-->
<?php include_once("./common.php") ?>
<div class="content-section-a" id="section-1">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-sm-12 center-block">
        <?php
        $qcount = mysqli_query( $qconnect, "SELECT * FROM quiz_exam where asked != '0'" );
        $snum = mysqli_num_rows( $qcount );

        $nexams = date( 'M d, Y', strtotime( 'next saturday' ) );

        if ( $snum ) {
          ?>
        <h1 class="section-heading"> Next examination schedule on <span style="color: crimson"><em><?php echo $nexams ?></em></span> starts <span style="color: crimson"><em>10:00 am</em></span>!!<br>
          <br>
          Last Exam Held on: <span style="color: crimson"><?php echo $datejavascript ; ?></span> <span style="color:green">at</span> <span style="color: crimson"><?php echo $examtime ; ?> </span></br>
          </br>
        </h1>
        <p class="text-center">We will update you soon stay in touch!!</p>
        <?php
        } else {
          ?>
        <h1 class="section-heading"> Sorry!!<br>
          <br>
          Not yet Started.</br>
          <br>
          First examination will be conduct on <span style="color: crimson"><?php echo $nexams ; ?></span>.</br>
          <br>
          We will update you soon stay in touch!! </h1>
        <?php
        }
        ?>
      </div>
    </div>
  </div>
</div>
<div class="content-section-b" id="section-1">
  <?php include "includes/winner_prize.php"; ?>
</div>

<!-- /.container --> 
<!-- Footer -->
<?php include "includes/landingfooter.php"; ?>

- Bootstrap Core JavaScript --> 
ript src="js/bootstrap.min.js"></script>
</body>

