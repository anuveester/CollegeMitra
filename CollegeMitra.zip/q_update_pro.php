<?php
if (!isset($_POST['doSubmit'])) {
    die(header("Location: ./col"));
}
include( 'database/qdb.php' );
include( './includes/ip.php' );
 include('./q_session.php');
error_reporting(0);

$today = date( "Y-m-d" );
$today_num = date( "Ymd" );
$current_time = date( "His" );
$current_day = date( "D" );
$todaytime = "$today_num$current_time";

if (isset($_POST['doSubmit'])){
	$paytm =  $_POST['paytm'];
	$phonepe =  $_POST['phonepe'];
	$googlepay =  $_POST['googlepay'];
	$image =  $_FILES['pics']['name'];

	//Photo Section
	define ("MAX_SIZE","1000"); 
	function getExtension($str)
	{
		 $i = strrpos($str,".");
		 if (!$i) { return ""; }
		 $l = strlen($str) - $i;
		 $ext = substr($str,$i+1,$l);
		 return $ext;
	}

	$errors=0;
	//$image=$_FILES['image']['name'];
	if ($image) 
	{
		$filename = stripslashes($_FILES['pics']['name']);
		$extension = getExtension($filename);
		$extension = strtolower($extension);
		if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") 
			&& ($extension != "gif")&& ($extension != "JPG") && ($extension != "JPEG") 
			&& ($extension != "PNG") && ($extension != "GIF")) 
		{
			$message="<script type='text/javascript'>alert('Unknown extension! ')</script><script language=JavaScript> window.location.href=\"./q_update.php\" </script>";
			$errors=1;
		}
		else
		{
			$size=filesize($_FILES['pics']['tmp_name']);

			if ($size > MAX_SIZE*1024){
				$message="<script type='text/javascript'>alert('You have exceeded the size limit!')</script><script language=JavaScript> window.location.href=\"./q_update.php\" </script>";
				$errors=1;
			}else{

				$image_name=time().'.'.$extension;
				$rand=rand(1000,999999);
				$newname="images/quiz/"."$rand". $image_name;

				$copied = copy($_FILES['pics']['tmp_name'], $newname);
				if (!$copied){
					$message="<script type='text/javascript'>alert('Copy unsuccessfull!')</script><script language=JavaScript> window.location.href=\"./q_update.php\" </script>";
					$errors=1;
				}
				else {
					//$message="<script type='text/javascript'>alert('Uploaded Successfull!')</script>";
					$imgsql=mysqli_query($qconnect,"update quiz_reg set pics='$newname' where id='$fid'");

				//mysql_query("insert into file_tbl (path) values('".$newname."')");
				}
			}
		}
	}
}

echo $message;



if($paytm == ''){
	$paytm='0';
}

if($phonepe == ''){
	$phonepe='0';
	
}

if($googlepay == ''){
	$googlepay='0';	
}


	//fetching data of candidates and getting the records for information 
	$pquery=mysqli_query($qconnect,"SELECT * FROM quiz_reg WHERE id='$fid' AND (paytm !='0' OR phonepe !='0' OR googlepay !='0')");
	$cdecide = mysqli_num_rows($pquery);	

	
	if($cdecide == 0){
		$sql=mysqli_query($qconnect,"update quiz_reg set paytm='$paytm', phonepe='$phonepe', googlepay='$googlepay' where id='$fid'");	 
		 echo "<script type='text/javascript'>alert('Thankyou, Successfully Updated. ')</script><script language=JavaScript> window.location.href=\"./q_exam.php\" </script>";
	 } elseif($imgsql) {
		 echo "<script type='text/javascript'>alert('Successfully Updated. ')</script><script language=JavaScript> window.location.href=\"./q_exam.php\" </script>";
	 }
	 else {
		 echo "<script type='text/javascript'>alert('Cannot Proceed due to some Technical problem. ')</script><script language=JavaScript> window.location.href=\"./q_update.php\" </script>";
	 }
?>