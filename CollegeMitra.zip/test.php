
<?php 
//session_start();
include('./q_session.php');
//ini_set('session.save_path', '/tmp');
//phpinfo();
//echo "path" . session_save_path();
//if (!session_start()) echo "Session not started";
//echo "header session status= " . session_status();
//echo "</br>";
//echo "header session_id= " . session_id();
//

if(isset($_SESSION))
{
echo "session started";
}



?>