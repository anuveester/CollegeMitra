
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->

 <!-- BEGIN HEAD -->
<head>
      <meta charset="UTF-8" />
    <title>CollegeMitra :: error 404 page not found</title>
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
     <meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />
  <!-- GLOBAL STYLES -->
    <link href="css/bootstrap.css" rel="stylesheet" />
    <link href="font-awesome-4.1.0/css/font-awesome.css" rel="stylesheet" />
    <!--END GLOBAL STYLES -->

     <!-- PAGE LEVEL STYLES -->
     <style>
     
/*Author : www.binarytheme.com 2014 
Please Share us if you like our work, it will help us alot*/

body {
  padding-top: 100px;
  
}


.logo h1 {
  color: #000000;
  font-size: 80px;
  padding-bottom:40px;
}

.text-muted {
    color:#000000;
    font-size:25px;
}

/*media queries*/

@media (max-width: 767px){
  .logo h1 {
    font-size: 65px;
  }
}
     </style>
      <!--END PAGE LEVEL STYLES -->
</head>
     <!-- END HEAD -->
     <!-- BEGIN BODY -->
<body  >
      <!-- PAGE CONTENT --> 
  <div class="container">
        <div class="col-lg-8 col-lg-offset-2 text-center">
	  <div class="logo">
	    <h1>Opps, Error <span class="text-danger">404</span> !</h1>
          </div>
            <div class="clearfix"></div>
            
          <p class="text-muted">There is some error here, Please try later. </p>
          <div class="clearfix"></div>
            <br />
                <div class="col-lg-6  col-lg-offset-3">
		  <div class="btn-group btn-group-justified">
		      <a href="col" class="btn btn-primary">Return Dashboard</a>
                      <a href="col" class="btn btn-success">Return Website</a> 
		  </div>
                        
                </div>
            
        </div>
                
                
        </div>
      <!-- END PAGE CONTENT --> 

</body>
     <!-- END BODY -->
</html>
