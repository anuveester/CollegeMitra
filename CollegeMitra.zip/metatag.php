    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="google-site-verification" content="DNo0e3VHyelCo4SetA0AGK1XAPADrldsxWAJ8AlXIMM" />
    <meta name="viewport" content="width=device-width", initial-scale="1">
    
    <meta name="alexaVerifyID" content="4X9U3qhC5Y_8ss46ni6fJJoJy-4" />
    <meta name="msvalidate.01" content="E4BB340BC13B55DDF10BBA22BE0CDE9D" />
    <meta name="robots" content="index, follow">
    <meta name="p:domain_verify" content="c4e32c88d1d1415a35c6bd3e71f34b2e"/>
    
    <meta name="author" content="CollegeMitra">
    <link rel="alternate" href="www.collegemitra.com" hreflang="en-in" />


