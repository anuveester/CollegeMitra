<?php
 include('database/qdb.php');
 include('./includes/ip.php');
$today=date("Y-m-d");
$today_num=date("Ymd");
$current_time = date("His"); 
$current_day = date("D"); 
$todaytime="$today_num$current_time"; 

$qset = mysql_query("SELECT * FROM quiz_score ORDER BY paperset ASC");
while($_GET=mysql_fetch_array($qset))
{
	$nexam=$_GET['exam_date'];
	$resultdate = date('Y-m-d', strtotime("$nexam +1 day") );
	$edate = date( 'l jS \of F Y', strtotime( "$nexam" ) );
	$pset=$_GET['paperset'];
}


if($resultdate >= $today){
	$pset=$pset-1;
	if ($pset == 0){
		$pset=1;
	}
}
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <head><title>QuizBattle : CollegeMitra || make them easy...</title>
<?php include "metatag.php"; ?>
<meta name="keywords" content="CollegeMitra.com, virtual, virtual classes, online education, books, online class, onine books, GATE, Engineering notes, class notes, online preparation,virtual learning " />
<?php include "landingtitle.php"; ?>
</head><body>
<?php include "landingnav.php"; ?>
<style>
	.prize1{
		margin-top: 10px;
		padding-top: 10px;
	}
	.prize1 img{
		width: auto;
		height: 300px;
	}
	.prize2{
		margin-top: 10px;
		padding-top: 38px;
	}
	.prize2 img{
		width: auto;
		height: 300px;
	}
	.prize3{
		margin-top: 10px;
		padding-top: 51px;
	}
	.prize3 img{
		width: auto;
		height: 300px;
	}
</style>

<!--Common File which include common code to every page-->
<?php include_once("./common.php") ?>
<div class="content-section-b" id="section-1">
  <div class="container"><br>
            
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 text-center">
              <h1><strong>!! Congratulations Winners !!</strong></h1>
              <h2><strong> Quiz taken Date: <?php echo $edate ?> </strong></h2>
            </div>
            <?php
				
				$q1 = mysql_query("SELECT 
								t1.id as id,
								t2.name,
								t1.rank,
								t2.pics
							from 
								quiz_score t1
								INNER JOIN quiz_reg t2
								ON t1.userid = t2.id
								
							WHERE t1.paperset = '$pset' AND t1.userid != '1' AND t1.userid != '7'
							ORDER BY t1.rank ASC LIMIT 0,2");
				while($_GET=mysql_fetch_array($q1))
				{
					$cname=$_GET['name'];	
					$pics = $_GET['pics'];
				}
			?>
            <div class=" col-lg-4 col-md-4 col-sm-4 text-center text-warning"> 
             <div class="prize2">
              <p class=""><i class="fa fa-trophy fa-3x" aria-hidden="true"></i> 2<sup>nd</sup> Prize</p>
              <p><?php echo "$cname";?></p><br><img src="<?php echo $pics ?>" class="logo" alt="CollegeMitra">
              </div>
            </div>
            <?php
				
				$q1 = mysql_query("SELECT 
								t1.id as id,
								t2.name,
								t1.rank,
								t2.pics
							from 
								quiz_score t1
								INNER JOIN quiz_reg t2
								ON t1.userid = t2.id
								
							WHERE t1.paperset = '$pset' AND t1.userid != '1' AND t1.userid != '7'
							ORDER BY t1.rank DESC");
				while($_GET=mysql_fetch_array($q1))
				{
					$cname=$_GET['name'];	
					$pics = $_GET['pics'];
				}
			?>
            <div class="col-lg-4 col-md-4 col-sm-4 text-center text-success"> 
             <div class="prize1">
              <p class=""><i class="fa fa-trophy fa-5x" aria-hidden="true"></i> 1<sup>st</sup> Prize</p>
              <p><?php echo $cname ?></p><br><img src="<?php echo $pics ?>" class="logo" alt="CollegeMitra">
             </div>
            </div>
            <?php
				
				$q1 = mysql_query("SELECT 
								t1.id as id,
								t2.name,
								t1.rank,
								t2.pics
							from 
								quiz_score t1
								INNER JOIN quiz_reg t2
								ON t1.userid = t2.id
								
							WHERE t1.paperset = '$pset' AND t1.userid != '1' AND t1.userid != '7'
							ORDER BY t1.rank ASC LIMIT 0,3");
				while($_GET=mysql_fetch_array($q1))
				{
					$cname=$_GET['name'];	
					$pics = $_GET['pics'];
				}
			?>
            <div class="col-lg-4 col-md-4 col-sm-4 text-center text-danger"> 
             <div class="prize3">
              <p><i class="fa fa-trophy fa-2x" aria-hidden="true"></i> 3<sup>rd</sup> Prize</p>
              <p><?php echo $cname ?></p><br><img src="<?php echo $pics ?>" class="logo" alt="CollegeMitra">
             </div>
            </div>
          </div>
  </div>
</div>


<!-- /.Registration -->
<div class="content-section-a" id="section-1">
       <div class="container">
      <h2 style="text-align: center; color: darkblue;">QuestionBattle Schedule</h2>
      <h3 style="text-align: center;">Every <span style="color:orangered">Saturday</span> Start from <span style="color: red"><u>10:00 AM</span></u>  to  <span style="color: red"><u>10:00 PM</u></span></h3>
      <h3 style="text-align: center;"><img src="images/point.png" width="50px" height="auto" alt="cm"> You are NEXT, login now <img src="images/point.png" width="50px" height="auto" alt="cm"></h3> <hr>
			<div class="row">
				
				<div class="col-lg-5 col-sm-5 col-xs-offset-1">
					<div class="fb-like" data-href="https://www.facebook.com/collegemitra/" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>
					<div class=" panel panel-info">
						<div class="panel-heading"><i class="fa fa-pencil-square-o"></i> Let's enter QuizBattle (If Already Registered)</div>
							<form class="form-horizontal col-xs-offset-1" name="form1"  id="defaultForm" method="post" action="q_login.php" role="form"  onsubmit="return validate1();">
							   <div class="form-group"></div>
                        <div class="form-group">
                            <label for="email" class="col-sm-2 control-label" role="navigation">Email</label>
                            <div class="col-sm-8">
                            <input type="email" class="form-control" title="Email" name="qemail" data-container="body" data-toggle="popover" data-placement="top" data-content="If not register then register first."  id="qemail" placeholder="Enter email" value="" autocomplete="off">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-5 col-sm-5 col-xs-offset-5">
                               <button type="submit" class="form-control btn btn-success" name="qenter" id="qenter" >Take Quiz</button>
                            </div>
                        </div>
                			</form>
					</div>
				</div>
				<div class="col-lg-5 col-sm-5">
					<div class="fb-like" data-href="https://www.facebook.com/collegemitra/" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>
					<div class=" panel panel-info">
						<div class="panel-heading"><i class="fa fa-pencil-square-o"></i> Create an account for take Quiz (Only for Quiz)</div>
						
							<form class="form-horizontal col-xs-offset-1" name="form1"  id="defaultForm" method="post" action="quizb_signup.php" role="form"  onsubmit="return quizreg();">
								<input type="hidden" name="ip" value="<?php echo $user_ip ?>" />
								<input type="hidden" name="currentdatetime" value="<?php echo $currentdatetime ?>" />
							   <div class="form-group"></div>
									<div class="form-group">
										<label for="fname" class="col-sm-2 control-label" role="navigation">Name</label>
										<div class="col-sm-4">
										   <input type="text" class="form-control"  id="fname" name="fname" placeholder="First Name" value="">
										</div>
										<div class="col-sm-4">
										   <input type="text" class="form-control"  id="lname" name="lname" placeholder="Last Name">
										</div>
									</div>
									<div class="form-group">
										<label for="email" class="col-sm-2 control-label" role="navigation">Email</label>
										<div class="col-sm-8">
										<input type="email" class="form-control" title="Email" name="email" data-container="body" data-toggle="popover" data-placement="top" data-content="Activation email goes same email ID which you enter, Please enter carefully" value=""  id="email" placeholder="Enter email" autocomplete="off">
									<span class="email_result" id="email_result"></span>
										</div>
									</div>
									<div class="form-group">
										<label for="email" class="col-sm-2 control-label" role="navigation">Mobile</label>
										<div class="col-sm-8">
                        					<input type="text" class="form-control"  id="mob" name="mob" placeholder=" contact number" value="" maxlength="10" autocomplete="off">
											<span class="mob_result" id="mob_result"></span>
										</div>
									</div>
									<div class="form-group">
										<label for="contact-gender" class="col-sm-2 control-label" role="navigation">Gender</label>
										<div class="col-sm-3">
											<label>
												<input type="radio" id="contact-gender" checked name="gen" value="male"> Male


											</label>
										</div>
										<div class="col-sm-3">
											<label>
												<input type="radio" id="contact-gender" name="gen" value="female"> Female
											</label>
										</div>
									</div>
									<div class="form-group">
										<label for="contact-course" class="col-sm-2 control-label" role="navigation">Type</label>
										<div class="col-sm-8">
										   <select class="form-control" id="careertype" name="careertype">
												<option value="1" disabled selected>What are you?</option>  
												<option value="Student">Student</option>                       
												<option value="Preparation">Preparation</option>                      
												<option value="Employee">Employee</option>                           
												<option value="Non Working">Non Working</option>  
											</select>
										</div>
									</div>
									<div class="form-group">
										<div class="col-sm-8 col-sm-offset-2">
											<div class="checkbox">
												<label>
												<input type="checkbox" value="1" name="disclaimer" id="disclaimer"/><a href="tnc" target="_blank">I accept terms and conditions</a>
												</label>
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="col-md-5 col-sm-5  col-xs-offset-5">
										   <button type="submit" class="form-control btn btn-danger" name="doSubmit" id="doSubmit" >Register</button>
										</div>
									</div>
							</form>
					</div>
				</div>
			</div>
	  </div>
  </div>
<!-- /.Registration -->
<div class="content-section-b" id="section-1">
	<?php include "includes/winner_list.php"; ?>
  </div>
<!-- /.Registration -->
<div class="content-section-a" id="section-1">
       <div class="container">
    <div class="row">
      <div class="col-lg-10  col-sm-12 col-xs-offset-1">
        <h2 class="section-heading">Quiz Instructions -</h2>
        <ol>
        	<li>Make sure you have a good internet connection.<br><br></li>
        	<li>Shut down all Instant Messaging tools (Skype, AIM, MSN Messenger) and Email programs as they can conflict in between your test.<br><br></li>
        	<li>Please don't click the “Back” button on the browser. This will take you out of the test and you may not able to start the same test again.<br><br></li>
        	<li>There are <strong>Only 10 questions</strong>.<br><br></li>
        	<li>You will have max 20 minutes to complete your test.<br><br></li>
        	<li>You can attempt the test only once if you want to take more quiz then you have to wait for next exam.<br><br></li>
        	<li>If by chance, you are not able to complete your test, your test will be submitted automatically and you cannot take the same test again.<br><br></li>
        	<li>You need to login through your email ID, fill in your credentials if you are a registered user or create a new account to start the test.<br><br></li>
        </ol>    
    </div>
    </div>
    <div class="row">
      <div class="col-lg-10  col-sm-12 col-xs-offset-1">
        <h2 class="section-heading">Benefits -</h2>
        <ol>
        	<li>On the basis of your quiz test score and minimum duration.<br><br></li>
        	<li>If your rank will vary between 1 ~ 20 then your will sure get the Paytm Balance.<br><br></li>
        </ol>
	  </div>
	  </div>
	  </div>
  </div>

<div class="content-section-b" id="section-1">
	<?php include "includes/winner_prize.php"; ?>
</div>

<!-- /.container --> 
<!-- Footer -->
<?php include "includes/landingfooter.php"; ?>

<!-- Login Popup -->
<?php include "landingsigninpopup.php"; ?>

<!-- jQuery Version 1.11.0 --> 
<script src="js/jquery-1.11.0.js"></script> 

<!-- Bootstrap Core JavaScript --> 
<script src="js/bootstrap.min.js"></script> 
<script>$(function () 
      { $("[data-toggle='popover']").popover();
      });
   </script>
   
   

<!--Quiz Registration-->
<script>

function quizreg()
{

	$('#mob').on('input', function (event) { 
		this.value = this.value.replace(/[^0-9]/g, '');
	});		

	if(document.getElementById('fname').value=="")
	{
	alert("Please Enter your First Name");	
	document.getElementById('fname').focus();	  
	return false;
	}	

	if(document.getElementById('email').value=="")
	{
	alert("Please Enter your Email ID.");	
	document.getElementById('email').focus();	  
	return false;
	}
	

	if (document.getElementById('mob').value == "")
	{ 
	alert("Please Enter Mobile Number.\n")
	document.getElementById('mob').focus();
	return false;	
	}
	

	if (document.getElementById('careertype').value == "1")
	{ 
	alert("Please Select your Career type.\n")
	document.getElementById('careertype').focus();
	return false;	
	}

	if(document.getElementById('disclaimer').checked)
	{
		var i = confirm("Are you sure ? \n\n");

		if(i){
			return true;
		}else{
			return false;
		}

		return true;
	}
	else{
		alert('Please Read Terms & Conditions.');
		return false;
	}
}
</script>
	
</body>
</html>
