/* username and password*/
$(document).ready(function () {

	$('#email').keyup(function () { // Keyup function for check the user action in input
		var Email = $(this).val(); // Get the username textbox using $(this) or you can use directly $('#username')
		var UsernameAvailResult = $('#email_result'); // Get the ID of the result where we gonna display the results
		if (Email.length > 10) { // check if greater than 2 (minimum 3)
			var UrlToPass = 'action=username_availability&email=' + Email;
			$.ajax({ // Send the username val to another checker.php using Ajax in POST method
				type: 'POST',
				data: UrlToPass,
				url: 'checkeremail_quiz.php',
				success: function (responseText) { // Get the result and asign to each cases
					if (Email.length >= 100) {
						UsernameAvailResult.html('<span class="text-danger">Please Enter correct e-mail ID.</span>');
						document.getElementById("doSubmit").disabled = true;
					} else if (responseText == 0) {
						UsernameAvailResult.html('<span class="text-success">Congratulation you can use this Email address</span>');
						document.getElementById("doSubmit").disabled = false;
					} else if (responseText > 0) {
						UsernameAvailResult.html('<span class="text-danger">This email already registered with us...</span>');
						document.getElementById("doSubmit").disabled = true;
					} else {
						alert('Problem with sql query');
					}
				}
			});
		} else {
			UsernameAvailResult.html('<span class="text-warning">Activation mail goes on this Email...</span>');
			document.getElementById("doSubmit").disabled = true;
		}
		if (Email.length == 0) {
			UsernameAvailResult.html('');
			UsernameAvailResult1.html('');
			document.getElementById("doSubmit").disabled = true;
		}

	});

	$('#uname').keyup(function () { // Keyup function for check the user action in input
		var Username = $(this).val(); // Get the username textbox using $(this) or you can use directly $('#username')
		var UsernameAvailResult = $('#username_avail_result'); // Get the ID of the result where we gonna display the results

		if (Username.length > 3) { // check if greater than 2 (minimum 3)
			var UrlToPass = 'action=username_availability&uname=' + Username;
			$.ajax({ // Send the username val to another checker.php using Ajax in POST method
				type: 'POST',
				data: UrlToPass,
				url: 'checkerusername.php',
				success: function (responseText) { // Get the result and asign to each cases
					if (Username.length >= 20) {
						UsernameAvailResult.html('<span class="text-danger">Username should not exceed 20 character.</span>');
						document.getElementById("doSubmit").disabled = true;
					} else if (responseText == 0) {
						UsernameAvailResult.html('<span class="text-success">Congratulation username Available</span>');
						document.getElementById("doSubmit").disabled = false;
					} else if (responseText > 0) {
						UsernameAvailResult.html('<span class="text-danger">Username already taken</span>');
						document.getElementById("doSubmit").disabled = true;
					} else {
						alert('Problem with sql query');
					}
				}
			});
		} else {
			UsernameAvailResult.html('<span class="text-warning">Enter atleast 4 characters</span>');
			document.getElementById("doSubmit").disabled = true;
		}
		if (Username.length == 0) {
			UsernameAvailResult.html('');
			UsernameAvailResult1.html('');
			document.getElementById("doSubmit").disabled = true;
		}

	});


	$('#pwd, #uname, #email, #mob').keydown(function (e) { // Dont allow users to enter spaces for their username and passwords
		if (e.which == 32) {
			return false;
		}
	});
	$('#pwd').keyup(function () { // As same using keyup function for get user action in input
		var PasswordLength = $(this).val().length; // Get the password input using $(this)
		var PasswordStrength = $('#password_strength'); // Get the id of the password indicator display area
		if (PasswordLength <= 0) { // Check is less than 0
			PasswordStrength.html(''); // Empty the HTML
			PasswordStrength.removeClass('bg-warning bg-danger bg-info bg-success'); //Remove all the indicator classes
		}
		if (PasswordLength > 0 && PasswordLength < 4) { // If string length less than 4 add 'bg-warning' class
			PasswordStrength.html('Weak');
			PasswordStrength.removeClass('bg-warning bg-info bg-success').addClass('bg-danger');
			document.getElementById("doSubmit").disabled = true;
		}
		if (PasswordLength > 4 && PasswordLength < 8) { // If string length greater than 4 and less than 8 add 'normal' class
			PasswordStrength.html('Normal');
			PasswordStrength.removeClass('bg-danger bg-info bg-success').addClass('bg-warning');
			document.getElementById("doSubmit").disabled = false;
		}
		if (PasswordLength >= 8 && PasswordLength < 12) { // If string length greater than 8 and less than 12 add 'strong' class
			PasswordStrength.html('Strong');
			PasswordStrength.removeClass('bg-danger bg-warning bg-success').addClass('bg-info');
			document.getElementById("doSubmit").disabled = false;
		}
		if (PasswordLength >= 12) { // If string length greater than 12 add 'bg-success' class
			PasswordStrength.html('Very Strong');
			PasswordStrength.removeClass('bg-danger bg-warning bg-info').addClass('bg-success');
			document.getElementById("doSubmit").disabled = false;
		}
	});
});
/* username and password*/

/* Quiz Section*/
$(document).ready(function () {
	/* Quiz Email*/
	$('#email').keyup(function () { // Keyup function for check the user action in input
		var Email = $(this).val(); // Get the username textbox using $(this) or you can use directly $('#username')
		var UsernameAvailResult = $('#email_result'); // Get the ID of the result where we gonna display the results
		if (Email.length > 10) { // check if greater than 2 (minimum 3)
			var UrlToPass = 'action=username_availability&email=' + Email;
			$.ajax({ // Send the username val to another checker.php using Ajax in POST method
				type: 'POST',
				data: UrlToPass,
				url: 'checkeremail_quiz.php',
				success: function (responseText) { // Get the result and asign to each cases
					if (Email.length >= 100) {
						UsernameAvailResult.html('<span class="text-danger">Please Enter correct e-mail ID.</span>');
						document.getElementById("doSubmit").disabled = true;
					} else if (responseText == 0) {
						UsernameAvailResult.html('<span class="text-success">Congratulation you can use this Email address</span>');
						document.getElementById("doSubmit").disabled = false;
					} else if (responseText > 0) {
						UsernameAvailResult.html('<span class="text-danger">This email already registered with us...</span>');
						document.getElementById("doSubmit").disabled = true;
					} else {
						alert('Problem with sql query');
					}
				}
			});
		} else {
			UsernameAvailResult.html('<span class="text-warning">Activation mail goes on this Email...</span>');
			document.getElementById("doSubmit").disabled = true;
		}
		if (Email.length == 0) {
			UsernameAvailResult.html('');
			UsernameAvailResult1.html('');
			document.getElementById("doSubmit").disabled = true;
		}

	});


	/* Quiz Contact*/
	$('#mob').keyup(function () { // Keyup function for check the user action in input
		var mob = $(this).val(); // Get the username textbox using $(this) or you can use directly $('#username')
		var UsernameAvailResult = $('#mob_result'); // Get the ID of the result where we gonna display the results
		if (mob.length > 9) { // check if greater than 2 (minimum 3)
			var UrlToPass = 'action=username_availability&mob=' + mob;
			$.ajax({ // Send the username val to another checker.php using Ajax in POST method
				type: 'POST',
				data: UrlToPass,
				url: 'checkeremob_quiz.php',
				success: function (responseText) { // Get the result and asign to each cases
					
					if (mob.length >= 11) {
						UsernameAvailResult.html('<span class="text-danger">Please Enter correct Mobile Number.</span>');
						document.getElementById("doSubmit").disabled = true;
					} else if (responseText == 0) {
						UsernameAvailResult.html('<span class="text-success">Congratulation you can use this Mobile Number</span>');
						document.getElementById("doSubmit").disabled = false;
					} else if (responseText > 0) {
						UsernameAvailResult.html('<span class="text-danger">This Mobile Number already registered with us...</span>');
						document.getElementById("doSubmit").disabled = true;
					} else {
						alert('Problem with sql query');
					}
				}
			});
		} else {
			UsernameAvailResult.html('<span class="text-warning">Scholar Money will go through this Paytm Number</span>');
			document.getElementById("doSubmit").disabled = true;
		}
		if (mob.length == 0) {
			UsernameAvailResult.html('');
			UsernameAvailResult1.html('');
			document.getElementById("doSubmit").disabled = true;
		}

	});
});


/* Login Error*/
function validate() {
	if (document.login_form.login_email.value == "") {
		alert("Please enter username  or Email ID.");
		document.login_form.login_email.focus();
		return false;
	} else if (document.login_form.login_password.value == "") {
		alert("Please enter password");
		document.login_form.login_password.focus();
		return false;
	} else
		return true;
}
/* Login Error*/

/* Registration form conditions */
function validate1() {
	if (document.form1.fname.value == "") {
		alert("Required First name");
		document.form1.fname.focus();
		return false;
	}

	if (document.form1.email.value == "") {
		alert("Please enter email ID ");
		document.form1.email.focus();
		return false;
	}

	if (document.form1.email.value == "") {
		alert("Please enter email ID .");
		document.form1.email.focus();
		return false;
	} else if (!((document.form1.email.value.indexOf(".") > 0) &&
			(document.form1.email.value.indexOf("@") > 0)) ||
		/[^a-zA-Z0-9.@_-]/.test(document.form1.email.value)) {
		alert("Email ID Invalid");
		document.form1.email.focus();
		return false;
	}

	if (document.form1.uname.value == "") {
		alert('Please Choose your Username');
		document.form1.uname.focus();
		return false;
	}

	if (document.form1.pwd.value == "") {
		alert('Please input Password');
		document.form1.pwd.focus();
		return false;
	}

	if (document.form1.cpwd.value == "") {
		alert('Please input Confirm Password');
		document.form1.cpwd.focus();
		return false;
	}

	if (document.form1.pwd.value != document.form1.cpwd.value) {
		alert('Confirm Password Not Match');
		document.form1.cpwd.focus();
		return false;
	}


	if (document.form1.careertype.value == "1") {
		alert("Please select your career type");
		document.form1.careertype.focus();
		return false;
	}

	if (document.getElementById('tnc').checked) {
		var i = confirm("Are you sure ? \n\nWe will send activation mail at your Email-ID. \n\nPlease check your Inbox or Spam folder.");

		if (i) {
			return true;
		} else {
			return false;
		}

		return true;
	} else {
		alert('Please Read Terms & Condition then proceed.');
		return false;
	}
}
/*form conditions*/

/* Registration form Update conditions */
function validate2() {
	if (document.getElementById('careertype').value == "") {
		alert("Please select your career type");
		document.getElementById('careertype').focus();
		return false;
	}


	if (document.getElementById('course').value == "") {
		alert("Please Select Course..");
		document.getElementById('course').focus();
		return false;
	}

	if (document.getElementById('course').value == "1" && document.getElementById('othercourses').value == "") {
		alert("Please Specify Course..");
		document.getElementById('othercourses').focus();
		return false;
	}

	if (document.getElementById('college').value == "") {
		alert("Please Select College Name...");
		document.getElementById('college').focus();
		return false;
	}

	if (document.getElementById('college').value == "1" && document.getElementById('othercolleges').value == "") {
		alert("Please Specify College Name...");
		document.getElementById('othercolleges').focus();
		return false;
	}

	if (document.getElementById('branch').value == "") {
		alert("Please Select Branch...");
		document.getElementById('branch').focus();
		return false;
	}

	if (document.getElementById('branch').value == "1" && document.getElementById('otherbranchs').value == "") {
		alert("Please Specify Branch...");
		document.getElementById('otherbranchs').focus();
		return false;
	}

	if (document.form2.date.value == "") {
		alert("Please select date");
		document.form2.date.focus();
		return false;
	}

	if (document.form2.month.value == "") {
		alert("Please select month");
		document.form2.month.focus();
		return false;
	}

	if (document.form2.year.value == "") {
		alert("Please select year");
		document.form2.year.focus();
		return false;
	}

	if (document.form2.mob.value == "") {
		alert("Please Enter Mobile Number.\n")
		document.form2.mob.focus();
		return false;
	} else if (/[a-z]/.test(document.form2.mob.value) || /[A-Z]/.test(document.form2.mob.value)) {
		alert("Alphabets are not allowed.\n")
		document.form2.mob.focus();
		return false;
	} else if (document.form2.mob.value.length !== 10) {
		alert("Entered mobile number should be in 10 digit.\n")
		document.form2.mob.focus();
		return false;
	}
}
/*form conditions*/

/* Registration form Update conditions */
function validate4() {
	if (document.getElementById('careertype').value == "") {
		alert("Please select your career type");
		document.getElementById('careertype').focus();
		return false;
	}

	if (document.getElementById('completedcourse').value == "") {
		alert("Please Select Course..");
		document.getElementById('completedcourse').focus();
		return false;
	}

	if (document.getElementById('completedcourse').value == "1" && document.getElementById('othercompletedcourse').value == "") {
		alert("Please Specify course..");
		document.getElementById('othercompletedcourse').focus();
		return false;
	}

	if (document.getElementById('preparing').value == "") {
		alert("Please Select competitive exam...");
		document.getElementById('preparing').focus();
		return false;
	}

	if (document.getElementById('preparing').value == "1" && document.getElementById('otherpreparation').value == "") {
		alert("Please define competitive exam Name...");
		document.getElementById('otherpreparation').focus();
		return false;
	}

	if (document.getElementById('date').value == "") {
		alert("Please select date");
		document.getElementById('date').focus();
		return false;
	}

	if (document.getElementById('month').value == "") {
		alert("Please select month");
		document.getElementById('month').focus();
		return false;
	}

	if (document.getElementById('year').value == "") {
		alert("Please select year");
		document.getElementById('year').focus();
		return false;
	}

	if (document.getElementById('mob').value == "") {
		alert("Please Enter Mobile Number.\n")
		document.getElementById('mob').focus();
		return false;
	} else if (/[a-z]/.test(document.getElementById('mob').value) || /[A-Z]/.test(document.getElementById('mob').value)) {
		alert("Alphabets are not allowed.\n")
		document.getElementById('mob').focus();
		return false;
	} else if (document.getElementById('mob').value.length !== 10) {
		alert("Entered mobile number should be in 10 digit.\n")
		document.getElementById('mob').focus();
		return false;
	}

	if (document.getElementById('lukindustry').value == "") {
		alert("Please tell your desire industries");
		document.getElementById('lukindustry').focus();
		return false;
	}

	if (document.getElementById('lukindustry').value == "1" && document.getElementById('otherlukindustry').value == "") {
		alert("Please define competitive exam Name...");
		document.getElementById('otherlukindustry').focus();
		return false;
	}
}
/*form conditions*/

/* Registration form Update conditions */
function validate5() {
	if (document.getElementById('careertype').value == "") {
		alert("Please select your career type");
		document.getElementById('careertype').focus();
		return false;
	}

	if (document.getElementById('course').value == "") {
		alert("Please Select Course..");
		document.getElementById('course').focus();
		return false;
	}

	if (document.getElementById('course').value == "1" && document.getElementById('othercourses').value == "") {
		alert("Please Specify Course..");
		document.getElementById('othercourses').focus();
		return false;
	}

	if (document.getElementById('college').value == "") {
		alert("Please Select College Name...");
		document.getElementById('college').focus();
		return false;
	}

	if (document.getElementById('college').value == "1" && document.getElementById('othercolleges').value == "") {
		alert("Please Specify College Name...");
		document.getElementById('othercolleges').focus();
		return false;
	}

	if (document.getElementById('othercolleges').value.length >= 6) {
		alert("Entered College name atleast 6 Character.\n")
		document.getElementById('othercolleges').focus();
		return false;
	}

	if (document.getElementById('branch').value == "") {
		alert("Please Select Branch...");
		document.getElementById('branch').focus();
		return false;
	}

	if (document.getElementById('branch').value == "1" && document.getElementById('otherbranchs').value == "") {
		alert("Please Specify Branch...");
		document.getElementById('otherbranchs').focus();
		return false;
	}

	if (document.form2.date.value == "") {
		alert("Please select date");
		document.form2.date.focus();
		return false;
	}

	if (document.form2.month.value == "") {
		alert("Please select month");
		document.form2.month.focus();
		return false;
	}

	if (document.form2.year.value == "") {
		alert("Please select year");
		document.form2.year.focus();
		return false;
	}

	if (document.form2.mob.value == "") {
		alert("Please Enter Mobile Number.\n")
		document.form2.mob.focus();
		return false;
	} else if (/[a-z]/.test(document.form2.mob.value) || /[A-Z]/.test(document.form2.mob.value)) {
		alert("Alphabets are not allowed.\n")
		document.form2.mob.focus();
		return false;
	} else if (document.form2.mob.value.length !== 10) {
		alert("Entered mobile number should be in 10 digit.\n")
		document.form2.mob.focus();
		return false;
	}

	if (document.form2.yop.value == "") {
		alert("Please select year when you Complete Your Degree...");
		document.form2.yop.focus();
		return false;
	}

	if (document.form2.yop.value == "") {
		alert("Please select year when you Complete Your Degree...");
		document.form2.yop.focus();
		return false;
	}

	if (document.form2.CompanyName.value == "") {
		alert("Please enter your Company Name..");
		document.form2.CompanyName.focus();
		return false;
	}

	if (document.form2.desig.value == "") {
		alert("Please enter Designation..");
		document.form2.desig.focus();
		return false;
	}

	if (document.form2.specialization.value == "") {
		alert("Please enter Specialization..");
		document.form2.specialization.focus();
		return false;
	}

	if (document.form2.specialization.length < "4") {
		specialization.html('Enter atleast 4 characters');
		document.getElementById("doSubmit").disabled = true;
	}
}
/*form conditions*/
/* Registration form Update conditions */
function validate6() {
	if (document.getElementById('careertype').value == "") {
		alert("Please select your career type");
		document.getElementById('careertype').focus();
		return false;
	}

	if (document.getElementById('course').value == "") {
		alert("Please Select Course..");
		document.getElementById('course').focus();
		return false;
	}

	if (document.getElementById('course').value == "1" && document.getElementById('othercourses').value == "") {
		alert("Please Specify Course..");
		document.getElementById('othercourses').focus();
		return false;
	}

	if (document.getElementById('college').value == "") {
		alert("Please Select College Name...");
		document.getElementById('college').focus();
		return false;
	}

	if (document.getElementById('college').value == "1" && document.getElementById('othercolleges').value == "") {
		alert("Please Specify College Name...");
		document.getElementById('othercolleges').focus();
		return false;
	}

	if (document.getElementById('branch').value == "") {
		alert("Please Select Branch...");
		document.getElementById('branch').focus();
		return false;
	}

	if (document.getElementById('branch').value == "1" && document.getElementById('otherbranchs').value == "") {
		alert("Please Specify Branch...");
		document.getElementById('otherbranchs').focus();
		return false;
	}

	if (document.form2.date.value == "") {
		alert("Please select date");
		document.form2.date.focus();
		return false;
	}

	if (document.form2.month.value == "") {
		alert("Please select month");
		document.form2.month.focus();
		return false;
	}

	if (document.form2.year.value == "") {
		alert("Please select year");
		document.form2.year.focus();
		return false;
	}

	if (document.form2.mob.value == "") {
		alert("Please Enter Mobile Number.\n")
		document.form2.mob.focus();
		return false;
	} else if (/[a-z]/.test(document.form2.mob.value) || /[A-Z]/.test(document.form2.mob.value)) {
		alert("Alphabets are not allowed.\n")
		document.form2.mob.focus();
		return false;
	} else if (document.form2.mob.value.length !== 10) {
		alert("Entered mobile number should be in 10 digit.\n")
		document.form2.mob.focus();
		return false;
	}
}
/*form conditions*/

/* Registration form Update conditions */
function validate3() {
	if (document.getElementById('careertype1').value == "") {
		alert("Please select your career type");
		document.getElementById('careertype1').focus();
		return false;
	}

}
/*form conditions*/

/* course option show and hide*/
function courses(val) {
	if (val == "1") $('#othercourse').show("");
	else $('#othercourse').hide("");
	return false;
}
/* course option show and hide*/
/* Branch option show and hide*/
function colleges(val) {
	if (val == "1") $('#othercollege').show("");
	else $('#othercollege').hide("");
	return false;
}
/* Branch option show and hide*/
/* College option show and hide*/
function branchs(val) {
	if (val == "1") $('#otherbranch').show("");
	else $('#otherbranch').hide("");
	return false;
}
/* College option show and hide*/


/* Looking industries option show and hide*/
function lukindustries(val) {
	if (val == "1") $('#otherlukindustries').show("");
	else $('#otherlukindustries').hide("");
	return false;
}
/* Looking industries option show and hide*/

/* Registration form Update conditions */
function testimonial() {
	if (document.getElementById('fname').value == "") {
		alert("Please enter your name");
		document.getElementById('fname').focus();
		return false;
	}

	if (document.form1.email1.value == "") {
		alert("Please enter email ID ");
		document.form1.email1.focus();
		return false;
	}

	if (document.form1.email1.value == "") {
		alert("Please enter email ID .");
		document.form1.email1.focus();
		return false;
	} else if (!((document.form1.email1.value.indexOf(".") > 0) &&
			(document.form1.email1.value.indexOf("@") > 0)) ||
		/[^a-zA-Z0-9.@_-]/.test(document.form1.email1.value)) {
		alert("Email ID Invalid");
		document.form1.email1.focus();
		return false;
	}

	if (document.getElementById('testimsg').value == "") {
		alert("Don't forget to write testimonial section");
		document.getElementById('testimsg').focus();
		return false;
	}

	if (document.getElementById('pics').value == "") {
		alert("You didn't select any pics please select it...");
		document.getElementById('pics').focus();
		return false;
	}

}
/*form conditions*/

/*Coontact Us Validation starts*/
function contactus() {
	if (document.getElementById('name').value == "") {
		alert("Please enter your name");
		document.getElementById('name').focus();
		return false;
	}

	if (document.getElementById('phone').value == "") {
		alert("Please Enter Contact Number.\n")
		document.getElementById('phone').focus();
		return false;
	} else if (/[a-z]/.test(document.getElementById('phone').value) || /[A-Z]/.test(document.getElementById('phone').value)) {
		alert("Alphabets are not allowed.\n")
		document.getElementById('phone').focus();
		return false;
	} else if (document.getElementById('phone').value.length !== 10) {
		alert("Entered Contact number should be in 10 digit.\n")
		document.getElementById('phone').focus();
		return false;
	}

	if (document.getElementById('email').value == "") {
		alert("Please enter email ID ");
		document.getElementById('email').focus();
		return false;
	}

	if (document.getElementById('email').value == "") {
		alert("Please enter email ID .");
		document.getElementById('email').focus();
		return false;
	} else if (!((document.getElementById('email').value.indexOf(".") > 0) &&
			(document.getElementById('email').value.indexOf("@") > 0)) ||
		/[^a-zA-Z0-9.@_-]/.test(document.getElementById('email').value)) {
		alert("Email ID Invalid");
		document.getElementById('email').focus();
		return false;
	}

	if (document.getElementById('message').value == "") {
		alert("Please enter your message");
		document.getElementById('message').focus();
		return false;
	}
}
/*Coontact Us Validation Ends*/


/* Registration form workshop */
/*form conditions*/
