<?php
include( 'database/qdb.php' );
include( './includes/ip.php' );
 include('./q_session.php');

$today = date( "Y-m-d" );
$today_num = date( "Ymd" );
$current_time = date( "His" );
$current_day = date( "D" );
$todaytime = "$today_num$current_time";


$qset = mysqli_query($qconnect, "SELECT 
						t1.paperset,
						t1.*,
						t2.*
						
					FROM 
						quiz_score t1
						INNER JOIN quiz_reg t2
						ON t1.userid=t2.id
					where 
						t1.userid='$fid' 
					ORDER BY t1.paperset ASC
					
					");
$unum=mysqli_num_rows($qset);
while($_GET=mysqli_fetch_array($qset))
{
	$pset=$_GET['paperset'];
	$pics=$_GET['pics'];
	$prank=$_GET['rank'];
	$phonepe=$_GET['phonepe'];
	$paytm=$_GET['paytm'];
	$googlepay=$_GET['googlepay'];
}

	
if ($prank >= 1 && $prank <= 20) {
	if($prank >= 1 && $prank <= 3){
		if(!empty($pics)){
			if($paytm == 0 && $phonepe == 0 && $googlepay == 0){
?>	
										
				<!DOCTYPE html>
				<html lang="en">

				<head>

					<head>
						<title>QuizBattle : CollegeMitra || make them easy...</title>
						<?php include "metatag.php"; ?>
						<meta name="keywords" content="CollegeMitra.com, virtual, virtual classes, online education, books, online class, onine books, GATE, Engineering notes, class notes, online preparation,virtual learning "/>
						<?php include "landingtitle.php"; ?>
					</head>
					<body>
						<?php include "landingnav.php"; ?>

						<!--Common File which include common code to every page-->
						<?php include_once("./common.php") ?>


						<!-- /.Registration -->
						<div class="content-section-b" id="section-1">
							<div class="container">
								<h2 style="text-align: center; color: darkblue;">QuestionBattle Schedule</h2>
								<h3 style="text-align: center;">Every <span style="color:orangered">Saturday</span> Start from <span style="color: red"><u>10:00 AM</span></u>  to  <span style="color: red"><u>10:00 PM</u></span></h3>
								<!--<h3 style="text-align: center;"><img src="images/point.png" width="50px" height="auto" alt="cm"> You are NEXT, login now <img src="images/point.png" width="50px" height="auto"sz alt="cm"></h3>-->
								<hr>
								<div class="row">

									<div class="col-lg-6 col-lg-offset-3">
										<div class="fb-like" data-href="https://www.facebook.com/collegemitra/" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>
										<div class=" panel panel-info">
											<div class="panel-heading"><i class="fa fa-pencil-square-o"></i> Update Your details to get your prize</div>						
										<form class="form-horizontal col-xs-offset-1" name="form1" id="defaultForm" method="post" action="q_update_pro.php" enctype="multipart/form-data" role="form" onsubmit="return update();">
											<div class="form-group"></div>
												<div class="form-group">
													<label for="paytm" class="col-sm-3 control-label" role="navigation">PayTm</label>
													<div class="col-sm-8 col-xs-11">
														<input type="text" class="form-control " id="paytm" name="paytm" placeholder=" Please enter Paytm No." maxlength="10" onkeypress="return isNumber(event)" autocomplete="off">
													</div>
												</div>
												<div class="form-group">
													<label for="phonepe" class="col-sm-3 control-label" role="navigation">PhonePe</label>
													<div class="col-sm-8 col-xs-11">
														<input type="text" class="form-control " id="phonepe" name="phonepe" placeholder=" Please enter Phonepe No." onkeypress="return isNumber(event)" maxlength="10" autocomplete="off">
													</div>
												</div>
												<div class="form-group">
													<label for="googlepay" class="col-sm-3 control-label" role="navigation">GoogelsPay</label>
													<div class="col-sm-8 col-xs-11">
														<input type="text" class="form-control " id="googlepay" name="googlepay" placeholder=" Please enter Google Pay No." onkeypress="return isNumber(event)" maxlength="10" autocomplete="off">
													</div>
												</div>
												<div class="form-group">
													<div class="col-md-5 col-sm-5  col-xs-offset-5">
														<button type="submit" class="form-control btn btn-danger" name="doSubmit" id="doSubmit">Update</button>
													</div>
												</div>
											</form>
											

										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="content-section-a" id="section-1">
							<?php include "includes/winner_prize.php"; ?>
						</div>

						<!-- /.container -->
						<!-- Footer -->
						<?php include "includes/landingfooter.php"; ?>

						<!-- Login Popup -->
						<?php include "landingsigninpopup.php"; ?>

						<!-- jQuery Version 1.11.0 -->
						<script src="js/jquery-1.11.0.js"></script>

						<!-- Bootstrap Core JavaScript -->
						<script src="js/bootstrap.min.js"></script>
						<script>
							$( function () {
								$( "[data-toggle='popover']" ).popover();
							} );
						</script>


						<!--Quiz Registration-->
						<script>
							/*Numerial numbers allowed*/
							function isNumber(evt) {
							evt = (evt) ? evt : window.event;
							var charCode = (evt.which) ? evt.which : evt.keyCode;
							if (charCode > 31 && (charCode < 48 || charCode > 57)) {
								return false;
							}
							return true;
				}

							function update() {


								if ( (document.getElementById( 'paytm' ).value == "") && (document.getElementById( 'phonepe' ).value == "") && (document.getElementById( 'googlepay' ).value == "")) {
									alert( "Please Enter anyone of them." );
									document.getElementById( 'paytm' ).focus();
									return false;
								}
							}
						</script>




					</body>

				</html>
				<?php	}else{
					header("location: ./q_exam.php");
			}
		}else{ ?>
										
			<!DOCTYPE html>
			<html lang="en">

			<head>

				<head>
					<title>QuizBattle : CollegeMitra || make them easy...</title>
					<?php include "metatag.php"; ?>
					<meta name="keywords" content="CollegeMitra.com, virtual, virtual classes, online education, books, online class, onine books, GATE, Engineering notes, class notes, online preparation,virtual learning "/>
					<?php include "landingtitle.php"; ?>
				</head>
				<body>
					<?php include "landingnav.php"; ?>

					<!--Common File which include common code to every page-->
					<?php include_once("./common.php") ?>


					<!-- /.Registration -->
					<div class="content-section-b" id="section-1">
						<div class="container">
							<h2 style="text-align: center; color: darkblue;">QuestionBattle Schedule</h2>
							<h3 style="text-align: center;">Every <span style="color:orangered">Saturday</span> Start from <span style="color: red"><u>10:00 AM</span></u>  to  <span style="color: red"><u>10:00 PM</u></span></h3>
							<!--<h3 style="text-align: center;"><img src="images/point.png" width="50px" height="auto" alt="cm"> You are NEXT, login now <img src="images/point.png" width="50px" height="auto"sz alt="cm"></h3>-->
							<hr>
							<div class="row">

								<div class="col-lg-6 col-lg-offset-3">
									<div class="fb-like" data-href="https://www.facebook.com/collegemitra/" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>
									<div class=" panel panel-info">
										<div class="panel-heading"><i class="fa fa-pencil-square-o"></i> Update Your details to get your prize</div>
									<form class="form-horizontal col-xs-offset-1" name="form1" id="defaultForm" method="post" action="q_update_pro.php" enctype="multipart/form-data" role="form" onsubmit="return update();">
										<div class="form-group"></div>
											<div class="form-group">
												<label for="pics" class="col-sm-3 control-label" role="navigation">Photo</label>
												<div class="col-sm-8 col-xs-11">
													<input type="file" name="pics" id="pics" accept="image/*" required>
												</div>
											</div>
											<?php if($paytm == 0 && $phonepe == 0 && $googlepay == 0){ ?>
												<div class="form-group">
													<label for="paytm" class="col-sm-3 control-label" role="navigation">PayTm</label>
													<div class="col-sm-8 col-xs-11">
														<input type="text" class="form-control " id="paytm" name="paytm" placeholder=" Please enter Paytm No." maxlength="10" onkeypress="return isNumber(event)" autocomplete="off">
													</div>
												</div>
												<div class="form-group">
													<label for="phonepe" class="col-sm-3 control-label" role="navigation">PhonePe</label>
													<div class="col-sm-8 col-xs-11">
														<input type="text" class="form-control " id="phonepe" name="phonepe" placeholder=" Please enter Phonepe No." onkeypress="return isNumber(event)" maxlength="10" autocomplete="off">
													</div>
												</div>
												<div class="form-group">
													<label for="googlepay" class="col-sm-3 control-label" role="navigation">GoogelsPay</label>
													<div class="col-sm-8 col-xs-11">
														<input type="text" class="form-control " id="googlepay" name="googlepay" placeholder=" Please enter Google Pay No." onkeypress="return isNumber(event)" maxlength="10" autocomplete="off">
													</div>
												</div>
										<?php } ?>
												<div class="form-group">
													<div class="col-md-5 col-sm-5  col-xs-offset-5">
														<button type="submit" class="form-control btn btn-danger" name="doSubmit" id="doSubmit">Update</button>
													</div>
												</div>
											</form>

										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="content-section-a" id="section-1">
							<?php include "includes/winner_prize.php"; ?>
						</div>

						<!-- /.container -->
						<!-- Footer -->
						<?php include "includes/landingfooter.php"; ?>

						<!-- Login Popup -->
						<?php include "landingsigninpopup.php"; ?>

						<!-- jQuery Version 1.11.0 -->
						<script src="js/jquery-1.11.0.js"></script>

						<!-- Bootstrap Core JavaScript -->
						<script src="js/bootstrap.min.js"></script>
						<script>
							$( function () {
								$( "[data-toggle='popover']" ).popover();
							} );
						</script>


						<!--Quiz Registration-->
						<script>
							/*Numerial numbers allowed*/
							function isNumber(evt) {
							evt = (evt) ? evt : window.event;
							var charCode = (evt.which) ? evt.which : evt.keyCode;
							if (charCode > 31 && (charCode < 48 || charCode > 57)) {
								return false;
							}
							return true;
				}

							function update() {


								if ( (document.getElementById( 'paytm' ).value == "") && (document.getElementById( 'phonepe' ).value == "") && (document.getElementById( 'googlepay' ).value == "")) {
									alert( "Please Enter anyone of them." );
									document.getElementById( 'paytm' ).focus();
									return false;
								}
							}
						</script>




					</body>

				</html>
				<?php
			 }
	}else{
		if($paytm == 0 && $phonepe == 0 && $googlepay == 0){ ?>

			<!DOCTYPE html>
			<html lang="en">

			<head>

				<head>
					<title>QuizBattle : CollegeMitra || make them easy...</title>
					<?php include "metatag.php"; ?>
					<meta name="keywords" content="CollegeMitra.com, virtual, virtual classes, online education, books, online class, onine books, GATE, Engineering notes, class notes, online preparation,virtual learning "/>
					<?php include "landingtitle.php"; ?>
				</head>
				<body>
					<?php include "landingnav.php"; ?>

					<!--Common File which include common code to every page-->
					<?php include_once("./common.php") ?>


					<!-- /.Registration -->
					<div class="content-section-b" id="section-1">
						<div class="container">
							<h2 style="text-align: center; color: darkblue;">QuestionBattle Schedule</h2>
							<h3 style="text-align: center;">Every <span style="color:orangered">Saturday</span> Start from <span style="color: red"><u>10:00 AM</span></u>  to  <span style="color: red"><u>10:00 PM</u></span></h3>
							<!--<h3 style="text-align: center;"><img src="images/point.png" width="50px" height="auto" alt="cm"> You are NEXT, login now <img src="images/point.png" width="50px" height="auto"sz alt="cm"></h3>-->
							<hr>
							<div class="row">

								<div class="col-lg-6 col-lg-offset-3">
									<div class="fb-like" data-href="https://www.facebook.com/collegemitra/" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>
									<div class=" panel panel-info">
										<div class="panel-heading"><i class="fa fa-pencil-square-o"></i> Update Your details to get your prize</div>
										<form class="form-horizontal col-xs-offset-1" name="form1" id="defaultForm" method="post" action="q_update_pro.php" enctype="multipart/form-data" role="form" onsubmit="return update();">
											<div class="form-group"></div>
												<div class="form-group">
													<label for="paytm" class="col-sm-3 control-label" role="navigation">PayTm</label>
													<div class="col-sm-8 col-xs-11">
														<input type="text" class="form-control " id="paytm" name="paytm" placeholder=" Please enter Paytm No." maxlength="10" onkeypress="return isNumber(event)" autocomplete="off">
													</div>
												</div>
												<div class="form-group">
													<label for="phonepe" class="col-sm-3 control-label" role="navigation">PhonePe</label>
													<div class="col-sm-8 col-xs-11">
														<input type="text" class="form-control " id="phonepe" name="phonepe" placeholder=" Please enter Phonepe No." onkeypress="return isNumber(event)" maxlength="10" autocomplete="off">
													</div>
												</div>
												<div class="form-group">
													<label for="googlepay" class="col-sm-3 control-label" role="navigation">GoogelsPay</label>
													<div class="col-sm-8 col-xs-11">
														<input type="text" class="form-control " id="googlepay" name="googlepay" placeholder=" Please enter Google Pay No." onkeypress="return isNumber(event)" maxlength="10" autocomplete="off">
													</div>
												</div>
												<div class="form-group">
													<div class="col-md-5 col-sm-5  col-xs-offset-5">
														<button type="submit" class="form-control btn btn-danger" name="doSubmit" id="doSubmit">Update</button>
													</div>
												</div>
											</form>

										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="content-section-a" id="section-1">
							<?php include "includes/winner_prize.php"; ?>
						</div>

						<!-- /.container -->
						<!-- Footer -->
						<?php include "includes/landingfooter.php"; ?>

						<!-- Login Popup -->
						<?php include "landingsigninpopup.php"; ?>

						<!-- jQuery Version 1.11.0 -->
						<script src="js/jquery-1.11.0.js"></script>

						<!-- Bootstrap Core JavaScript -->
						<script src="js/bootstrap.min.js"></script>
						<script>
							$( function () {
								$( "[data-toggle='popover']" ).popover();
							} );
						</script>


						<!--Quiz Registration-->
						<script>
							/*Numerial numbers allowed*/
							function isNumber(evt) {
							evt = (evt) ? evt : window.event;
							var charCode = (evt.which) ? evt.which : evt.keyCode;
							if (charCode > 31 && (charCode < 48 || charCode > 57)) {
								return false;
							}
							return true;
				}

							function update() {


								if ( (document.getElementById( 'paytm' ).value == "") && (document.getElementById( 'phonepe' ).value == "") && (document.getElementById( 'googlepay' ).value == "")) {
									alert( "Please Enter anyone of them." );
									document.getElementById( 'paytm' ).focus();
									return false;
								}
							}
						</script>




					</body>

				</html>
				<?php }else{ 
			header("location: ./q_exam.php");
		}
	}
}else{
	header("location: ./q_exam.php");
}
?>