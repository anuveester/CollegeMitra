
				<!DOCTYPE html><!--Exam-->
				<html lang="en">
					<head>
						<head><title>QuizBattle : CollegeMitra || make them easy...</title>
					<?php include "metatag.php"; ?>
					<meta name="keywords" content="CollegeMitra.com, virtual, virtual classes, online education, books, online class, onine books, GATE, Engineering notes, class notes, online preparation,virtual learning " />
					<?php include "landingtitle.php"; ?>


					</head>

						<script>document.addEventListener('contextmenu', event => event.preventDefault());</script>

					<body onselectstart="return false">
					<!-- Navigation -->
						<nav class="navbar navbar-inverse navbar-fixed-top">
							<div class="container">
								<!-- Brand and toggle get grouped for better mobile display -->
								<div class="navbar-header">
									<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
										<span class="sr-only">Toggle navigation</span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
									</button>
									<a class="navbar-brand" href="#"><img src="img/logo.png" class="logo" alt="CollegeMitra"></a>
								</div>
								<!-- /.navbar-collapse -->
							</div>
							<!-- /.container -->
						</nav>

					 <!--Quiz common-->
					  <script src="http://code.jquery.com/jquery-latest.js"></script>
						<?php include_once("./includes/mocktestcommon.php") ?>


					<!--Common File which include common code to every page-->


					<script>
					shortcut = {
						all_shortcuts: {},
						  add: function (e, t, n) {
							var r = {
							  type: "keydown",
							  propagate: !1,
							  disable_in_input: !1,
							  target: document,
							  keycode: !1
							};
							if (n) for (var i in r) "undefined" == typeof n[i] && (n[i] = r[i]);
							else n = r;
							r = n.target, "string" == typeof n.target && (r = document.getElementById(n.target)), e = e.toLowerCase(), i = function (r) {
							  r = r || window.event;
							  if (n.disable_in_input) {
								var i;
								r.target ? i = r.target : r.srcElement && (i = r.srcElement), 3 == i.nodeType && (i = i.parentNode);
								if ("INPUT" == i.tagName || "TEXTAREA" == i.tagName) return
							  }
							  r.keyCode ? code = r.keyCode : r.which && (code = r.which), i = String.fromCharCode(code).toLowerCase(), 188 == code && (i = ","), 190 == code && (i = ".");
							  var s = e.split("+"),
								o = 0,
								u = {
								  "`": "~",
								  1: "!",
								  2: "@",
								  3: "#",
								  4: "$",
								  5: "%",
								  6: "^",
								  7: "&",
								  8: "*",
								  9: "(",
								  0: ")",
								  "-": "_",
								  "=": "+",
								  ";": ":",
								  "'": '"',
								  ",": "<",
								  ".": ">",
								  "/": "?",
								  "\\": "|"
								}, f = {
								  esc: 27,
								  escape: 27,
								  tab: 9,
								  space: 32,
								  "return": 13,
								  enter: 13,
								  backspace: 8,
								  scrolllock: 145,
								  scroll_lock: 145,
								  scroll: 145,
								  capslock: 20,
								  caps_lock: 20,
								  caps: 20,
								  numlock: 144,
								  num_lock: 144,
								  num: 144,
								  pause: 19,
								  "break": 19,
								  insert: 45,
								  home: 36,
								  "delete": 46,
								  end: 35,
								  pageup: 33,
								  page_up: 33,
								  pu: 33,
								  pagedown: 34,
								  page_down: 34,
								  pd: 34,
								  left: 37,
								  up: 38,
								  right: 39,
								  down: 40,
								  f1: 112,
								  f2: 113,
								  f3: 114,
								  f4: 115,
								  f5: 116,
								  f6: 117,
								  f7: 118,
								  f8: 119,
								  f9: 120,
								  f10: 121,
								  f11: 122,
								  f12: 123
								}, l = !1,
								c = !1,
								h = !1,
								p = !1,
								d = !1,
								v = !1,
								m = !1,
								y = !1;
							  r.ctrlKey && (p = !0), r.shiftKey && (c = !0), r.altKey && (v = !0), r.metaKey && (y = !0);
							  for (var b = 0; k = s[b], b < s.length; b++) "ctrl" == k || "control" == k ? (o++, h = !0) : "shift" == k ? (o++, l = !0) : "alt" == k ? (o++, d = !0) : "meta" == k ? (o++, m = !0) : 1 < k.length ? f[k] == code && o++ : n.keycode ? n.keycode == code && o++ : i == k ? o++ : u[i] && r.shiftKey && (i = u[i], i == k && o++);
							  if (o == s.length && p == h && c == l && v == d && y == m && (t(r), !n.propagate)) return r.cancelBubble = !0, r.returnValue = !1, r.stopPropagation && (r.stopPropagation(), r.preventDefault()), !1
							}, this.all_shortcuts[e] = {
							  callback: i,
							  target: r,
							  event: n.type
							}, r.addEventListener ? r.addEventListener(n.type, i, !1) : r.attachEvent ? r.attachEvent("on" + n.type, i) : r["on" + n.type] = i
						  },
						  remove: function (e) {
							var e = e.toLowerCase(),
							  t = this.all_shortcuts[e];
							delete this.all_shortcuts[e];
							if (t) {
							  var e = t.event,
								n = t.target,
								t = t.callback;
							  n.detachEvent ? n.detachEvent("on" + e, t) : n.removeEventListener ? n.removeEventListener(e, t, !1) : n["on" + e] = !1
							}

						  }
						},
						 shortcut.add("Ctrl+U",function (){
						 //alert('Sorry\nNo CTRL+U is allowed. Be creative!')
						}),
						 shortcut.add("Meta+Alt+U",function(){
						 //alert('Sorry\nNo Command+Option+U is allowed. Be creative!')
						}),
						shortcut.add("Ctrl+C",function(){
						 //alert('Sorry\nNever duplicate th`enter code here`is article...')
						}),
						shortcut.add("Meta+C",function(){
						 //alert('Sorry\nNever duplicate this article...')
						});
						shortcut.add("f12",function(){
						 //alert('Sorry\nNever Sorry this is not allowed')
						});
						shortcut.add("Ctrl+P",function(){
						 //alert('Sorry\nNever Sorry this is not allowed')
						});
						shortcut.add("Meta+P",function(){
						 //alert('Sorry\nNever Sorry this is not allowed')
						});


					</script>

						<!-- Record of Ip Adress -->

					<?php include 'includes/analyticstracking.php';


					?>


						<!-- Fb Button roots-->
						<div id="fb-root"></div>
						<script>
						(function(d, s, id) {
						  var js, fjs = d.getElementsByTagName(s)[0];
						  if (d.getElementById(id)) return;
						  js = d.createElement(s); js.id = id;
						  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.0";
						  fjs.parentNode.insertBefore(js, fjs);
						}(document, 'script', 'facebook-jssdk'));
						</script>


					<!-- Redirect to another page (for no-js support) (place it in your <head>) -->
					<noscript><meta http-equiv="refresh" content="1 ;url=http://www.collegemitra.com/javaalert"></noscript>  


					<div class="content-section-a" id="section-1">
					  <div class="container">
						<div class="row">
						  <div class="col-lg-10  col-sm-12 col-xs-offset-1">

							<div class="col-md-9 col-sm-8">

							   <!--Edit Feed-->
							   <div class="row"><!-- /row -->

								   <div class="col-sm-12 col-md-12">
										<h2>You are attending <strong class="text-info">QuizBattle</strong>, SET-<?php echo $set ?>
										<small class="pull-right">
											<span id='timer'></span>
											<i class="fa fa-clock-o fa-2x text-third"></i>
										</small>
										</h2>
										<br>
										<hr>

										<div class="row" >
											<div class="col-sm-12">
											<form class="form-horizontal" role="form" id='quiz_form' method="post" action="quiz_result.php">
												<?php
													//echo "$number_question";

													$i = 0;
													$j = 1;
													$k = 1;							

													$row = mysqli_query($qconnect,"select * from quiz_exam where paperset='$set' ORDER BY RAND() limit 0,$limit");
													$rowcount = mysqli_num_rows( $row );
													$remainder = $rowcount/$number_question;
													while ( $result = mysqli_fetch_assoc($row) ) {
														$results['questions'][] = $result;		
														$time=$result['timer'];	
														$timer=	1200; //in seconds			
													}

													foreach ($results['questions'] as $result) {
														$qid=$result['id'];
														$qhold = mysqli_query($qconnect,"INSERT INTO quiz_holder ( qid,userid,paperset)VALUES ( '$qid',$fid,$set)");
														if ( $i == 0) echo "<div class='cont' id='question_splitter_$j'>";?>

														<div id='question<?php echo $k;?>' >
														<strong><p class='questions' id="qname<?php echo $j;?>"> <span class="text-info"><?php echo $k?></span>.&nbsp;<?php echo $result['question_name'];?></p></strong>

														<ul style="list-style:none">
														<li>
														<input type="radio" value="1" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>  <?php echo $result['answer1'];?>
														</li>
														<li>
														<input type="radio" value="2" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>  <?php echo $result['answer2'];?>
														</li>
														<li>

														<?php if(isset( $result['answer3'] ) && !empty( $result['answer3'] )){ ?>
														<input type="radio" value="3" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>  <?php echo $result['answer3'];?>
														<?php } ?>
														</li>
														<li>

														<?php if(isset( $result['answer4'] ) && !empty( $result['answer4'] )){ ?>
														<input type="radio" value="4" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>  <?php echo $result['answer4'];?>
														<?php } ?>
														</li>
														<li>

														<?php if(isset( $result['answer5'] ) && !empty( $result['answer5'] )){ ?>
														<input type="radio" value="5" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>  <?php echo $result['answer5'];?>
														<?php } ?>
														</li>
														<li>

														<?php if(isset( $result['answer6'] ) && !empty( $result['answer6'] )){ ?>
														<input type="radio" value="6" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>  <?php echo $result['answer6'];?>
														<?php } ?> 
														</li> 
														</ul>                                 

														<input type="radio" checked='checked' style='display:none' value="smart_quiz" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>
														<hr> 
														</div>

														<?php
															 $i++; 
															 if ( ( $remainder < 1 ) || ( $i == $number_question && $remainder == 1 ) ) {
																echo "<button id='".$j."' class='next btn btn-success' type='submit'>Finish</button>";
																echo "</div>";
															 }  elseif ( $rowcount > $number_question  ) {
																if ( $j == 1 && $i == $number_question ) {
																	echo "<button id='".$j."' class='next btn btn-success' type='button'>Next</button>";
																	echo "</div>";
																	$i = 0;
																	$j++;           
																} elseif ( $k == $rowcount ) { 
																	echo " <button id='".$j."' class='previous btn btn-success' type='button'>Previous</button>
																	<button id='".$j."' class='next btn btn-success' type='submit'>Finish</button>";
																	echo "</div>";
																	$i = 0;
																	$j++;
																} elseif ( $j > 1 && $i == $number_question ) {
																	echo "<button id='".$j."' class='previous btn btn-success' type='button'>Previous</button>
																	<button id='".$j."' class='next btn btn-success' type='button' >Next</button>";
																	echo "</div>";
																	$i = 0;
																	$j++;
																}

															 }
															  $k++;
														 } ?>	
											  </form>
										</div>

										</div>

								   </div>

								</div> <!-- /.row -->
								<!--edit feed Finished-->

							  </div>   

						  </div>
						</div>
					  </div>
					</div>



<div class="content-section-b" id="section-1">
	<?php include "includes/winner_prize.php"; ?>
</div>
					<!-- /.container --> 
					<!-- Footer -->

						<footer>
							<div class="container">
								<div class="row">
									<div class="col-lg-12">
										<p class="copyright text-muted small">Copyright &copy; CollegeMitra 2012-<?php echo date('Y'); ?>. All Rights Reserved</p>
									</div>
								</div>
							</div>
						</footer>

					<!-- Login Popup -->

					<!-- jQuery Version 1.11.0 --> 
					<script src="js/jquery-1.11.0.js"></script> 

					<!-- Bootstrap Core JavaScript --> 
					<script src="js/bootstrap.min.js"></script> 
					<script>$(function () 
						  { $("[data-toggle='popover']").popover();
						  });
					   </script>

					   <!--Timer-->
						<script>
							$('.cont').addClass('hide');
							$('#question_splitter_1').removeClass('hide');
							$(document).on('click','.next',function(){
								last=parseInt($(this).attr('id'));  console.log( last );   
								nex=last+1;
								$('#question_splitter_'+last).addClass('hide');

								$('#question_splitter_'+nex).removeClass('hide');
							});

							$(document).on('click','.previous',function(){
								last=parseInt($(this).attr('id'));     
								pre=last-1;
								$('#question_splitter_'+last).addClass('hide');

								$('#question_splitter_'+pre).removeClass('hide');
							});

							var c = <?php echo $timer ?>;
							var t;
							timedCount();

							function timedCount() {

								var hours = parseInt( c / 3600 ) % 24;
								var minutes = parseInt( c / 60 ) % 60;
								var seconds = c % 60;

								var result = (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds  < 10 ? "0" + seconds : seconds);

								$('#timer').html(result);
								if(c == 0 ){
									setConfirmUnload(false);
									$("#quiz_form").submit();
								}
								c = c - 1;
								t = setTimeout(function(){ timedCount() }, 1000);
							}
						</script>

						<script type="text/javascript">

							// Prevent accidental navigation away
							setConfirmUnload(true);
							function setConfirmUnload(on)
							{
								window.onbeforeunload = on ? unloadMessage : null;
							}
							function unloadMessage()
							{
								return 'Your Answered Questions are resetted zero, Please select stay on page to continue your Quiz';
							}

							$(document).on('click', 'button:submit',function(){
								setConfirmUnload(false);
							});

						</script>


					</body>
					</html>