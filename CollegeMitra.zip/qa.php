
	<!DOCTYPE html><!--QuestionBattle will start in:-->
	<html lang="en">
	<head>
		<head><title>QuizBattle : CollegeMitra || make them easy...</title>
	<?php include "metatag.php"; ?>
	<meta name="keywords" content="CollegeMitra.com, virtual, virtual classes, online education, books, online class, onine books, GATE, Engineering notes, class notes, online preparation,virtual learning " />
	<?php include "landingtitle.php"; ?>
	</head>


	<style> 

	h1{ 
	  margin: 40px 0px 20px; 
	  text-align: center; 
	} 
	 #clockdiv{ 
		font-family: sans-serif; 
		color: #fff; 
		display: inline-block; 
		font-weight: 100; 
		text-align: center; 
		font-size: 30px; 
			width: 100%;
			margin: 0 auto;
			padding: 20px;
	} 
	#clockdiv > div{ 
		padding: 10px; 
		border-radius: 3px; 
		background: #00BF96; 
		display: inline-block; 
	} 
	#clockdiv div > span{ 
		padding: 15px; 
		border-radius: 3px; 
		background: #00816A; 
		display: inline-block; 
	} 
	smalltext{ 
		padding-top: 5px; 
		font-size: 16px; 
	} 
	</style> 

	<body>
	<?php include "landingnav.php"; ?>

	<!--Common File which include common code to every page-->
	<?php include_once("./common.php") ?>
	<div class="content-section-a" id="section-1">
	  <div class="container">
		<div class="row">
		  <div class="col-lg-12 col-sm-12 center-block">
			<h1 class="section-heading">QuestionBattle will start in: <?php echo $datejavascript ; ?></h1>
				<div id="clockdiv"> 
				  <div> 
					<span class="days" id="day"></span> 
					<div class="smalltext">Days</div> 
				  </div> 
				  <div> 
					<span class="hours" id="hour"></span> 
					<div class="smalltext">Hours</div> 
				  </div> 
				  <div> 
					<span class="minutes" id="minute"></span> 
					<div class="smalltext">Minutes</div> 
				  </div> 
				  <div> 
					<span class="seconds" id="second"></span> 
					<div class="smalltext">Seconds</div> 
				  </div> 
				</div>         
		  </div>
		</div>
	  </div>
	</div>


<div class="content-section-b" id="section-1">
	<?php include "includes/winner_prize.php"; ?>
</div>
	<!-- /.container --> 
<!-- Footer -->
<?php include "includes/landingfooter.php"; ?>

	<!-- Bootstrap Core JavaScript --> 
	<script src="js/bootstrap.min.js"></script>    


	<!--countdown timer-->

		<script> 

	var deadline = new Date("<?php echo $datejavascript ?> <?php echo $examtime ?>").getTime(); 

	var x = setInterval(function() { 

	var now = new Date().getTime(); 
	var t = deadline - now; 
	var days = Math.floor(t / (1000 * 60 * 60 * 24)); 
	var hours = Math.floor((t%(1000 * 60 * 60 * 24))/(1000 * 60 * 60)); 
	var minutes = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60)); 
	var seconds = Math.floor((t % (1000 * 60)) / 1000); 
	document.getElementById("day").innerHTML =days ; 
	document.getElementById("hour").innerHTML =hours; 
	document.getElementById("minute").innerHTML = minutes;  
	document.getElementById("second").innerHTML =seconds;  
	if (t < 0) { 
			clearInterval(x); 
			document.getElementById("demo").innerHTML = "TIME UP"; 
			document.getElementById("day").innerHTML ='0'; 
			document.getElementById("hour").innerHTML ='0'; 
			document.getElementById("minute").innerHTML ='0' ;  
			document.getElementById("second").innerHTML = '0'; } 
	}, 1000); 
	</script> 

			<!--Auto refresh when exam start-->
			<script>
				var target = new Date("<?php echo $datejavascript ?> <?php echo $examtime ?>");
			timeOffset = target.getTimezoneOffset() * 60000;
			targetTime = target.getTime();
			targetUTC = targetTime + timeOffset;

			var today = new Date();
			todayTime = today.getTime();
			todayUTC = todayTime + timeOffset;

			refreshTime = (targetUTC - todayUTC);
			if (refreshTime > 1) {
				setTimeout(function() { window.location.reload(true); }, refreshTime);
			}
			</script>
	</body>
	</html>s