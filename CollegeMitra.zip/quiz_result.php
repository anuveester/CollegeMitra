<?php
include( 'database/qdb.php' );
include( './includes/ip.php' );
include( './q_session.php' );
$today = date( "Y-m-d" );
$today_num = date( "Ymd" );
$current_time = date( "His" );
$time = date( "H:i:s" );
$current_day = date( "D" );
$todaytime = "$today_num$current_time";



if ( !empty( $_POST ) ) {
	//$scrs =  mysql_real_escape_string($_POST['scr']);		
	$scid = mysqli_query($qconnect, "SELECT * from quiz_score where userid='$fid'" );
	while ( $scids = mysqli_fetch_array( $scid ) ) {
		$score_id = $scids[ 'id' ];
		$score_subject = $scids[ 'category_id' ];
		$set = $scids[ 'paperset' ];
		$examdate = $scids[ 'exam_date' ];
		$edate = date( 'Y-m-d', strtotime( "$examdate" ) );
		$examdate = date( 'l jS \of F Y', strtotime( "$examdate" ) );

		/*timing*/
		$from = $scids[ 'exam_from' ];
		$from = date( 'H:i:s', strtotime( "$from" ) );
		$to = $scids[ 'exam_to' ];
		$to = date( 'H:i:s', strtotime( "$to" ) );

		$mainsubject = mysqli_query($qconnect, "SELECT * FROM quiz_subject WHERE id='$score_subject'" );
		while ( $scoresubject = mysqli_fetch_array( $mainsubject ) ) {
			$subject = $scoresubject[ 'subject' ];
		}
	}
	$efrom = "$edate $from";
	$eto = "$edate $to";

	$right_answer = 0;
	$wrong_answer = 0;
	$unanswered = 0;
	$keys = array_keys( $_POST );
	$order = join( ",", $keys );
	$query = "select * from quiz_exam where id IN($order) ORDER BY FIELD(id,$order)";
	$response = mysqli_query($qconnect, $query );

	$user_id = $fid;
	while ( $result = mysqli_fetch_array( $response ) ) {
		if ( $result[ 'answer' ] == $_POST[ $result[ 'id' ] ] ) {
			$right_answer++;
		} else if ( $_POST[ $result[ 'id' ] ] == 'smart_quiz' ) {
			$unanswered++;
		} else {
			$wrong_answer++;
		}
	}
	$results = array();
	$results[ 'right_answer' ] = $right_answer;
	$results[ 'wrong_answer' ] = $wrong_answer;
	$results[ 'unanswered' ] = $unanswered;

	$input = mysqli_query($qconnect, "SELECT * from quiz_score where userid='$fid' AND exam_date = '$today' AND exam_to = '0'" );
	$meet = mysqli_num_rows( $input );
	if ( $meet != '0' ) {
		$et_from = new DateTime( "$from" );
		$totaltime = $et_from->diff( new DateTime( "$time" ) );
		$hours = $totaltime->h;
		$hours = str_pad( "$hours", 2, "0", STR_PAD_LEFT );
		$min = $totaltime->i;
		$min = str_pad( "$min", 2, "0", STR_PAD_LEFT );
		$sec = $totaltime->s;
		$sec = str_pad( "$sec", 2, "0", STR_PAD_LEFT );

		$ttime = "$hours:$min:$sec";

		$update_query = "update quiz_score set rightanswer='$right_answer', wronganswer = '$wrong_answer', unanswered = '$unanswered', exam_to = '$time', taken_time='$ttime' where id ='$score_id' ";
		mysqli_query($qconnect, $update_query );
		$eto = "$edate $time";
	}

	$et_from = new DateTime( "$efrom" );
	$totaltime = $et_from->diff( new DateTime( "$eto" ) );
	$hours = $totaltime->h;
	$hours = str_pad( "$hours", 2, "0", STR_PAD_LEFT );
	$min = $totaltime->i;
	$min = str_pad( "$min", 2, "0", STR_PAD_LEFT );
	$sec = $totaltime->s;
	$sec = str_pad( "$sec", 2, "0", STR_PAD_LEFT );
} else {
	die( header( "Location: ./col" ) );
}

$attempt = $right_answer + $wrong_answer;
$totalquestion = $right_answer + $wrong_answer + $unanswered;
$percentage = ( $right_answer / $totalquestion ) * 100;
//$percentage=($percentage/10);	
//$percentage=number_format((float)$percentage, 2, '.', '');  // Outputs -> 105.00	

if ( $percentage <= 40 ) {
	$backgroundcolour = '#FFF0F0';
	$textcolor = 'danger';
	$stat = 'Can do better';
} elseif ( $percentage > 40 && $percentage <= 60 ) {
	$backgroundcolour = '#FFFFEA';
	$textcolor = 'warning';
	$stat = 'Average';
} elseif ( $percentage > 60 && $percentage <= 75 ) {
	$backgroundcolour = '#F5FCF5';
	$textcolor = 'success';
	$stat = 'Good';
} elseif ( $percentage > 75 && $percentage <= 100 ) {
	$backgroundcolour = '#F5FCF5';
	$textcolor = 'success';
	$stat = 'Excellent';
}
//Rating System

$query = mysqli_query($qconnect, "SELECT * FROM rate" );
while ( $data = mysqli_fetch_assoc( $query ) ) {
	$rate_db[] = $data;
	$sum_rates[] = $data[ 'rate' ];
	$my_rates = $data[ 'rate' ];
	$posted_id = $data[ 'id_post' ];
}
if ( @count( $rate_db ) ) {
	$rate_times = count( $rate_db );
	$sum_rates = array_sum( $sum_rates );
	$rate_value = $sum_rates / $rate_times;
	$rate_bg = ( ( $rate_value ) / 5 ) * 100;
} else {
	$rate_times = 0;
	$rate_value = 0;
	$rate_bg = 0;
}
$rate_value=number_format($rate_value, 2);
?>
<!DOCTYPE html>
<html lang="en">

<head>

	<head>
		<title>QuizBattle : CollegeMitra || make them easy...</title>
		<?php include "metatag.php"; ?>
		<meta name="keywords" content="CollegeMitra.com, virtual, virtual classes, online education, books, online class, onine books, GATE, Engineering notes, class notes, online preparation,virtual learning "/>
		<?php include "landingtitle.php"; ?>
		<!-- Custom CSS -->
		<link href="css/rate.css" rel="stylesheet">
	</head>

	<body>
		<?php include "landingnav.php"; ?>


		<!--Common File which include common code to every page-->
		<?php include_once("./common.php") ?>
		<div class="content-section-a" id="section-1">
			<div class="container">
				</br>

				<div class="row">
					<div class="col-lg-10  col-sm-12 col-xs-offset-1">

						<div class="col-sm-6">
							<strong>No. of Question : <span style="font-size:16px;"><?php echo $totalquestion ?></span><br></strong>
						</div>

						<div class="col-sm-6">
							<strong>Attempt : <span style="font-size:16px;"><?php echo $attempt ?></span><br></strong>
						</div>

						<div class="col-sm-6">
							<strong>Correct answer : <span style="font-size:16px;"><?php echo $right_answer ?></span><br></strong>
						</div>
						<div class="col-sm-6">
							<strong>Wrong answer : <span style="font-size:16px;"><?php echo $wrong_answer ?></span><br></strong>
						</div>
						<div class="col-sm-6">
							<strong>Un Answered : <span style="font-size:16px;"><?php echo $unanswered ?></span><br></strong>
						</div>
						<div class="col-sm-6">
							<strong>Status : <span style="font-size:16px;"><?php echo $stat ?></span></strong>
						</div>
					</div>
				</div>
			</div>
		</div>


		<div class="content-section-b" id="section-1">

			<div class="container">

				<!--Contets Starts-->
				<div class="row">
					<!--row-->

					<div class="col-md-12 col-sm-12">

						<!--Edit Feed-->
							<div class="row">
								<div class="col-lg-12 col-sm-12">
									<div style="text-align: center">
											<h2 style="font-family: 'Gill Sans MT Condensed';font-weight:bold; font-size:30px;">This quiz you solved in: <span style=" color: forestgreen; font-size: 40px"><?php echo $hours ?></span>H <span style=" color: forestgreen; font-size: 40px"><?php echo $min ?></span>Min  <span style=" color: forestgreen; font-size: 40px"><?php echo $sec ?></span>Sec</span></h2>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-lg-12 col-sm-12">
									<div style="align-content: center">
										<div class="rate-ex2-cnt">
											<div id="1" class="rate-btn-1 rate-btn"></div>
											<div id="2" class="rate-btn-2 rate-btn"></div>
											<div id="3" class="rate-btn-3 rate-btn"></div>
											<div id="4" class="rate-btn-4 rate-btn"></div>
											<div id="5" class="rate-btn-5 rate-btn"></div>
											<h4><?php 
												if($posted_id!=''){ ?> Your:
											<strong class="text-third">
												<?php echo $my_rates; ?> / 5</strong>,
											<?php } ?> Total:
											<strong class="text-third">
												<?php echo $rate_times; ?>
											</strong></h4>
										</div>
									</div>
								</div>
							</div>
							<br><br>
							<div class="row">
								<div class="col-lg-12 col-sm-12">Overall Rating:
									<div>
										<div class=""><h4>Overall Rating:</h4>
											<div class="rate-result-cnt">
												<div class="rate-bg" style="width:<?php echo $rate_bg; ?>%"></div>
												<div class="rate-stars"></div><h4>Overall Rating:</h4>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-lg-12 col-sm-12">
									<div class="" style="text-align: center">
											<h2 style="font-family: 'Gill Sans MT Condensed';font-weight:bold; font-size:30px;">
											<?php if($posted_id!=''){ echo "Your Rating: $my_rates/5,"; }?>
											Total rated: <span style=" color: forestgreen; font-size: 40px"><?php echo "$rate_value/5"; ?></span>											
											</h2>
									</div>
								</div>
							</div>
							<br>
						<div class="col-lg-10  col-sm-12 col-xs-offset-1">
							<div class="col-sm-12 col-md-12">
								<br>
								<style>
									.certificate {
										width: 100%;
										height: auto;
										border: 10px solid #007F9F;
										background-color: <?php echo $backgroundcolour ?>;
									}
									
									u,
									.scr {
										border-bottom: 1px dotted #000;
										text-decoration: none;
									}
								</style>
								<div class="certificate">
									<div class="row">
										<h1 class="text-center text-danger col-xs-12" style=" font-family:GothicE, 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size-adjust:!important;"><strong>Certificate of Appreciation</strong></h1>
										<!--<div class="text-center">
                        	<h3 style=" font-family: 'CommercialScript BT';">Subject</h3>
                        </div>-->
										<div class="text-center">
											<h2 style="font-family: 'Gill Sans MT Condensed';font-weight:bold; font-size:30px;"></br></br>Subject<br><abbr title="<?php echo ucwords(strtolower($subject)) ?>"><?php echo ucwords(strtolower($subject)) ?> - <?php echo ucwords(strtolower($set)) ?></abbr></h2>
										</div>
										<br>
										<div class="col-sm-10 col-xs-10 col-xs-offset-1">
											<strong>Date : <?php echo $examdate ;?></strong>
										</div>
										<div class="text-center col-sm-12 col-xs-12">
											<p class="text-center text-capitalize" style="font-weight:bolder; font-size:32px">
												<u>
													<?php echo $name ?>
												</u>
											</p>
										</div>

										<br>
										<div class="col-lg-2 col-sm-10 col-xs-10 col-xs-offset-1">
											<strong>Score : 
                                    <span style="font-size:20px;" class="text-<?php echo $textcolor ?>"><?php echo $percentage ?>%</span>
                                </strong>
										</div>
										<div class="col-lg-3 col-md-12 col-sm-12 col-xs-12 col-xs-offset-1">
											<strong>Status : 
                                    <span style="font-size:24px;" class="text-<?php echo $textcolor ?>"><?php echo $stat ?></span>
                                </strong>
										</div>
										<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12 col-xs-offset-1">
											<strong>Correct Answer : 
                                    <span style="font-size:24px;" class="text-<?php echo $textcolor ?>"><?php echo $right_answer ?>/<?php echo $totalquestion ?></span>
                                </strong>
										</div>
										<br>
										<br>

										<br>
										<div class="col-sm-12 col-xs-10 text-justify col-xs-offset-1">
											<br> for completing the "Online test" program conducted by <a href="http://www.collegemitra.com" style="text-decoration:none;">collegemitra.com</a>.
										</div><br><br>
										<div class="col-sm-12 col-xs-12 text-justify col-xs-offset-1">
											<small><strong>Note: Not use for any official certification.</strong></small>
										</div>
									</div>
									<hr>
									<div class="row">
										<div class="col-sm-12 text-right">
											<span class="te">Powered by</span> <img src="../../cm-admin/user/images/logo.png" width="100">
										</div>
									</div>
								</div>
								<br>
								<hr>
					
					<div class="row">
						<div class="col-lg-12 col-sm-12">
							<div class="fb-like" data-href="https://www.facebook.com/collegemitra/" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>
							<div class="panel panel-success">
								<div class="panel-heading"><i class="fa fa-pencil-square-o"></i> Suggest Us</div>
								<form class="form-horizontal col-lg-offset-1 col-xs-offset-1" name="form1" id="defaultForm" method="post" action="q_suggest_pro.php" role="form" onsubmit="return sign();">
									<div class="form-group"></div>
									<div class="form-group">
										<label for="email" class="col-sm-2 control-label" role="navigation">"Your suggestions are very valuable to us"</label>
										<div class="col-sm-8 col-xs-11">
											<textarea name="suggest" cols="60" rows="4"></textarea>
										</div>
									</div>
									<div class="form-group">
										<div class="col-md-3 col-sm-3 col-xs-3 col-xs-offset-5">
											<button type="submit" class="form-control btn btn-success" name="sug_submit" id="qenter">Submit Suggestion</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
							<hr>
									<h2><abbr>LAST QUIZ SOLUTIONS</abbr></h2>
									<hr>
									<ol>
										<?php 
											$set=$set-1;		
											$qu=mysqli_query($qconnect, "SELECT * FROM quiz_exam WHERE paperset='$set' order by id asc");
											while($_GET=mysqli_fetch_array($qu))
											{
											$q = $_GET['id'];
												
												$q1 = $_GET['question_name']; 
												//$q1id = $_GET['id']; 
												 $a1 = $_GET['answer']; 

												if($a1==1){
													 $a2='answer1';
												}elseif($a1==2){
													 $a2='answer2';
												}elseif($a1==3){
													 $a2='answer3';
												}elseif($a1==4){
													 $a2='answer4';
												}elseif($a1==5){
													 $a2='answer5';
												}else{
													 $a2='answer6';
												}
													
												$que=mysqli_query($qconnect, "SELECT * from quiz_exam where id='$q'");
												while($qeresult=mysqli_fetch_array($que))
												{
												$ans = $qeresult["$a2"];
												
												?>
										<li>
											<span style="color: blue;"><strong><?php echo "$q1"; ?></strong></span><br> Ans:
											<span style=" color: orange">
												<?php echo "$ans"; ?>
											</span>
										</li><br>
										<?php
										}
										}
										?>
									</ol>

								</div>
							</div>

						</div>
						<!-- /.row -->
						<div class="row">
							<!-- /row -->
							<div class="col-lg-10  col-sm-12 col-xs-offset-1">
								<p>Note<span style="color: red">*</span> : Final result will be declare after 48 hours.</p>
							</div>
							<!-- /.row -->
						</div>
						<!-- /.row -->
						<!--edit feed Finished-->

					</div>
				</div>
			</div>
		</div>

		<!-- /.container -->
		<!-- Footer -->
		<?php include "includes/landingfooter.php"; ?>

		<!-- Login Popup -->
		<?php include "landingsigninpopup.php"; ?>

		<!-- jQuery Version 1.11.0 -->
		<script src="js/jquery-1.11.0.js"></script>

		<!-- Bootstrap Core JavaScript -->
		<script src="js/bootstrap.min.js"></script>
		<script>
			$( function () {
				$( "[data-toggle='popover']" ).popover();
			} );
		</script>


		<script>
			// rating script
			$( function () {
				$( '.rate-btn' ).hover( function () {
					$( '.rate-btn' ).removeClass( 'rate-btn-hover' );
					var therate = $( this ).attr( 'id' );
					for ( var i = therate; i >= 0; i-- ) {
						$( '.rate-btn-' + i ).addClass( 'rate-btn-hover' );
					};
				} );

				$( '.rate-btn' ).click( function () {
					var therate = $( this ).attr( 'id' );
					var dataRate = 'act=rate&post_id=<?php echo $fid; ?>&rate=' + therate; //
					$( '.rate-btn' ).removeClass( 'rate-btn-active' );
					for ( var i = therate; i >= 0; i-- ) {
						$( '.rate-btn-' + i ).addClass( 'rate-btn-active' );
					};
					$.ajax( {
						type: "POST",
						url: "./quiz_result_ajax.php",
						data: dataRate,
						success: function () {}
					} );

				} );
			} );
		</script>
			< /body> < /
			html >