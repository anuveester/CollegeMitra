<div class="banner">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <h3>Connect to Start College<span style="color:#f0ad4e;">Mitra</span></h3>
      </div>
      <div class="col-lg-6">
        <ul class="list-inline banner-social-buttons">
          <li> <a href="https://twitter.com/collegemitra" class="btn btn-default btn-lg"><i class="fa fa-twitter fa-fw"></i> <span class="network-name">Twitter</span></a> </li>
          <li> <a href="https://facebook.com/collegemitra" class="btn btn-warning btn-lg"><i class="fa fa-facebook fa-fw"></i> <span class="network-name">facebook</span></a> </li>
          <li> <a href="https://google.com/+Collegemitra" target="_blank" class="btn btn-default btn-lg"><i class="fa fa-google-plus fa-fw"></i> <span class="network-name">google plus</span></a> </li>
        </ul>
      </div>
    </div>
  </div>
  <!-- /.container --> 
  
</div>
