
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="list-inline">
                        <li>
                            <a href="col">Home</a>
                        </li>
                        <li class="footer-menu-divider">&sdot;</li>
                        <li>
                            <a href="#about">About Us</a>
                        </li>
                        <li class="footer-menu-divider">&sdot;</li>
                        <li>
                            <a href="tnc">Terms and Conditions</a>
                        </li>
                        <li class="footer-menu-divider ">&sdot;</li>
                        <li>
                            <a href="contactus">Contact Us</a>
                        </li>
                    </ul>
                    <p class="copyright text-muted small">Copyright &copy; CollegeMitra 2012-<?php echo date('Y'); ?>. All Rights Reserved</p>
                </div>
            </div>
        </div>
    </footer>