

<form method="POST" action="signup" name="registration_form" id="registration_form" >
<b><p align="center" id="reg"><span id="reg_1">Sign</span><span id="reg_2">Up</span> <span id="reg_3">Form</span></p></b>
<p align="center" id="reg_msg"><small>Register and get great sign to success.</small></p>
  <table id="reg_tab">
	   <tr>
	   <td id="rgt_box"></td>
       <td><input type="text" id="fname" name="fname" placeholder="First Name"/>
       <input type="text" id="lname" name="lname" placeholder="Last Name"/></td>
       </tr>
					
       <tr>
	   <td id="rgt_box"></td>
       <td><input type="text" id="email" name="email" placeholder="Email"></td>
       </tr>
       
		<tr>
	   <td id="rgt_box"></td>
         <td><input type="password" id="password" name="password" placeholder="Password">
         <input type="password" id="password2" name="password2" placeholder="Confirm Password"></td>
        </tr>
		
        <tr>
	   <td id="rgt_box"></td>
       <td><input type="text" class="course" autocomplete="off" id="course" name="course" placeholder="Course" /><span id="stars"><subscript>*</subscript></span><br /><small>Eg: Medical, Engineering, Art, B.A., Bcom. etc.</small>
       <div id="results"></div>
       </td>
       </tr>
       
       <tr id="college_selection" >
	   <td id="rgt_box"></td>
       <td><input type="text" class="college" name="college" id="college" autocomplete="off" placeholder="College"/><span id="stars"><subscript>*</subscript></span><br /><small>Eg: <span id="stars">"NITW"</span> This is wrong.<span id="green">"National Institute Of Technology warangal"</span> This is correct. This will help you to find material from your college.</small>     
       <div id="results"></div>
		</td>
       </tr>

    <tr>
     <td id="rgt_box" ></td>
     <td><input type="text" class="branch" name="branch" id="branch" autocomplete="off" placeholder="Specialization - Branch / Subject / Stream"/><span id="stars"><subscript>*</subscript></span><br /><small>Eg: <span id="stars">"CS"</span> This is wrong.<span id="green">"Computer Science"</span> This is correct. This will help you to find material from your college.</small>
     <div id="results"></div>
<div class="overlay"></div>  </td>
    </tr>
		
    <tr>
      <td>&nbsp;</td>
      <td>
      <input type="reset" name="reg_reset" id="reg_reset" value="Reset" />
      <input type="submit" name="submit" id="submit" value="Register" />
      </td>
    </tr>
    
  </table>

</form>

<div id="results"></div>
<div class="overlay"></div>