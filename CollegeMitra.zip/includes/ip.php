    <?php 

	$user_ip = $ip=$_SERVER['REMOTE_ADDR'];
//echo "IP address= $ip";


$user_ip = $_SERVER['REMOTE_ADDR']; 
$ip2long=ip2long($user_ip);
//$ip = '168.192.0.1'; // your ip address here
    $query = @unserialize(file_get_contents('http://ip-api.com/php/'.$user_ip));
    if($query && $query['status'] == 'success')
    {
        $city=$query['city'];
        $country=$query['country'];
        $countrycode=$query['countryCode'];
        $regionName=$query['regionName'];
        $region=$query['region'];
        $timezone=$query['timezone'];
		date_default_timezone_set("$timezone");
		$location="$city, $country";
	}
    ?>
