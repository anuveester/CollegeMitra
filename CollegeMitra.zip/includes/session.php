<?php 

session_start();
//Print_r ($_SESSION);
if (!isset($_SESSION['id']))
{
header('location: quizbattle'); // If session starts then it is redirecting to home page
}

//starting the timeout session
$inactive = 7200; // The value of time is in sec

if (isset($_SESSION["timeout"])) // check to see if $_SESSION["timeout"] is set
{
    $sessionTTL = time() - $_SESSION["timeout"];    // calculate the session's "time to live"

    if ($sessionTTL > $inactive) 
	{
        session_destroy(); 
       // header("location: ../logout.php"); // Redirecting after destroy session to logout page
    }
}
$_SESSION["timeout"] = time();

$id =  $_SESSION['id'];
$fname =  $_SESSION['fname'];
$lname =  $_SESSION['lname'];
$uname =  $_SESSION['uname'];

$url = "http" . (($_SERVER['SERVER_PORT'] == 443) ? "s" : "") . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
//$location="fh";
$loc=mysqli_query($qconnect,"INSERT into location (ip,location,url) VALUES ('$user_ip','$location','$url')");
?>