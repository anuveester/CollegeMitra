<div class="right_act_heading">
<h4>Friends Activity</h4>
</div>

<?php 
				error_reporting(0);			 	
				include "database/db.php";
				include "includes/session.php";
//				$results = mysql_query("SELECT * FROM profile where id='$id' ");
//					while($record=mysql_fetch_array($results))
//					{
//					$college=$record['college'];
//					}
//				
						//$res = mysql_query("SELECT * FROM notes where college='$college' OR pid='1' ORDER BY time DESC LIMIT 0,5");
						$rest = mysql_query("SELECT * FROM notes ORDER BY time DESC LIMIT 0,5", $connect);
						while($recordc=mysql_fetch_array($rest))
						{
						$idm=$recordc['id'];
						$pidm=$recordc['pid'];
						$subjecta=$recordc['subject'];
				
					$resultm = mysql_query("SELECT * FROM profile where id='$pidm' ", $connect);
					while($recordx=mysql_fetch_array($resultm))
					{
					$idz=$recordx['id'];
					$fnames=$recordx['fname'];
					$lnames=$recordx['lname'];
					}
					
					$Proz = mysql_query("SELECT img FROM pro_pic where pid='$idz'", $connect);
					while($recordz=mysql_fetch_array($Proz))
					{
					$imgz=$recordz['img'];
					} 				
                    ?>        
    <div class="activity">
        <div class="activity_img">
        <a href="#"><img src="<?php echo $imgz ?>" class="activity_pics" /></a>
        </div>
        
        <div class="activity_news">
        <p><b><?php echo $subjecta ?></b> uploaded by <b><?php echo $fnames ?>&nbsp;<?php echo $lnames ?></b>.</p>
        </div>
    </div>
&nbsp;
<?php
	}
?>
