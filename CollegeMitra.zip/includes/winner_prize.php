
  
   <div class="container">
    <div class="col-lg-10  col-sm-12 col-xs-offset-1">
      <h3><u>Winner Price will be in this order:</u></h3>
      <br>
      
      <table class="col-lg-2  col-sm-12 col-xs-offset-1" style="color: green">
  <tbody>
    <tr>
      <th scope="row" style="text-align: right;">1<sup>st</sup></th>
      <td style="text-align: center;">:</td>
      <td style="text-align: right;"><i class="fa fa-rupee"></i> 100.00</td>
    </tr>
    <tr>
      <th scope="row" style="text-align: right;">2<sup>nd</sup></th>
      <td style="text-align: center;">:</td>
      <td style="text-align: right;"><i class="fa fa-rupee"></i> 70.00</td>
    </tr>
    <tr>
      <th scope="row" style="text-align: right;">3<sup>rd</sup></th>
      <td style="text-align: center;">:</td>
      <td style="text-align: right;"><i class="fa fa-rupee"></i> 50.00</td>
    </tr>
    <tr>
      <th scope="row" style="text-align: right;">-----</th>
      <td style="text-align: center;">--</td>
      <td style="text-align: right;">------------</td>
    </tr>
  </tbody>
</table>
      <table class="col-lg-2  col-sm-12 col-xs-offset-1" style="color: darkblue">
  <tbody>
    <tr>
      <th scope="row" style="text-align: right;">4<sup>th</sup></th>
      <td style="text-align: center;">:</td>
      <td style="text-align: right;"><i class="fa fa-rupee"></i> 20.00</td>
    </tr>
    <tr>
      <th scope="row" style="text-align: right;">5<sup>th</sup></th>
      <td style="text-align: center;">:</td>
      <td style="text-align: right;"><i class="fa fa-rupee"></i> 20.00</td>
    </tr>
    <tr>
      <th scope="row" style="text-align: right;">6<sup>th</sup></th>
      <td style="text-align: center;">:</td>
      <td style="text-align: right;"><i class="fa fa-rupee"></i> 20.00</td>
    </tr>
    <tr>
      <th scope="row" style="text-align: right;">7<sup>th</sup></th>
      <td style="text-align: center;">:</td>
      <td style="text-align: right;"><i class="fa fa-rupee"></i> 20.00</td>
    </tr>
    <tr>
      <th scope="row" style="text-align: right;">8<sup>th</sup></th>
      <td style="text-align: center;">:</td>
      <td style="text-align: right;"><i class="fa fa-rupee"></i> 20.00</td>
    </tr>
    <tr>
      <th scope="row" style="text-align: right;">9<sup>th</sup></th>
      <td style="text-align: center;">:</td>
      <td style="text-align: right;"><i class="fa fa-rupee"></i> 20.00</td>
    </tr>
    <tr>
      <th scope="row" style="text-align: right;">10<sup>th</sup></th>
      <td style="text-align: center;">:</td>
      <td style="text-align: right;"><i class="fa fa-rupee"></i> 20.00</td>
    </tr>
    <tr>
      <th scope="row" style="text-align: right;">-----</th>
      <td style="text-align: center;">--</td>
      <td style="text-align: right;">------------</td>
    </tr>
  </tbody>
</table>
      <table class="col-lg-2  col-sm-12 col-xs-offset-1" style="color: darkorange">
  <tbody>
    <tr>
      <th scope="row" style="text-align: right;">11<sup>th</sup></th>
      <td style="text-align: center;">:</td>
      <td style="text-align: right;"><i class="fa fa-rupee"></i> 18.00</td>
    </tr>
    <tr>
      <th scope="row" style="text-align: right;">12<sup>th</sup></th>
      <td style="text-align: center;">:</td>
      <td style="text-align: right;"><i class="fa fa-rupee"></i> 18.00</td>
    </tr>
    <tr>
      <th scope="row" style="text-align: right;">13<sup>th</sup></th>
      <td style="text-align: center;">:</td>
      <td style="text-align: right;"><i class="fa fa-rupee"></i> 18.00</td>
    </tr>
    <tr>
      <th scope="row" style="text-align: right;">14<sup>th</sup></th>
      <td style="text-align: center;">:</td>
      <td style="text-align: right;"><i class="fa fa-rupee"></i> 18.00</td>
    </tr>
    <tr>
      <th scope="row" style="text-align: right;">15<sup>th</sup></th>
      <td style="text-align: center;">:</td>
      <td style="text-align: right;"><i class="fa fa-rupee"></i> 18.00</td>
    </tr>
    <tr>
      <th scope="row" style="text-align: right;">16<sup>th</sup></th>
      <td style="text-align: center;">:</td>
      <td style="text-align: right;"><i class="fa fa-rupee"></i> 15.00</td>
    </tr>
    <tr>
      <th scope="row" style="text-align: right;">17<sup>th</sup></th>
      <td style="text-align: center;">:</td>
      <td style="text-align: right;"><i class="fa fa-rupee"></i> 15.00</td>
    </tr>
    <tr>
      <th scope="row" style="text-align: right;">18<sup>th</sup></th>
      <td style="text-align: center;">:</td>
      <td style="text-align: right;"><i class="fa fa-rupee"></i> 15.00</td>
    </tr>
    <tr>
      <th scope="row" style="text-align: right;">19<sup>th</sup></th>
      <td style="text-align: center;">:</td>
      <td style="text-align: right;"><i class="fa fa-rupee"></i> 15.00</td>
    </tr>
    <tr>
      <th scope="row" style="text-align: right;">20<sup>th</sup></th>
      <td style="text-align: center;">:</td>
      <td style="text-align: right;"><i class="fa fa-rupee"></i> 15.00</td>
    </tr>
    <tr>
      <th scope="row" style="text-align: right;">-----</th>
      <td style="text-align: center;">--</td>
      <td style="text-align: right;">------------</td>
    </tr>
  </tbody>
</table>

    </div>
  </div>