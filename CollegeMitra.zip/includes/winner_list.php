<div class="container">
	<h3><u>Check your Rank:</u></h3>
	<br>
	<div class="row">

		<table class="col-lg-4  col-md-4 col-sm-12" style="color: green">
			<tbody>
				<?php 

				$i=1;
				$candidate = mysqli_query($qconnect, "SELECT												
												t1.id as id,
												t2.name,
												t2.mob,
												t1.taken_time,
												t1.payment,
												t1.rank,
												t1.prize,
												t1.rightanswer
											from 
												quiz_score t1
												INNER JOIN quiz_reg t2
												ON t1.userid = t2.id

											WHERE t1.paperset = '$pset' AND t1.rank != '0'
											ORDER BY t1.rank ASC
											limit 0,3
										");
				while($_GET=mysqli_fetch_array($candidate)){
					$cid = $_GET['id'];
					$cname = ucwords($_GET[ 'name' ]);		
					$paid=$_GET['payment'];			
					$rank=$_GET['rank'];			
					$price=$_GET['prize'];	
					$price = number_format("$price", 2);	

					if($paid == 1){$paid=' - Paid';}else{$paid = '';}

					if($rank == 1){
						$ii = 'st';
					}elseif($rank == 2){
						$ii = 'nd';			
					}elseif($rank == 3){
						$ii = 'rd';				
					}else{
						$ii = 'th';				
					}

		   ?>
				<tr>
					<th scope="row" style="text-align: right;">
						<?php echo $i; ?>
						<sup>
							<?php echo $ii; ?>
						</sup>
					</th>
					<td style="text-align: center;">:</td>
					<td style="text-align: left;">
						<?php echo("$cname"); ?>
					</td>
					<td style="text-align: right;"><i class="fa fa-rupee"></i>
						<?php echo("$price"); ?>
					</td>
					<td style="text-align: left;">
						<?php echo("$paid"); ?>
					</td>
				</tr>
				<?php
				$i++;
				}
				?>
				<tr>
					<th scope="row" style="text-align: right;">-----</th>
					<td style="text-align: center;">--</td>
					<td style="text-align: left;">-----------</td>
					<td style="text-align: right;">------</td>
					<td style="text-align: left;"></td>
				</tr>
			</tbody>
		</table>
		<table class="col-lg-4 col-md-4  col-sm-12" style="color: darkblue">
			<tbody>
				<?php 
					$i=4;
				$candidate = mysqli_query($qconnect, "SELECT 												
												t1.id as id,
												t2.name,
												t2.mob,
												t1.taken_time,
												t1.payment,
												t1.rank,
												t1.prize,
												t1.rightanswer
											from 
												quiz_score t1
												INNER JOIN quiz_reg t2
												ON t1.userid = t2.id

											WHERE t1.paperset = '$pset' AND t1.rank != '0'
											ORDER BY t1.rank ASC
											Limit 3,7
										");
				while($_GET=mysqli_fetch_array($candidate)){
					$cid = $_GET['id'];
					$cname = ucwords($_GET[ 'name' ]);		
					$paid=$_GET['payment'];			
					$rank=$_GET['rank'];			
					$price=$_GET['prize'];	
					$price = number_format("$price", 2);	

					if($paid == 1){$paid=' - Paid';}else{$paid = '';}

					if($rank == 1){
						$ii = 'st';
					}elseif($rank == 2){
						$ii = 'nd';			
					}elseif($rank == 3){
						$ii = 'rd';				
					}else{
						$ii = 'th';				
					}	


		   ?>
				<tr>
					<th scope="row" style="text-align: right;">
						<?php echo $i; ?>
						<sup>
							<?php echo $ii; ?>
						</sup>
					</th>
					<td style="text-align: center;">:</td>
					<td style="text-align: left;">
						<?php echo("$cname"); ?>
					</td>
					<td style="text-align: right;"><i class="fa fa-rupee"></i>
						<?php echo("$price"); ?>
					</td>
					<td style="text-align: left;">
						<?php echo("$paid"); ?>
					</td>
				</tr>
				<?php
				$i++;
				}
				?>
				<tr>
					<th scope="row" style="text-align: right;">----</th>
					<td style="text-align: center;">--</td>
					<td style="text-align: left;">-----------</td>
					<td style="text-align: right;">-------</td>
					<td style="text-align: left;"></td>
				</tr>
			</tbody>
		</table>
		<div class="col-lg-1  col-sm-1"></div>
		<table class="col-lg-4 col-md-4 col-sm-12" style="color: darkorange">
			<tbody>
				<?php 
					$i=11;
				$candidate = mysqli_query($qconnect, "SELECT 												
												t1.id as id,
												t2.name,
												t2.mob,
												t1.taken_time,
												t1.payment,
												t1.rank,
												t1.prize,
												t1.rightanswer
											from 
												quiz_score t1
												INNER JOIN quiz_reg t2
												ON t1.userid = t2.id

											WHERE t1.paperset = '$pset' AND t1.rank != '0'
											ORDER BY t1.rank ASC
											Limit 10,10
										");
				while($_GET=mysqli_fetch_array($candidate)){
					$cid = $_GET['id'];
					$cname = ucwords($_GET[ 'name' ]);		
					$paid=$_GET['payment'];			
					$rank=$_GET['rank'];			
					$price=$_GET['prize'];	
					$price = number_format("$price", 2);	

					if($paid == 1){$paid=' - Paid';}else{$paid = '';}

					if($rank == 1){
						$ii = 'st';
					}elseif($rank == 2){
						$ii = 'nd';			
					}elseif($rank == 3){
						$ii = 'rd';				
					}else{
						$ii = 'th';				
					}	

		   ?>
				<tr>
					<th scope="row" style="text-align: right;">
						<?php echo $i; ?>
						<sup>
							<?php echo $ii; ?>
						</sup>
					</th>
					<td style="text-align: center;">:</td>
					<td style="text-align: left;">
						<?php echo("$cname"); ?>
					</td>
					<td style="text-align: right;"><i class="fa fa-rupee"></i>
						<?php echo("$price"); ?>
					</td>
					<td style="text-align: left;">
						<?php echo("$paid"); ?>
					</td>
				</tr>
				<?php
				$i++;
				}
				?>
				<tr>
					<th scope="row" style="text-align: right;">----</th>
					<td style="text-align: center;">--</td>
					<td style="text-align: left;">------</td>
					<td style="text-align: right;">-------</td>
					<td style="text-align: left;"></td>
				</tr>
			</tbody>
		</table>
	</div>
	<div class="row">
		<div class="col-lg-10  col-sm-12 col-xs-offset-1">
			<h2 style="text-align: center; color: red;"><a href="whatsapp://send?text=Hey I won real money in my Paytm account. %0Ayou can also, win Paytm balance like me!! %0A %0ACheck the winner list at website.  %0Avisit: http://collegemitra.com/quizbattle.php" data-action="share/whatsapp/share"><img src="./images/wta.png" width="80px" class="" alt="CollegeMitra">Tell to your friends.</a></h2>
			<h4 style="text-align: center;">To claim you prize please contact us @ <span style="color: red;">+91 9560 141 243</span></h4>
			<h4 style="text-align: center;">Hello winners, If your name in the list then update your Paytm No./Phone Pe/Google Pay, To update:  
  						<button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#myModalpics"><i class="fa fa-pencil fa-fw"></i> <span style="color:#fff;">Update</button></h4>
		</div>
	</div>
</div>