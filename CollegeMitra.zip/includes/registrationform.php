				<form class="form-horizontal col-xs-offset-1" name="form1"  id="defaultForm" method="post" action="signup" role="form"  onsubmit="return validate1();">
 					<input type="hidden" name="ip" value="<?php echo $user_ip ?>" />
 					<input type="hidden" name="currentdatetime" value="<?php echo $currentdatetime ?>" />
                   <div class="form-group"></div>
                        <div class="form-group">
                            <label for="fname" class="col-sm-2 control-label" role="navigation">Name</label>
                            <div class="col-sm-4">
                               <input type="text" class="form-control"  id="fname" name="fname" placeholder="First Name">
                            </div>
                            <div class="col-sm-4">
                               <input type="text" class="form-control"  id="lname" name="lname" placeholder="Last Name">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="email" class="col-sm-2 control-label" role="navigation">Email</label>
                            <div class="col-sm-8">
                            <input type="email" class="form-control" title="Email" name="email" data-container="body" data-toggle="popover" data-placement="top" data-content="Activation email goes same email ID which you enter, Please enter carefully"  id="email" placeholder="Enter email" autocomplete="off">
                        <span class="email_result" id="email_result"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="uname" class="col-sm-2 control-label" role="navigation">Username</label>
                            <div class="col-sm-8">
                            <input type="text" class="form-control" title="Username" name="uname" id="uname" placeholder="Enter username" autocomplete="off">
                            <span class="username_avail_result1" id="username_avail_result"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="pwd" class="col-sm-2 control-label" role="navigation">Password</label>
                            <div class="col-sm-4">
                               <input type="password" class="form-control" id="pwd" name="pwd" placeholder="Password">
                               <span class="password_strength" id="password_strength"></span>
                            </div>
                            <div class="col-sm-4">
                               <input type="password" class="form-control" id="contact-pass" name="cpwd" placeholder="Retype">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="contact-gender" class="col-sm-2 control-label" role="navigation">Gender</label>
                            <div class="col-sm-4">
                                	<label>
                               			<input type="radio" id="contact-gender" checked name="gen" value="male"> Male
                               		</label>
                               </div>
                            	<div class="col-sm-4">
                                	<label>
                               			<input type="radio" id="contact-gender" name="gen" value="female"> Female
                               		</label>
                               </div>
                        </div>
                        <div class="form-group">
                            <label for="contact-course" class="col-sm-2 control-label" role="navigation">Type</label>
                            <div class="col-sm-8">
                               <select class="form-control" id="contact-course course" name="careertype" onchange="br(this.value)">
                                    <option value="1" disabled selected>What are you?</option>                 
                                    <option value="Preparation">Preparation</option>                           
                                    <option value="Student">Student</option>                           
                                    <option value="Employee">Employee</option>                           
                                    <option value="Non Working">Non Working</option>  
                                </select>
                            </div>
					</div>
                        <div class="form-group">
                        	<div class="col-sm-8 col-sm-offset-2">
                            	<div class="checkbox">
                                	<label>
                                    <input type="checkbox" name="tnc" id="tnc"/><a href="tnc" target="_blank">I accept terms and conditions</a>
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-5 col-sm-12">
                               <button type="reset" class="form-control btn btn-info" >Reset</button>
                            </div>
                            <div class="col-md-5 col-sm-12 ">
                               <button type="submit" class="form-control btn btn-warning" name="doSubmit" id="doSubmit" >SignUp</button>
                            </div>
                        </div>
                </form>