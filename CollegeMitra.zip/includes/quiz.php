<div class="quiz">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
<!--        <h3>Connect to Start College<span style="color:#f0ad4e;">Mitra</span></h3>
-->      </div>
      <div class="col-lg-6">
        <ul class="list-inline banner-social-buttons">
			<li> 
      			<a href="./quizbattle.php" class="btn btn-danger btn-lg">
       				<i class="fa fa-lightbulb-o"></i> 
       				<span class="network-name">Enter</span>
       			</a> 
       		</li>
        </ul>
      </div>
    </div>
  </div>
  <!-- /.container --> 
  
</div>
