<?php
if (!isset($_POST['sug_submit'])) {
    die(header("Location: ./col"));
}
include( 'database/qdb.php' );
include( './includes/ip.php' );
 include('./q_session.php');
//error_reporting(0);

$today = date( "Y-m-d" );
$today_num = date( "Ymd" );
$current_time = date( "His" );
$current_day = date( "D" );
$todaytime = "$today_num$current_time";

if (isset($_POST['sug_submit'])){
	echo $sug =  $_POST['suggest'];
}

$sql=mysqli_query($qconnect, "INSERT INTO quiz_suggestion (uid,suggestion) VALUES ('$fid','$sug')");


	if($sql){ 
		 echo "<script type='text/javascript'>alert('Thankyou for your suggestion, This is very valuable to us. ')</script><script language=JavaScript> window.location.href=\"./quizbattle.php\" </script>";
		echo "<script>window.close();</script>";
	 } else{
		 echo "<script type='text/javascript'>alert('Something Wrong')</script><script language=JavaScript> window.location.href=\"./quizbattle.php\" </script>";echo "<script>window.close();</script>";
	 }

?>