<?php 
 include('database/qdb.php');
if(isset($_GET['i'])){
	$d = $_GET[ 'i' ];
	$del=mysql_query("DELETE FROM `quiz_score` WHERE `id`=$d");
}elseif(isset($_GET['s'])){
	$s = $_GET[ 's' ];
	$del=mysql_query("DELETE FROM `quiz_score` WHERE `id`=$s");
}elseif(isset($_GET['u'])){
	$u = $_GET[ 'u' ];
	$del=mysql_query("UPDATE quiz_reg set banned='1' where id='$u'");
}


$qset = mysql_query( "SELECT * FROM quiz_score ORDER BY paperset ASC" );
while ( $_GET = mysql_fetch_array( $qset ) ) {
	$pset = $_GET[ 'paperset' ];
}


$qsut = mysql_query( "SELECT sum(prize) as amt FROM quiz_score where paperset='$pset' and rank >= 1 and rank <= 20 AND payment='0'" );
while ( $_GET = mysql_fetch_array( $qsut ) ) {
	$amtt = $_GET[ 'amt' ];
	echo "Prize amount Remains: <strong>$amtt</strong>"."<br>"."<br>";
}
//$pset='3';
$i='1';
$candidate = mysql_query("SELECT 
								t1.* ,t1.id as sid , t2.*
							from 
								quiz_score t1
								INNER JOIN quiz_reg t2
								ON t1.userid = t2.id
								
							where t1.userid !='0' AND t1.exam_to = '0' AND t1.paperset='$pset'
						");
$n=mysql_num_rows($candidate);
if($n > 0){
echo "<strong>Quiz Not Completed:</strong><br>";
}
while($_GET=mysql_fetch_array($candidate)){
	$sid = $_GET['sid'];
	$cid = $_GET['userid'];
	//echo "<br>";
	
		$cname=$_GET['name'];		
		$mob=$_GET['mob'];	
	
		echo "$i: CM Quiz $cname - <a href=\"tel:$mob\">$mob</a>&nbsp;&nbsp;&nbsp;<a href=\"./tttt.php?i=$sid\">X</a>";
	    echo "<br>";
	$i++;
}

	    echo "<br>";
	    echo "<br>";
$i='1';
echo "<strong>Result:</strong><br>";
$candidate = mysql_query("SELECT 
								t1.id as id,
								t1.userid as uid,
								t2.name,
								t2.mob,
								t1.taken_time,
								t1.rightanswer
							from 
								quiz_score t1
								INNER JOIN quiz_reg t2
								ON t1.userid = t2.id
								
							WHERE t1.taken_time != '' AND userid NOT IN ('1','7','46') AND t1.paperset='$pset' AND t2.banned != '1'
							ORDER BY t1.rightanswer DESC, t1.taken_time ASC LIMIT 0,20
						");
while($_GET=mysql_fetch_array($candidate)){
	$cid = $_GET['id'];
	$uid = $_GET['uid'];
		$cname=$_GET['name'];		
		$mob=$_GET['mob'];		
		$rightanswer=$_GET['rightanswer'];
		$takentime=$_GET['taken_time'];
		echo "$i: $rightanswer-$takentime - CM Quiz $cname - <a href=\"tel:$mob\">$mob</a> - $uid $mob";
	echo "<br>";
		
		if($i == 1){
			$p=100;
		}elseif($i==2){
			$p=70;
		}elseif($i==3){
			$p=50;
		}elseif($i>=4 && $i<=10){
			$p=20;
		}elseif($i>=11 && $i<=20){
			$p=rand(12,20);
		}else{
			$p='0';
		}
	
	//$update=mysql_query("UPDATE quiz_score SET rank='$i', prize='$p', done='1' WHERE id='$cid'");
	$i++;
	
}
	echo "<br>";
	echo "<br>";

echo "<strong>Multiple Attemps</strong><br>";

		$i=1;
		$did = mysql_query("SELECT count(*) as ctn,id,ip,ip2long from quiz_score where ip!='' and paperset='$pset' group by ip having count(*) > 1");
		while($_GET=mysql_fetch_array($did)){
			$lid = $_GET['id'];
			$lip = ($_GET['ip']);
			$lips = ($_GET['ip2long']);
			$ctn = ($_GET['ctn']);
			//echo "$lip ($ctn)";
			//echo "<br>";
			
			
			$dids = mysql_query("SELECT 
										t1.*,
										t2.* ,
										t2.id as cid 
									from 
									quiz_score t1
									INNER JOIN quiz_reg t2
									ON t1.userid = t2.id
									
									where 
										t1.ip!=''  AND t2.banned != '1'
									and 
										t1.ip2long='$lips'
									order by t1.exam_from ASC
									");
			while($_GET=mysql_fetch_array($dids)){
				 $uids = $_GET['userid'];
				 $cids = $_GET['cid'];
				 $sname = $_GET['name'];
		
				echo "$i: $sname - $uids - (<a href=\"#\"><strong>$lip</strong></a>)  - <a href=\"./tttt.php?u=$cids\">X</a><br>";
				//echo "<br>";
				$i++;
			}
		}

echo "<br>";
echo "<br>";
$i='1';
echo "<strong>Quiz Taken:</strong><br>";
$candidate = mysql_query("SELECT 
								* 
							from 
								quiz_score
							where userid !='0' AND taken_time != '' AND paperset='$pset'
						");
while($_GET=mysql_fetch_array($candidate)){
	$cid = $_GET['userid'];
	$sid = $_GET['id'];
	//echo "<br>";
	
	$list = mysql_query("SELECT * FROM quiz_reg WHERE id = $cid");
	while($_GET = mysql_fetch_array($list)){
		$cname=$_GET['name'];		
		$mob=$_GET['mob'];		
	}
		echo "$i: $cname - <a href=\"tel:$mob\">$mob</a> - <a href=\"./tttt.php?s=$sid\">X</a>";
	    echo "<br>";
	$i++;
}

	    echo "<br>";
	    echo "<br>";
$i='1';
echo "<strong>Quiz not Attended:</strong><br>";
$candidate = mysql_query("SELECT 
								* 
							from 
								quiz_reg
							where id NOT IN (SELECT userid FROM quiz_score WHERE userid != '0' AND paperset='$pset')
							order by id asc
						");
while($_GET=mysql_fetch_array($candidate)){
	$cid = $_GET['id'];
		$cname=$_GET['name'];		
		$mob=$_GET['mob'];
		echo "$i: $cname - <a href=\"tel:$mob\">$mob</a>";
	echo "<br>";
	$i++;
	
}

?>