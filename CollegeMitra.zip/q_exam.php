<?php
 include('database/qdb.php');
error_reporting(0);
 include('./includes/ip.php');
 include('./q_session.php');
$today=date("Y-m-d");
$today_num=date("Ymd");
$current_time = date("H:i:s");
$current_day = date("D");
$todaytime="$today_num$current_time";

//number of  Question
$number_question = "1";
//Subject Category
$category_id = "1";
//Unknown
$id='1';
// Limit
$limit = '10';
?>
 <?php
     
    //$demo = mysqli_query($qconnect,"SELECT * FROM quiz_exam ORDER BY nextexam ASC");
    $demo = mysqli_query($qconnect,"SELECT DATE_ADD(nextexam, INTERVAL 7 DAY) as nextdate,nextexam,time,paperset FROM quiz_exam ORDER BY nextexam ASC, time ASC");
    while($_GET=mysqli_fetch_array($demo))
    {
        $nextexam=$_GET['nextexam'];
        $examtime=$_GET['time'];
         
        $nextdate=$_GET['nextdate'];
        $set=$_GET['paperset'];
    }
        $datejavascriptnt = date('M d, Y', strtotime("$nextdate"));
 
    $t = mysqli_query($qconnect,"SELECT * FROM quiz_exam where nextexam = '$today' ORDER BY id ASC,time ASC");
    $snum=mysqli_num_rows($t);
    while($_GET=mysqli_fetch_array($t))
    {
        $from=$_GET['time'];
        //$fr = date('H:i:s', strtotime("$from") );
        $to = date('H:i:s', strtotime("$from". '12 hour') );
        //$shedule_date = date('Ymd', strtotime("$nextexam")); 
    }
    $set1=$set+1;
    $eattempt = mysqli_query($qconnect,"SELECT * FROM quiz_score where userid = '$fid' AND exam_date='$today' AND paperset='$set'");
    $attempt=mysqli_num_rows($eattempt);
 
// Declare two dates and 
// initialize it
$date1 = "$nextexam";
$datejavascript = date('M d, Y', strtotime("$date1") );
$nextdate = date('M d, Y', strtotime("$date1", '+6 days') );
$date2 = "$today";
 
 
if ( $date1 > $date2) {
    ?>
    <!DOCTYPE html><!--QuestionBattle will start in:-->
    <html lang="en">
    <head>
        <head><title>QuizBattle : CollegeMitra || make them easy...</title>
    <?php include "metatag.php"; ?>
    <meta name="keywords" content="CollegeMitra.com, virtual, virtual classes, online education, books, online class, onine books, GATE, Engineering notes, class notes, online preparation,virtual learning " />
    <?php include "landingtitle.php"; ?>
    </head>
 
 
    <style>
 
    h1{
      margin: 40px 0px 20px;
      text-align: center;
    }
     #clockdiv{
        font-family: sans-serif;
        color: #fff;
        display: inline-block;
        font-weight: 100;
        text-align: center;
        font-size: 30px;
            width: 100%;
            margin: 0 auto;
            padding: 20px;
    }
    #clockdiv > div{
        padding: 10px;
        border-radius: 3px;
        background: #00BF96;
        display: inline-block;
    }
    #clockdiv div > span{
        padding: 15px;
        border-radius: 3px;
        background: #00816A;
        display: inline-block;
    }
    smalltext{
        padding-top: 5px;
        font-size: 16px;
    }
    </style>
 
    <body>
    <?php include "landingnav.php"; ?>
 
    <!--Common File which include common code to every page-->
    <?php include_once("./common.php") ?>
    <div class="content-section-a" id="section-1">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 col-sm-12 center-block">
            <h1 class="section-heading">QuestionBattle will start in: <?php echo $datejavascript ; ?></h1>
                <div id="clockdiv">
                  <div>
                    <span class="days" id="day"></span>
                    <div class="smalltext">Days</div>
                  </div>
                  <div>
                    <span class="hours" id="hour"></span>
                    <div class="smalltext">Hours</div>
                  </div>
                  <div>
                    <span class="minutes" id="minute"></span>
                    <div class="smalltext">Minutes</div>
                  </div>
                  <div>
                    <span class="seconds" id="second"></span>
                    <div class="smalltext">Seconds</div>
                  </div>
                </div>        
          </div>
        </div>
      </div>
    </div>
 

<div class="content-section-b" id="section-1">
	
    <?php include "includes/winner_prize.php"; ?>
</div>
    <!-- /.container -->
<!-- Footer -->
<?php include "includes/landingfooter.php"; ?>
 
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>   
 
 
    <!--countdown timer-->
 
        <script>
 
    var deadline = new Date("<?php echo $datejavascript ?> <?php echo $examtime ?>").getTime();
 
    var x = setInterval(function() {
 
    var now = new Date().getTime();
    var t = deadline - now;
    var days = Math.floor(t / (1000 * 60 * 60 * 24));
    var hours = Math.floor((t%(1000 * 60 * 60 * 24))/(1000 * 60 * 60));
    var minutes = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((t % (1000 * 60)) / 1000);
    document.getElementById("day").innerHTML =days ;
    document.getElementById("hour").innerHTML =hours;
    document.getElementById("minute").innerHTML = minutes; 
    document.getElementById("second").innerHTML =seconds; 
    if (t < 0) {
            clearInterval(x);
            document.getElementById("demo").innerHTML = "TIME UP";
            document.getElementById("day").innerHTML ='0';
            document.getElementById("hour").innerHTML ='0';
            document.getElementById("minute").innerHTML ='0' ; 
            document.getElementById("second").innerHTML = '0'; }
    }, 1000);
    </script>
 
            <!--Auto refresh when exam start-->
            <script>
                var target = new Date("<?php echo $datejavascript ?> <?php echo $examtime ?>");
            timeOffset = target.getTimezoneOffset() * 60000;
            targetTime = target.getTime();
            targetUTC = targetTime + timeOffset;
 
            var today = new Date();
            todayTime = today.getTime();
            todayUTC = todayTime + timeOffset;
 
            refreshTime = (targetUTC - todayUTC);
            if (refreshTime > 1) {
                setTimeout(function() { window.location.reload(true); }, refreshTime);
            }
            </script>
    </body>
    </html>
    <?php
} elseif ( $date1 == $date2 ) {
    if ( $from > $current_time ) {
        ?>
            <!DOCTYPE html><!--Be ready Exam will start in, If not started then refresh the page.-->
            <html lang="en">
            <head>
                <head><title>QuizBattle : CollegeMitra || make them easy...</title>
            <?php include "metatag.php"; ?>
            <meta name="keywords" content="CollegeMitra.com, virtual, virtual classes, online education, books, online class, onine books, GATE, Engineering notes, class notes, online preparation,virtual learning " />
            <?php include "landingtitle.php"; ?>
            </head>
 
 
            <style>
 
            h1{
              margin: 40px 0px 20px;
              text-align: center;
            }
             #clockdiv{
                font-family: sans-serif;
                color: #fff;
                display: inline-block;
                font-weight: 100;
                text-align: center;
                font-size: 30px;
                    width: 100%;
                    margin: 0 auto;
                    padding: 20px;
            }
            #clockdiv > div{
                padding: 10px;
                border-radius: 3px;
                background: #00BF96;
                display: inline-block;
            }
            #clockdiv div > span{
                padding: 15px;
                border-radius: 3px;
                background: #00816A;
                display: inline-block;
            }
            smalltext{
                padding-top: 5px;
                font-size: 16px;
            }
            </style>
 
            <body>
            <?php include "landingnav.php"; ?>
 
            <!--Common File which include common code to every page-->
            <?php include_once("./common.php") ?>
            <div class="content-section-a" id="section-1">
              <div class="container">
                <div class="row">
                  <div class="col-lg-12 col-sm-12 center-block">
                    <h1 class="section-heading">Be ready Exam will start in:</h1>
                        <div id="clockdiv">
                          <div>
                            <span class="days" id="day"></span>
                            <div class="smalltext">Days</div>
                          </div>
                          <div>
                            <span class="hours" id="hour"></span>
                            <div class="smalltext">Hours</div>
                          </div>
                          <div>
                            <span class="minutes" id="minute"></span>
                            <div class="smalltext">Minutes</div>
                          </div>
                          <div>
                            <span class="seconds" id="second"></span>
                            <div class="smalltext">Seconds</div>
                          </div>
                        </div> 
                    <h1 class="section-heading">If exam does not start automatically after time-up then refresh the page.</h1>      
                  </div>
                </div>
              </div>
            </div>
 
 
<div class="content-section-b" id="section-1">
    <?php include "includes/winner_prize.php"; ?>
</div>
            <!-- /.container -->
<!-- Footer -->
<?php include "includes/landingfooter.php"; ?>
 
            <!-- Bootstrap Core JavaScript -->
            <script src="js/bootstrap.min.js"></script>   
 
 
            <!--countdown timer-->
 
                <script>
 
            var deadline = new Date("<?php echo $datejavascript ?> <?php echo $examtime ?>").getTime();
 
            var x = setInterval(function() {
 
            var now = new Date().getTime();
            var t = deadline - now;
            var days = Math.floor(t / (1000 * 60 * 60 * 24));
            var hours = Math.floor((t%(1000 * 60 * 60 * 24))/(1000 * 60 * 60));
            var minutes = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((t % (1000 * 60)) / 1000);
            document.getElementById("day").innerHTML =days ;
            document.getElementById("hour").innerHTML =hours;
            document.getElementById("minute").innerHTML = minutes; 
            document.getElementById("second").innerHTML =seconds; 
            if (t < 0) {
                    clearInterval(x);
                    document.getElementById("demo").innerHTML = "TIME UP";
                    document.getElementById("day").innerHTML ='0';
                    document.getElementById("hour").innerHTML ='0';
                    document.getElementById("minute").innerHTML ='0' ; 
                    document.getElementById("second").innerHTML = '0'; }
            }, 1000);
                     
                var target = new Date("<?php echo $datejavascript ?> <?php echo $examtime ?>");
            timeOffset = target.getTimezoneOffset() * 60000;
            targetTime = target.getTime();
            targetUTC = targetTime + timeOffset;
 
            var today = new Date();
            todayTime = today.getTime();
            todayUTC = todayTime + timeOffset;
 
            refreshTime = (targetUTC - todayUTC);
            if (refreshTime > 1) {
                setTimeout(function() { window.location.href ='q_exam.php'; }, refreshTime);
            }
            </script>
 
            </body>
            </html>
        <?php
    }else{     
        if ( ($to < $current_time) ) {
            ?>
            <!DOCTYPE html><!--OOPS!!<br><br>TODAYS Quizbattle is over. Be on time for next Battle.-->
            <html lang="en">
                <head>
                    <head><title>QuizBattle : CollegeMitra || make them easy...</title>

                <?php include "metatag.php"; ?>
                <meta name="keywords" content="CollegeMitra.com, virtual, virtual classes, online education, books, online class, onine books, GATE, Engineering notes, class notes, online preparation,virtual learning " />
                <?php include "landingtitle.php"; ?>
                </head>
 
 
                <style>
 
                h1,h2{
                  margin: 40px 0px 20px;
                  text-align: center;
                }
                 #clockdiv{
                    font-family: sans-serif;
                    color: #fff;
                    display: inline-block;
                    font-weight: 100;
                    text-align: center;
                    font-size: 30px;
                        width: 100%;
                        margin: 0 auto;
                        padding: 20px;
                }
                #clockdiv > div{
                    padding: 10px;
                    border-radius: 3px;
                    background: #00BF96;
                    display: inline-block;
                }
                #clockdiv div > span{
                    padding: 15px;
                    border-radius: 3px;
                    background: #00816A;
                    display: inline-block;
                }
                smalltext{
                    padding-top: 5px;
                    font-size: 16px;
                }
                </style>
 
                <body>
                <?php include "landingnav.php"; ?>
 
                <!--Common File which include common code to every page-->
                <?php include_once("./common.php") ?>
                <div class="content-section-a" id="section-1">
                  <div class="container">
                    <div class="row">
                      <div class="col-lg-12 col-sm-12 center-block">
                        <h1 class="section-heading">OOPS!!<br><br>Today's Quizbattle is over. Be on time for next Quiz.</br><br> Next Exam scheduled: <span style="color: crimson"><?php echo $datejavascriptnt ; ?></span> <span style="color:green">at</span> <span style="color: crimson"><?php echo $from ; ?></span></h1>
                        <h2 style="color: orangered">-: Time left :-</h2>
                            <div id="clockdiv">
                              <div>
                                <span class="days" id="day"></span>
                                <div class="smalltext">Days</div>
                              </div>
                              <div>
                                <span class="hours" id="hour"></span>
                                <div class="smalltext">Hours</div>
                              </div>
                              <div>
                                <span class="minutes" id="minute"></span>
                                <div class="smalltext">Minutes</div>
                              </div>
                              <div>
                                <span class="seconds" id="second"></span>
                                <div class="smalltext">Seconds</div>
                              </div>
                            </div>        
                      </div>
                    </div>
                  </div>
                </div>
 
 
<div class="content-section-b" id="section-1">
    <?php include "includes/winner_prize.php"; ?>
</div>
                <!-- /.container -->
<!-- Footer -->
<?php include "includes/landingfooter.php"; ?>
 
                <!-- Bootstrap Core JavaScript -->
                <script src="js/bootstrap.min.js"></script>   
 
 
                <!--countdown timer-->
 
                    <script>
 
                var deadline = new Date("<?php echo $datejavascriptnt ?> <?php echo $examtime ?>").getTime();
 
                var x = setInterval(function() {
 
                var now = new Date().getTime();
                var t = deadline - now;
                var days = Math.floor(t / (1000 * 60 * 60 * 24));
                var hours = Math.floor((t%(1000 * 60 * 60 * 24))/(1000 * 60 * 60));
                var minutes = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((t % (1000 * 60)) / 1000);
                document.getElementById("day").innerHTML =days ;
                document.getElementById("hour").innerHTML =hours;
                document.getElementById("minute").innerHTML = minutes; 
                document.getElementById("second").innerHTML =seconds; 
                if (t < 0) {
                        clearInterval(x);
                        document.getElementById("demo").innerHTML = "TIME UP";
                        document.getElementById("day").innerHTML ='0';
                        document.getElementById("hour").innerHTML ='0';
                        document.getElementById("minute").innerHTML ='0' ; 
                        document.getElementById("second").innerHTML = '0'; }
                }, 1000);
                </script>
 
                </body>
                </html>
            <?php
        } else{
            if($attempt){
            ?>
            <!DOCTYPE html><!--You are already attended this Quiz, Please check your results.-->
            <html lang="en">
                <head>
                    <head><title>QuizBattle : CollegeMitra || make them easy...<?php echo $set ?></title>
                <?php include "metatag.php"; ?>
                <meta name="keywords" content="CollegeMitra.com, virtual, virtual classes, online education, books, online class, onine books, GATE, Engineering notes, class notes, online preparation,virtual learning " />
                <?php include "landingtitle.php"; ?>
                </head>
 
 
                <style>
 
                h1,h2{
                  margin: 40px 0px 20px;
                  text-align: center;
                }
                 #clockdiv{
                    font-family: sans-serif;
                    color: #fff;
                    display: inline-block;
                    font-weight: 100;
                    text-align: center;
                    font-size: 30px;
                        width: 100%;
                        margin: 0 auto;
                        padding: 20px;
                }
                #clockdiv > div{
                    padding: 10px;
                    border-radius: 3px;
                    background: #00BF96;
                    display: inline-block;
                }
                #clockdiv div > span{
                    padding: 15px;
                    border-radius: 3px;
                    background: #00816A;
                    display: inline-block;
                }
                smalltext{
                    padding-top: 5px;
                    font-size: 16px;
                }
                </style>
 
                <body>
                <?php include "landingnav.php"; ?>
 
                <!--Common File which include common code to every page-->
                <?php include_once("./common.php") ?>
                <div class="content-section-a" id="section-1">
                  <div class="container">
                    <div class="row">
                      <div class="col-lg-12 col-sm-12 center-block">
                        <h1 class="section-heading">OOPS!!<br><br>You are already attended this Quiz, Please check your results.</br><br> Next Exam scheduled: <span style="color: crimson"><?php echo $datejavascriptnt ; ?></span> <span style="color:green">at</span> <span style="color: crimson"><?php echo $from ; ?></span></h1>
                        <h2 style="color: orangered">-: For next Exam time left :-</h2>
                            <div id="clockdiv">
                              <div>
                                <span class="days" id="day"></span>
                                <div class="smalltext">Days</div>
                              </div>
                              <div>
                                <span class="hours" id="hour"></span>
                                <div class="smalltext">Hours</div>
                              </div>
                              <div>
                                <span class="minutes" id="minute"></span>
                                <div class="smalltext">Minutes</div>
                              </div>
                              <div>
                                <span class="seconds" id="second"></span>
                                <div class="smalltext">Seconds</div>
                              </div>
                            </div>        
                      </div>
                    </div>
                  </div>
                </div>
 
<div class="content-section-b" id="section-1">
    <?php include "includes/winner_prize.php"; ?>
</div>
                <!-- /.container -->
<!-- Footer -->
<?php include "includes/landingfooter.php"; ?>
 
                <!-- Bootstrap Core JavaScript -->
                <script src="js/bootstrap.min.js"></script>   
 
 
                <!--countdown timer-->
 
                    <script>
 
                var deadline = new Date("<?php echo $datejavascriptnt ?> <?php echo $examtime ?>").getTime();
 
                var x = setInterval(function() {
 
                var now = new Date().getTime();
                var t = deadline - now;
                var days = Math.floor(t / (1000 * 60 * 60 * 24));
                var hours = Math.floor((t%(1000 * 60 * 60 * 24))/(1000 * 60 * 60));
                var minutes = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((t % (1000 * 60)) / 1000);
                document.getElementById("day").innerHTML =days ;
                document.getElementById("hour").innerHTML =hours;
                document.getElementById("minute").innerHTML = minutes; 
                document.getElementById("second").innerHTML =seconds; 
                if (t < 0) {
                        clearInterval(x);
                        document.getElementById("demo").innerHTML = "TIME UP";
                        document.getElementById("day").innerHTML ='0';
                        document.getElementById("hour").innerHTML ='0';
                        document.getElementById("minute").innerHTML ='0' ; 
                        document.getElementById("second").innerHTML = '0'; }
                }, 1000);
                </script>
 
                </body>
                </html>  
        <?php       
            }else{
				
				$ip2long=ip2long($user_ip);
                //Inserting scorecard for result storation 
                $query = mysqli_query($qconnect,"INSERT INTO quiz_score ( userid,paperset,category_id, exam_date, exam_from,ip,ip2long)VALUES ( '$fid','$set','$category_id', '$today','$current_time','$user_ip','$ip2long')");
 
                $asked=mysqli_query($qconnect,"UPDATE quiz_exam SET asked='1' WHERE nextexam='$today'")
                ?>
                <!DOCTYPE html><!--Exam-->
                <html lang="en">
                    <head>
                        <head><title>QuizBattle : CollegeMitra || make them easy...</title>
                    <?php include "metatag.php"; ?>
                    <meta name="keywords" content="CollegeMitra.com, virtual, virtual classes, online education, books, online class, onine books, GATE, Engineering notes, class notes, online preparation,virtual learning " />
                    <?php include "landingtitle.php"; ?>
 
 
                    </head>
 
                        <script>document.addEventListener('contextmenu', event => event.preventDefault());</script>
 
                    <body onselectstart="return false">
                    <!-- Navigation -->
                        <nav class="navbar navbar-inverse navbar-fixed-top">
                            <div class="container">
                                <!-- Brand and toggle get grouped for better mobile display -->
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                    <a class="navbar-brand" href="#"><img src="img/logo.png" class="logo" alt="CollegeMitra"></a>
                                </div>
                                <!-- /.navbar-collapse -->
                            </div>
                            <!-- /.container -->
                        </nav>
 
                     <!--Quiz common-->
                      <script src="http://code.jquery.com/jquery-latest.js"></script>
                        <?php include_once("./includes/mocktestcommon.php") ?>
 
 
                    <!--Common File which include common code to every page-->
 
 
                    <script>
                    shortcut = {
                        all_shortcuts: {},
                          add: function (e, t, n) {
                            var r = {
                              type: "keydown",
                              propagate: !1,
                              disable_in_input: !1,
                              target: document,
                              keycode: !1
                            };
                            if (n) for (var i in r) "undefined" == typeof n[i] && (n[i] = r[i]);
                            else n = r;
                            r = n.target, "string" == typeof n.target && (r = document.getElementById(n.target)), e = e.toLowerCase(), i = function (r) {
                              r = r || window.event;
                              if (n.disable_in_input) {
                                var i;
                                r.target ? i = r.target : r.srcElement && (i = r.srcElement), 3 == i.nodeType && (i = i.parentNode);
                                if ("INPUT" == i.tagName || "TEXTAREA" == i.tagName) return
                              }
                              r.keyCode ? code = r.keyCode : r.which && (code = r.which), i = String.fromCharCode(code).toLowerCase(), 188 == code && (i = ","), 190 == code && (i = ".");
                              var s = e.split("+"),
                                o = 0,
                                u = {
                                  "`": "~",
                                  1: "!",
                                  2: "@",
                                  3: "#",
                                  4: "$",
                                  5: "%",
                                  6: "^",
                                  7: "&",
                                  8: "*",
                                  9: "(",
                                  0: ")",
                                  "-": "_",
                                  "=": "+",
                                  ";": ":",
                                  "'": '"',
                                  ",": "<",
                                  ".": ">",
                                  "/": "?",
                                  "\\": "|"
                                }, f = {
                                  esc: 27,
                                  escape: 27,
                                  tab: 9,
                                  space: 32,
                                  "return": 13,
                                  enter: 13,
                                  backspace: 8,
                                  scrolllock: 145,
                                  scroll_lock: 145,
                                  scroll: 145,
                                  capslock: 20,
                                  caps_lock: 20,
                                  caps: 20,
                                  numlock: 144,
                                  num_lock: 144,
                                  num: 144,
                                  pause: 19,
                                  "break": 19,
                                  insert: 45,
                                  home: 36,
                                  "delete": 46,
                                  end: 35,
                                  pageup: 33,
                                  page_up: 33,
                                  pu: 33,
                                  pagedown: 34,
                                  page_down: 34,
                                  pd: 34,
                                  left: 37,
                                  up: 38,
                                  right: 39,
                                  down: 40,
                                  f1: 112,
                                  f2: 113,
                                  f3: 114,
                                  f4: 115,
                                  f5: 116,
                                  f6: 117,
                                  f7: 118,
                                  f8: 119,
                                  f9: 120,
                                  f10: 121,
                                  f11: 122,
                                  f12: 123
                                }, l = !1,
                                c = !1,
                                h = !1,
                                p = !1,
                                d = !1,
                                v = !1,
                                m = !1,
                                y = !1;
                              r.ctrlKey && (p = !0), r.shiftKey && (c = !0), r.altKey && (v = !0), r.metaKey && (y = !0);
                              for (var b = 0; k = s[b], b < s.length; b++) "ctrl" == k || "control" == k ? (o++, h = !0) : "shift" == k ? (o++, l = !0) : "alt" == k ? (o++, d = !0) : "meta" == k ? (o++, m = !0) : 1 < k.length ? f[k] == code && o++ : n.keycode ? n.keycode == code && o++ : i == k ? o++ : u[i] && r.shiftKey && (i = u[i], i == k && o++);
                              if (o == s.length && p == h && c == l && v == d && y == m && (t(r), !n.propagate)) return r.cancelBubble = !0, r.returnValue = !1, r.stopPropagation && (r.stopPropagation(), r.preventDefault()), !1
                            }, this.all_shortcuts[e] = {
                              callback: i,
                              target: r,
                              event: n.type
                            }, r.addEventListener ? r.addEventListener(n.type, i, !1) : r.attachEvent ? r.attachEvent("on" + n.type, i) : r["on" + n.type] = i
                          },
                          remove: function (e) {
                            var e = e.toLowerCase(),
                              t = this.all_shortcuts[e];
                            delete this.all_shortcuts[e];
                            if (t) {
                              var e = t.event,
                                n = t.target,
                                t = t.callback;
                              n.detachEvent ? n.detachEvent("on" + e, t) : n.removeEventListener ? n.removeEventListener(e, t, !1) : n["on" + e] = !1
                            }
 
                          }
                        },
                         shortcut.add("Ctrl+U",function (){
                         //alert('Sorry\nNo CTRL+U is allowed. Be creative!')
                        }),
                         shortcut.add("Meta+Alt+U",function(){
                         //alert('Sorry\nNo Command+Option+U is allowed. Be creative!')
                        }),
                        shortcut.add("Ctrl+C",function(){
                         //alert('Sorry\nNever duplicate th`enter code here`is article...')
                        }),
                        shortcut.add("Meta+C",function(){
                         //alert('Sorry\nNever duplicate this article...')
                        });
                        shortcut.add("f12",function(){
                         //alert('Sorry\nNever Sorry this is not allowed')
                        });
                        shortcut.add("Ctrl+P",function(){
                         //alert('Sorry\nNever Sorry this is not allowed')
                        });
                        shortcut.add("Meta+P",function(){
                         //alert('Sorry\nNever Sorry this is not allowed')
                        });
 
 
                    </script>
 
                        <!-- Record of Ip Adress -->
 
                    <?php include 'includes/analyticstracking.php';
 
 
                    ?>
 
 
                        <!-- Fb Button roots-->
                        <div id="fb-root"></div>
                        <script>
                        (function(d, s, id) {
                          var js, fjs = d.getElementsByTagName(s)[0];
                          if (d.getElementById(id)) return;
                          js = d.createElement(s); js.id = id;
                          js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.0";
                          fjs.parentNode.insertBefore(js, fjs);
                        }(document, 'script', 'facebook-jssdk'));
                        </script>
 
 
                    <!-- Redirect to another page (for no-js support) (place it in your <head>) -->
                    <noscript><meta http-equiv="refresh" content="1 ;url=http://www.collegemitra.com/javaalert"></noscript> 
 
 
                    <div class="content-section-a" id="section-1">
                      <div class="container">
                        <div class="row">
                          <div class="col-lg-10  col-sm-12 col-xs-offset-1">
 
                            <div class="col-md-9 col-sm-8">
 
                               <!--Edit Feed-->
                               <div class="row"><!-- /row -->
 
                                   <div class="col-sm-12 col-md-12">
                                        <h2>You are attending <strong class="text-info">QuizBattle</strong>, SET-<?php echo $set ?>
                                        <small class="pull-right">
                                            <span id='timer'></span>
                                            <i class="fa fa-clock-o fa-2x text-third"></i>
                                        </small>
                                        </h2>
                                        <br>
                                        <hr>
 
                                        <div class="row" >
                                            <div class="col-sm-12">
                                            <form class="form-horizontal" role="form" id='quiz_form' method="post" action="quiz_result.php">
                                                <?php
                                                    //echo "$number_question";
 
                                                    $i = 0;
                                                    $j = 1;
                                                    $k = 1;                        
 
                                                    $row = mysqli_query($qconnect,"SELECT * from quiz_exam where paperset='$set' ORDER BY RAND() limit 0,$limit");
                                                    $rowcount = mysqli_num_rows( $row );
                                                    $remainder = $rowcount/$number_question;
                                                    while ( $result = mysql_fetch_assoc($row) ) {
                                                        $results['questions'][] = $result;     
                                                        $time=$result['timer'];
                                                        $timer= 1200; //in seconds         
                                                    }
 
                                                    foreach ($results['questions'] as $result) {
                                                        $qid=$result['id'];
                                                        $qhold = mysql_query("INSERT INTO quiz_holder ( qid,userid,paperset)VALUES ( '$qid',$fid,$set)");
                                                        if ( $i == 0) echo "<div class='cont' id='question_splitter_$j'>";?>
 
                                                        <div id='question<?php echo $k;?>' >
                                                        <strong><p class='questions' id="qname<?php echo $j;?>"> <span class="text-info"><?php echo $k?></span>.&nbsp;<?php echo $result['question_name'];?></p></strong>
 
                                                        <ul style="list-style:none">
                                                        <li>
                                                        <input type="radio" value="1" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>  <?php echo $result['answer1'];?>
                                                        </li>
                                                        <li>
                                                        <input type="radio" value="2" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>  <?php echo $result['answer2'];?>
                                                        </li>
                                                        <li>
 
                                                        <?php if(isset( $result['answer3'] ) && !empty( $result['answer3'] )){ ?>
                                                        <input type="radio" value="3" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>  <?php echo $result['answer3'];?>
                                                        <?php } ?>
                                                        </li>
                                                        <li>
 
                                                        <?php if(isset( $result['answer4'] ) && !empty( $result['answer4'] )){ ?>
                                                        <input type="radio" value="4" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>  <?php echo $result['answer4'];?>
                                                        <?php } ?>
                                                        </li>
                                                        <li>
 
                                                        <?php if(isset( $result['answer5'] ) && !empty( $result['answer5'] )){ ?>
                                                        <input type="radio" value="5" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>  <?php echo $result['answer5'];?>
                                                        <?php } ?>
                                                        </li>
                                                        <li>
 
                                                        <?php if(isset( $result['answer6'] ) && !empty( $result['answer6'] )){ ?>
                                                        <input type="radio" value="6" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>  <?php echo $result['answer6'];?>
                                                        <?php } ?>
                                                        </li>
                                                        </ul>                                
 
                                                        <input type="radio" checked='checked' style='display:none' value="smart_quiz" id='radio1_<?php echo $result['id'];?>' name='<?php echo $result['id'];?>'/>
                                                        <hr>
                                                        </div>
 
                                                        <?php
                                                             $i++;
                                                             if ( ( $remainder < 1 ) || ( $i == $number_question && $remainder == 1 ) ) {
                                                                echo "<button id='".$j."' class='next btn btn-success' type='submit'>Finish</button>";
                                                                echo "</div>";
                                                             }  elseif ( $rowcount > $number_question  ) {
                                                                if ( $j == 1 && $i == $number_question ) {
                                                                    echo "<button id='".$j."' class='next btn btn-success' type='button'>Next</button>";
                                                                    echo "</div>";
                                                                    $i = 0;
                                                                    $j++;          
                                                                } elseif ( $k == $rowcount ) {
                                                                    echo " <button id='".$j."' class='previous btn btn-success' type='button'>Previous</button>
                                                                    <button id='".$j."' class='next btn btn-success' type='submit'>Finish</button>";
                                                                    echo "</div>";
                                                                    $i = 0;
                                                                    $j++;
                                                                } elseif ( $j > 1 && $i == $number_question ) {
                                                                    echo "<button id='".$j."' class='previous btn btn-success' type='button'>Previous</button>
                                                                    <button id='".$j."' class='next btn btn-success' type='button' >Next</button>";
                                                                    echo "</div>";
                                                                    $i = 0;
                                                                    $j++;
                                                                }
 
                                                             }
                                                              $k++;
                                                         } ?>   
                                              </form>
                                        </div>
 
                                        </div>
 
                                   </div>
 
                                </div> <!-- /.row -->
                                <!--edit feed Finished-->
 
                              </div>  
 
                          </div>
                        </div>
                      </div>
                    </div>
 
 
 
<div class="content-section-b" id="section-1">
    <?php include "includes/winner_prize.php"; ?>
</div>
                    <!-- /.container -->
                    <!-- Footer -->
 
                        <footer>
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <p class="copyright text-muted small">Copyright &copy; CollegeMitra 2012-<?php echo date('Y'); ?>. All Rights Reserved</p>
                                    </div>
                                </div>
                            </div>
                        </footer>
 
                    <!-- Login Popup -->
 
                    <!-- jQuery Version 1.11.0 -->
                    <script src="js/jquery-1.11.0.js"></script>
 
                    <!-- Bootstrap Core JavaScript -->
                    <script src="js/bootstrap.min.js"></script>
                    <script>$(function ()
                          { $("[data-toggle='popover']").popover();
                          });
                       </script>
 
                       <!--Timer-->
                        <script>
                            $('.cont').addClass('hide');
                            $('#question_splitter_1').removeClass('hide');
                            $(document).on('click','.next',function(){
                                last=parseInt($(this).attr('id'));  console.log( last );  
                                nex=last+1;
                                $('#question_splitter_'+last).addClass('hide');
 
                                $('#question_splitter_'+nex).removeClass('hide');
                            });
 
                            $(document).on('click','.previous',function(){
                                last=parseInt($(this).attr('id'));    
                                pre=last-1;
                                $('#question_splitter_'+last).addClass('hide');
 
                                $('#question_splitter_'+pre).removeClass('hide');
                            });
 
                            var c = <?php echo $timer ?>;
                            var t;
                            timedCount();
 
                            function timedCount() {
 
                                var hours = parseInt( c / 3600 ) % 24;
                                var minutes = parseInt( c / 60 ) % 60;
                                var seconds = c % 60;
 
                                var result = (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds  < 10 ? "0" + seconds : seconds);
 
                                $('#timer').html(result);
                                if(c == 0 ){
                                    setConfirmUnload(false);
                                    $("#quiz_form").submit();
                                }
                                c = c - 1;
                                t = setTimeout(function(){ timedCount() }, 1000);
                            }
                        </script>
 
                        <script type="text/javascript">
 
                            // Prevent accidental navigation away
                            setConfirmUnload(true);
                            function setConfirmUnload(on)
                            {
                                window.onbeforeunload = on ? unloadMessage : null;
                            }
                            function unloadMessage()
                            {
                                return 'Your Answered Questions are resetted zero, Please select stay on page to continue your Quiz';
                            }
 
                            $(document).on('click', 'button:submit',function(){
                                setConfirmUnload(false);
                            });
 
                        </script>
 
 
                    </body>
                    </html>
                <?php           
            }
        }
    }
} else {
?>
    <!DOCTYPE html><!--Sorry!!<br><br>No more Exam Sheduled.</br><br> Last Exam Held on:-->
    <html lang="en">
            <head>
                <head><title>QuizBattle : CollegeMitra || make them easy...</title>
            <?php include "metatag.php"; ?>
            <meta name="keywords" content="CollegeMitra.com, virtual, virtual classes, online education, books, online class, onine books, GATE, Engineering notes, class notes, online preparation,virtual learning " />
            <?php include "landingtitle.php"; ?>
            </head>
 
 
            <style>
 
            h1,h2{
              margin: 40px 0px 20px;
              text-align: center;
            }
            </style>
 
            <body>
            <?php include "landingnav.php"; ?>
 
            <!--Common File which include common code to every page-->
            <?php include_once("./common.php") ?>
            <div class="content-section-a" id="section-1">
              <div class="container">
                <div class="row">
                  <div class="col-lg-12 col-sm-12 center-block">
                    <?php
                        $qcount = mysqli_query($qconnect,"SELECT * FROM quiz_exam where asked != '0'");
                        $snum=mysqli_num_rows($qcount);
         
                        $nexams = date('M d, Y', strtotime('next saturday'));
         
                        if($snum){
                            ?>
                            <h1 class="section-heading">
                                Sorry!!<br><br>
                                This week Quiz Postpond to next week.</br><br>
                                Last Exam Held on: <span style="color: crimson"><?php echo $datejavascript ; ?></span> <span style="color:green">at</span> <span style="color: crimson"><?php echo $examtime ; ?> </span></br></br>
                                We will update you soon stay in touch!!
                            </h1>
				
                            <?php
                        }else{
                            ?>
                            <h1 class="section-heading">
                                Sorry!!<br><br>
                                Not yet Started.</br><br>
                                First examination will be conduct on <span style="color: crimson"><?php echo $nexams ; ?></span>.</br><br>                               
                                We will update you soon stay in touch!!
                            </h1>
                            <?php                       
                        }
                    ?>     
                  </div>
                </div>
              </div>
            </div>
             
<div class="content-section-b" id="section-1">
    <?php include "includes/winner_prize.php"; ?>
</div>
 
            <!-- /.container -->
<!-- Footer -->
<?php include "includes/landingfooter.php"; ?>
 
            <!-- Bootstrap Core JavaScript -->
            <script src="js/bootstrap.min.js"></script>   
 
 
 
            </body>
            </html>
<?php
}
?>