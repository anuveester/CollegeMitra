<!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <h4 class="modal-title" id="myModalLabel">Sign In</h4>
          </div>
          <div class="modal-body">
            <div id="signin"> 
            	<form action="col" method="post" name="login_form"   onsubmit="return validate();">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Email adress / Username</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" name="login_email" placeholder="Enter email / username">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputEmail1">Password</label>
                        <input type="password" class="form-control" id="exampleInputEmail1" name="login_password" placeholder="Enter password">
                      </div>
                    <div class="clearfix">
                        <label for="ipassword"><span><input tabindex="5" name="login_submit" class="btn btn-warning large" type="submit" value="Sign into your account"></span></label>
                    </div>
                </form>
        	</div>
          </div>
          <div class="modal-footer">
          <span class="pull-left"><i class="fa fa-question-circle"></i><a href="forgtpwd" class="">forget password</a></span>
          <span class=" col-xs-offset-2">Don't have an account <a href="#">sign up here</a></span>
         </div>
        </div>
      </div>
    </div> 
    
    