<?php
 include('database/qdb.php');
if (isset($_POST['qenter']) || isset($_POST['qenter1'])){ 

 	$email = mysqli_real_escape_string($qconnect,$_POST['qemail']); 
	
	if(empty($email)){
		$email = mysqli_real_escape_string($qconnect,$_POST['qemail1']);
	}

	//$user = "SELECT * FROM users WHERE  and ";

	$user=mysqli_query($qconnect,"SELECT * FROM quiz_reg WHERE (email='".$email."')")or die (mysql_error());//query sang database 

	$count=mysqli_num_rows($user);

	$query = mysqli_fetch_array ($user);
		
	//$pics=$query['pics'];
	
	if($count > 0){session_start();//para mag start ang session

			$fid = $_SESSION['id']=$query['id'];//kwaon ang id sang may tyakto nga username kag password ang ibotang sa 
			$name = $_SESSION['name']=$query['name'];	
	
		//fetching data of candidates and getting the records for information 
		$pquery=mysqli_query($qconnect,"SELECT * FROM quiz_reg WHERE email='$email' AND (pics = '' OR paytm='0' OR phonepe='0' OR googlepay='0')");
		$cdecide = mysqli_num_rows($pquery);	
				   
		if($cdecide == 0){
			header("location: test.php");
		}else{
			header("location: q_update.php");
		}
		
	}else{
		
		$message=  "<script language=javascript> 

        alert(\"This Email Id is not registered with us. Please create an Account.\");</script>

		<script language=JavaScript> window.location.href =\"quizbattle.php\" </script>";
	}
	
	echo "$message";
	
}
?>