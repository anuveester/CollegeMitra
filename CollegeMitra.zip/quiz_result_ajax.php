<?php
//require_once 'config.php';
require_once( 'database/qdb.php' );

    if($_POST['act'] == 'rate'){
    	//search if the user(ip) has already gave a note
    	//$ip = $_SERVER["REMOTE_ADDR"];
    	$therate = $_POST['rate'];
    	$thepost = $_POST['post_id'];

    	$query = mysqli_query($qconnect,"SELECT * FROM rate where id= '$thepost'  "); 
    	while($data = mysqli_fetch_assoc($query)){
    		$rate_db[] = $data;
    	}

    	if(@count($rate_db) == 0 ){
    		mysqli_query($qconnect,"INSERT INTO rate (id_post, rate)VALUES('$thepost', '$therate')");
    	}else{
    		mysqli_query($qconnect,"UPDATE rate SET rate= '$therate' WHERE id = '$thepost'");
    	}
    } 
?>