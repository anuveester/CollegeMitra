<?php
 include('database/db.php');
 include('./includes/ip.php');
$today=date("Y-m-d");
$today_num=date("Ymd");
$current_time = date("His"); 
$current_day = date("D"); 
$todaytime="$today_num$current_time"; 
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <head><title>Virtual Class : CollegeMitra || make them easy...</title>
<?php include "metatag.php"; ?>
<meta name="keywords" content="CollegeMitra.com, virtual, virtual classes, online education, books, online class, onine books, GATE, Engineering notes, class notes, online preparation,virtual learning " />
<?php include "landingtitle.php"; ?>
</head><body>
<?php include "landingnav.php"; ?>

<!--Common File which include common code to every page-->
<?php include_once("./common.php") ?>
<div class="content-section-b" id="section-1">
  <div class="container">
    <div class="row">
      <div class="col-lg-10  col-sm-12 col-xs-offset-1">
        <h2 class="section-heading">What is Virtual Classes ?</h2>
        <p class="lead text-justify"> These Virtual classes are web-based and both tutors and students can easily interact with each other
          at the comfort of your home. Just as in actual classes where teacher makes interaction and discuss
          various questions, topics, held debates with their students. Through virtual classes, we can naively
          interact with any person, regarding study sessions, around the world. And we can naively portrait
          assuredness level and skills just as, communication skills, listening skills and writing skills. Gradually
          these Virtual classes are spreading all around the world just because of the growing technology. And
          it does not only make progress in technology but also makes improvements in one particular’s life.
          Just as we need either guider or counsellor to show us a way to take your next step with utmost
          care to become successful in future, similarly, <span style="color:#f0ad4e;"><em><strong>CollegeMitra</strong></em></span> is providing these virtual classes as your
          guider where a team of expert and skilled tutors would be functioning to provide you with apt
          knowledge. And will help you out in enhancements of your communicating skills, listening skills, and
          writing skills. And <span style="color:#f0ad4e;"><em><strong>CollegeMitra</strong></em></span> will bestow chances, through making virtual classes, to portrait
          connections with the people around the world and share such thoughts and opinions.</p>
          
        
      </div>
    </div>
  </div>
</div>


<!-- /.Registration -->
<div class="content-section-a">
      <div class="container">
        </div><div class="container">
			<div class="row">
				
				<div class="col-lg-6 col-sm-6">
					<div class="fb-like" data-href="https://www.facebook.com/collegemitra/" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>
					<div class=" panel panel-info">
						<div class="panel-heading"><i class="fa fa-pencil-square-o"></i> Let's goto QuizBattle (If Already Registered)</div>
							<form class="form-horizontal col-xs-offset-1" name="form1"  id="defaultForm" method="post" action="signup" role="form"  onsubmit="return validate1();">
							   <div class="form-group"></div>
                        <div class="form-group">
                            <label for="email" class="col-sm-2 control-label" role="navigation">Email</label>
                            <div class="col-sm-8">
                            <input type="email" class="form-control" title="Email" name="email" data-container="body" data-toggle="popover" data-placement="top" data-content="Activation email goes same email ID which you enter, Please enter carefully"  id="email" placeholder="Enter email" autocomplete="off">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-5 col-sm-12">
                               <button type="reset" class="form-control btn btn-info" >Reset</button>
                            </div>
                            <div class="col-md-5 col-sm-12 ">
                               <button type="submit" class="form-control btn btn-success" name="doSubmit" id="doSubmit" >Take Quiz</button>
                            </div>
                        </div>
                			</form>
					</div>
				</div>
				<div class="col-lg-6 col-sm-6">
					<div class="fb-like" data-href="https://www.facebook.com/collegemitra/" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>
					<div class=" panel panel-info">
						<div class="panel-heading"><i class="fa fa-pencil-square-o"></i> Create an account for take Quiz (Only for Quiz)</div>
							<form class="form-horizontal col-xs-offset-1" name="form1"  id="defaultForm" method="post" action="signup" role="form"  onsubmit="return validate1();">
								<input type="hidden" name="ip" value="<?php echo $user_ip ?>" />
								<input type="hidden" name="currentdatetime" value="<?php echo $currentdatetime ?>" />
							   <div class="form-group"></div>
									<div class="form-group">
										<label for="fname" class="col-sm-2 control-label" role="navigation">Name</label>
										<div class="col-sm-4">
										   <input type="text" class="form-control"  id="fname" name="fname" placeholder="First Name">
										</div>
										<div class="col-sm-4">
										   <input type="text" class="form-control"  id="lname" name="lname" placeholder="Last Name">
										</div>
									</div>
									<div class="form-group">
										<label for="email" class="col-sm-2 control-label" role="navigation">Email</label>
										<div class="col-sm-8">
										<input type="email" class="form-control" title="Email" name="email" data-container="body" data-toggle="popover" data-placement="top" data-content="Activation email goes same email ID which you enter, Please enter carefully"  id="email" placeholder="Enter email" autocomplete="off">
									<span class="username_avail_result3" id="username_avail_result3"></span>
										</div>
									</div>
									<div class="form-group">
										<label for="email" class="col-sm-2 control-label" role="navigation">Mobile</label>
										<div class="col-sm-8">
                        					<input type="text" class="form-control"  id="wmob" name="wmob" placeholder=" contact number" autocomplete="off"  maxlength="10">
										</div>
									</div>
									<div class="form-group">
										<label for="contact-gender" class="col-sm-2 control-label" role="navigation">Gender</label>
										<div class="col-sm-4">
												<label>
													<input type="radio" id="contact-gender" checked name="gen" value="male"> Male
												</label>
										   </div>
											<div class="col-sm-4">
												<label>
													<input type="radio" id="contact-gender" name="gen" value="female"> Female
												</label>
										   </div>
									</div>
									<div class="form-group">
										<div class="col-sm-8 col-sm-offset-2">
											<div class="checkbox">
												<label>
												<input type="checkbox" name="tnc" id="tnc"/><a href="tnc" target="_blank">I accept terms and conditions</a>
												</label>
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="col-md-5 col-sm-12">
										   <button type="reset" class="form-control btn btn-info" >Reset</button>
										</div>
										<div class="col-md-5 col-sm-12 ">
										   <button type="submit" class="form-control btn btn-danger" name="doSubmit" id="doSubmit" >SignUp</button>
										</div>
									</div>
							</form>
					</div>
				</div>
			</div>
	  </div>
  </div>
    </div>

<div class="content-section-b" id="section-1">
  <div class="container"> <br>
    <div class="col-lg-10  col-sm-12 col-xs-offset-1">
      <h4>Importance of virtual classes</h4>
      <p class="lead text-justify"> As we all know the momentousness of technology in our daily lives. These technologies are not only
        restricted to communication, farming or transportation but also in the spheres of education.
        We all have come across that the manner of teaching has been altered perfectly as compared to
        20th century. Nowadays, everything happening around the world is easily updated on internet.
        In India, government provides books in all the government schools. And presently, due to
        advancement in technology, books, notes, and other important study materials and stuffs are
        available on internet. Through technology, any student or person can naively transform their
        thoughts or words into pictures. </p>
      <p class="lead text-justify"> So wait no more and get your hands on this opportunity since we all know “In the middle of every
        difficulty lies opportunity”. Experience classroom from the comfort of your home at <span style="color:#f0ad4e;"><em><strong>CollegeMitra</strong></em></span> and you are all ready to flaunt your skills to your colleagues. </p>
    </div>
  </div>
</div>

<!-- /.container --> 
<!-- Footer -->
<?php include "includes/landingfooter.php"; ?>

<!-- Login Popup -->
<?php include "landingsigninpopup.php"; ?>

<!-- jQuery Version 1.11.0 --> 
<script src="js/jquery-1.11.0.js"></script> 

<!-- Bootstrap Core JavaScript --> 
<script src="js/bootstrap.min.js"></script> 
<script>$(function () 
      { $("[data-toggle='popover']").popover();
      });
   </script>
</body>
</html>
