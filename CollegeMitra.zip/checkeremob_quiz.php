<?php
include 'database/qdb.php'; // include the library for database connection
if(isset($_POST['action']) && $_POST['action'] == 'username_availability'){ // Check for the username posted
	$mob 		= htmlentities($_POST['mob']); // Get the username values
	$check_query	= mysqli_query($qconnect,'SELECT mob FROM quiz_reg WHERE mob = "'.$mob.'" '); // Check the database
	echo mysqli_num_rows($check_query); // echo the num or rows 0 or greater than 0
}
?>