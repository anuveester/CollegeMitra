
<?php 
if (!isset($_POST['doSubmit'])) {
    die(header("Location: col"));
}
 
 include('database/qdb.php');
 include "./includes/ip.php";
   
 if (isset($_POST['doSubmit']))
  
    $fname =  mysqli_real_escape_string($qconnect,$_POST['fname']);
    $fname = ucfirst(strtolower($fname));
    $lname = mysqli_real_escape_string($qconnect,$_POST['lname']);
    $lname = ucfirst(strtolower($lname));
	$name="$fname $lname";
    $gen = $_POST['gen'];
    $email = $_POST['email'];
    $careertype = $_POST['careertype'];
    $mob = $_POST['mob'];
    $tnc = $_POST['disclaimer'];


    $webmaster = 'quiz_battle@collegemitra.com'; //this is optional
    $firm = 'Anuveester College Mitra Solutions Pvt. Ltd.';
    $emailsubject= 'Welcome to CollegeMitra.';
    $rName='CollegeMitra';
    $hash = md5( rand(0,1000) ); // Generate random 32 character hash and assign it to a local variable.
	$currentdatetime=date('Y-m-d H:i:s');
     
	$ip2long=ip2long($user_ip);
    $query = mysqli_query ($qconnect,"INSERT INTO quiz_reg (career,name,email,mob,gen,tnc,date,hash,ip,longip,location) VALUES ('$careertype','$name','$email','$mob','$gen','$tnc','$currentdatetime','$hash','$user_ip','$ip2long','$location')");
     
    $body = 
<<<EOF
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    </head>
     
    <body>
    <p>Dear <span style="color:#060"><b>$name</b></span>,</p>
     
    <p>
        Student life is considered as one of the happiest period in life for he has to be up and doing in the acquisition of knowledge in the formation of his character and in making contact with the world around him. Nowadays students are pretty demanding when it comes to seize teacher&#39;s PowerPoints, lecture notes and other hand written notes. Since we understand the importance of notes in student&#39;s life, <span style="color:#f0ad4e;"><em><strong>CollegeMitra</strong></em></span> headed forward with a new and innovative strategy. <br><br> <span style="color:#f0ad4e;"><em><strong>CollegeMitra</strong></em></span>- As the very name suggests that this platform is the best companion for college students helping them to take every step with utmost care. <span style="color:#f0ad4e;"><em><strong>CollegeMitra</strong></em></span> comprises of those users who have the ability to take in information and make it one&#39;s own by processing it, restructuring it and then presenting it in a form so that it could be easily understood by students.  Now we know what you probably might be thinking- how these notes could come handy to you?&nbsp;Well, you always might be peeping into your friend&#39;s notebook to pen down some important points but that doesn&#39;t sound easy right? Here at <span style="color:#f0ad4e;"><em><strong>CollegeMitra</strong></em></span> you can get your hands on the hand written notes provided by your classmates and batch mates and access them easily to the fullest.
    </p>
    <p>
      Please check your details below: </p>
    <p>---------------------------------------------------------<br>
    <span style="color:#820003">Email ID:&nbsp;</span><span style="color:#090">$email</span><br />
    <span style="color:#820003"> Mobile Number:</span>&nbsp;<span style="color:#090">$mob</span><br />
    ---------------------------------------------------------</p>
    <p>Please click this link for Quiz Battle <b>"http://www.collegemitra.com/quizbattle<br/></p>
    <p>Your given details are highly valuable to us &amp; keeping them secretly is our responsibility, for any queries please feel free to  contact us at <a href="mailto:info@collegemitra.com" target="_blank">info@collegemitra.com</a>.</p>
    <p>
    Reflecting our long-standing commitment to learning &amp;  continuous improvement, we welcome your feedback as we continue to improve this  site with gravity stage.</p>
    <p>
    We will be glad you to hear from you.</p>
    <p>
    You can visit this link <a href="www.collegemitra.com">www.collegemitra.com</a></p>
    <p>
      Sincerely,<br>
      Anuj Pratap (Founder)<br>
    Team $firm</p>
    </body>
    </html>    
EOF;
 
  
 if ($query == 1){
     
//Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html\r\n"; 
$headers .= "From: ". $rName . " <" . $webmaster . ">\r\n";
$headers .= "Return-Path: $webmaster\r\n";
$headers .= "X-Mailer: PHP \r\n";
$headers .= "Bcc: quiz_battle@collegemitra.com" . "\r\n";
 
$success = mail($email, $emailsubject, $body, $headers); // this is the main line which will send the mail above mentioned
//$success = mail($webmaster, $emailsubject, $body, $headers);
      
     header ("location: quizbattle");
 }
 else {
     echo 'Cannot Proceed due to some Technical problem';
 }
  
?>