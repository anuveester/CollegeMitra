<?php
//error_reporting(0);
include( 'database/qdb.php' );
include( './includes/ip.php' );
$today = date( "Y-m-d" );
$today_num = date( "Ymd" );
$current_time = date( "His" );
$current_day = date( "D" );
$todaytime = "$today_num$current_time";
 
$url = "http" . (($_SERVER['SERVER_PORT'] == 443) ? "s" : "") . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
 
//location input
//$loc=mysqli_query($qconnect, "INSERT into location (ip,location,url) VALUES ('$user_ip','$location','$url')");
 
 
$qset = mysqli_query($qconnect, "SELECT * FROM quiz_score ORDER BY paperset ASC" );
while ( $_GET = mysqli_fetch_array( $qset ) ) {
    $psets = $_GET[ 'paperset' ];
}
 
if ( $psets == '1' ) {
    $p = $set = $psets;
 
    $qset1 = mysqli_query($qconnect, "SELECT * FROM quiz_score WHERE paperset='$set' ORDER BY paperset ASC" );
    while ( $_GET = mysqli_fetch_array( $qset1 ) ) {
        $pdate = $cdate = $_GET[ 'exam_date' ];
    }
} else {
    $set = $psets;
    $p = $psets - 1;
 
    $qset1 = mysqli_query($qconnect, "SELECT * FROM quiz_score WHERE paperset='$set' ORDER BY paperset ASC" );
    while ( $_GET = mysqli_fetch_array( $qset1 ) ) {
        $cdate = $_GET[ 'exam_date' ];
    }
 
    $qset2 = mysqli_query($qconnect, "SELECT * FROM quiz_score WHERE paperset='$p' ORDER BY paperset ASC" );
    while ( $_GET = mysqli_fetch_array( $qset2 ) ) {
        $pdate = $_GET[ 'exam_date' ];
    }
 
}
 
$resultdate = date( 'Y-m-d', strtotime( "$cdate +2 day" ) ); //after 2 days of exam
 
if ( $resultdate >= $today ) {
    $resultdate = $pdate;
    $pset = $p;
    //echo "<br>";
} else {
    $resultdate = $cdate;
    $pset = $set;
}
$edate = date( 'l jS \of F Y', strtotime( "$resultdate" ) );
//$pset='2';
?>
<!DOCTYPE html>
<html lang="en">
 
<head>
 
    <head>
        <title>QuizBattle : CollegeMitra || make them easy...</title>
        <?php include "metatag.php"; ?>
        <meta name="keywords" content="CollegeMitra.com, virtual, virtual classes, online education, books, online class, onine books, GATE, Engineering notes, class notes, online preparation,virtual learning "/>
        <?php include "landingtitle.php"; ?>
    </head>
 
    <body>
        <?php include "landingnav.php"; ?>
        <style>
            .prize1 {
                margin-top: 10px;
                padding-top: 10px;
            }
             
            .prize2 {
                margin-top: 10px;
                padding-top: 38px;
            }
             
            .prize3 {
                margin-top: 10px;
                padding-top: 38px;
            }
             
            .prize1 img {
                width: auto;
                height: 300px;
            }
             
            .prize2 img {
                width: auto;
                height: 300px;
            }
             
            .prize3 img {
                width: auto;
                height: 300px;
            }
             
            .w1{
                width: auto;
                height: 150px;             
            }
             
            .w2{
                width: auto;
                height: 130px;
                margin-top: 22px;              
            }
             
            .w3{
                width: auto;
                height: 130px;
                margin-top: 22px;              
            }
             
        </style>
 
        <!--Common File which include common code to every page-->
        <?php include_once("./common.php") ?>
        <div class="content-section-b" id="section-1">
            <div class="container"><br>
 
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12 text-center">
                        <h1><strong>!! Winners of Quizbattle-<?php echo $pset ?>!!</strong></h1>
                        <h2><strong> Quiz taken Date: <em><span class="text-danger"><?php echo $edate ?></span></em> </strong></h2><br>
                    </div>
                    <?php
 
                    $q1 = mysqli_query($qconnect, "SELECT
                                      
                                t1.id as id,
                                t2.name,
                                t1.rank,
                                t2.pics
                                            from
                                                quiz_score t1
                                                INNER JOIN quiz_reg t2
                                                ON t1.userid = t2.id
 
                                 
                            WHERE t1.paperset = '$pset' AND t1.rank = '2'" );
                    while ( $_GET = mysqli_fetch_array( $q1 ) ) {
                        $cname = ucwords( $_GET[ 'name' ] );
                        $pics = $_GET[ 'pics' ];
                        if ( empty( $pics ) ) {
                            //$pics='./images/na.png';
 
                            $pics = "<a href='' data-toggle=\"modal\" data-target=\"#myModalpics\"><img src=\"./images/na.png\" class=\"\" alt=\"CollegeMitra\"></a>";
                        } else {
                            $pics = "<img src=\"$pics\" class=\"\" alt=\"CollegeMitra\">";
                        }
                    }
                    ?>
                    <div class=" col-lg-4 col-md-4 col-sm-4 text-center text-warning">
                        <p class=""><img src="./images/2.png" class="w2" alt="CollegeMitra"> </p>
                        <h4>2<sup>nd</sup> Prize</h4>
                        <h3><?php echo "$cname"; ?></h3>
                        <div class="prize2"><?php echo "$pics";?></div>
                    </div>
                    <?php
 
                    $q1 = mysqli_query($qconnect, "SELECT
                                t1.id as id,
                                t2.name,
                                t1.rank,
                                t2.pics
                            from
                                quiz_score t1
                                INNER JOIN quiz_reg t2
                                ON t1.userid = t2.id                               
                                 
                            WHERE t1.paperset = '$pset' AND t1.rank = '1'" );
                    while ( $_GET = mysqli_fetch_array( $q1 ) ) {
                        $cname = ucwords( $_GET[ 'name' ] );
                        $pics = $_GET[ 'pics' ];
 
                        if ( empty( $pics ) ) {
                            $pics = "<a href='' data-toggle=\"modal\" data-target=\"#myModalpics\"><img src=\"./images/na.png\" class=\"\" alt=\"CollegeMitra\"></a>";
                        } else {
                            $pics = "<img src=\"$pics\" class=\"\" alt=\"CollegeMitra\">";
                        }
                    }
                    ?>
                    <div class="col-lg-4 col-md-4 col-sm-4 text-center text-success">
                        <div class="">
                        <p class=""><img src="./images/1.png" class="w1" alt="CollegeMitra"> </p>
                        <h4>1<sup>st</sup> Prize</h4>
                        <h3><?php echo "$cname"; ?></h3>
                        <div class="prize2"><?php echo "$pics";?></div>
                        </div>
                    </div>
                    <?php
 
                    $q1 = mysqli_query($qconnect, "SELECT
                                t1.id as id,
                                t2.name,
                                t1.rank,
                                t2.pics
                            from
                                quiz_score t1
                                INNER JOIN quiz_reg t2
                                ON t1.userid = t2.id
                                 
                            WHERE t1.paperset = '$pset' AND t1.rank = '3'" );
                    while ( $_GET = mysqli_fetch_array( $q1 ) ) {
                        $cname = ucwords( $_GET[ 'name' ] );
                        $pics = $_GET[ 'pics' ];
                        if ( empty( $pics ) ) {
                            $pics = "<a href='' data-toggle=\"modal\" data-target=\"#myModalpics\"><img src=\"./images/na.png\" class=\"\" alt=\"CollegeMitra\"></a>";
                        } else {
                            $pics = "<img src=\"$pics\" class=\"\" alt=\"CollegeMitra\">";
                        }
                    }
                    ?>
                    <div class="col-lg-4 col-md-4 col-sm-4 text-center text-danger">
                        <p class=""><img src="./images/3.png" class="w3" alt="CollegeMitra"> </p>
                        <h4>3<sup>rd</sup> Prize</h4>
                        <h3><?php echo "$cname"; ?></h3>
                        <div class="prize3"><?php echo "$pics";?></div>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12 text-center">
                        <h3><strong> For further details <a href="https://www.facebook.com/collegemitra" target="_blank">click here</a> </strong></h3>
                        <?php
                        $picup = mysqli_query($qconnect, "SELECT
                                                        *
                                            from
                                                quiz_score t1
                                                INNER JOIN quiz_reg t2
                                                ON t1.userid = t2.id
 
                                            WHERE t1.paperset = '$pset' AND t1.userid != '1' AND t1.userid != '7' AND `rank` BETWEEN 1 AND 3 AND t2.pics = ''" );
                        $picy = mysqli_num_rows( $picup );
 
                        if ( $picy > 0 ) {
                            ?>
                        <h4><strong> If you are in Top 3 and not uploaded your Photo then click here:
                        <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#myModalpics"><i class="fa fa-cloud-upload fa-fw"></i> <span style="color:#fff;">Upload</button> </strong></h4>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
 
        <!-- Modal Photo Login -->
        <div class="modal fade" id="myModalpics" role="dialog">
            <div class="modal-dialog">
 
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Update</h4>
                    </div>
                    <div class="modal-body">
            <div id="signin">
                            <form class="form-horizontal col-lg-offset-1 col-xs-offset-1" name="form1" id="defaultForm" method="post" action="./q_login.php" role="form" onsubmit="return sign1();">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Registered Email ID</label>
                                        <input type="email" class="form-control" title="Email" name="qemail1" id="qemail1" placeholder="Enter email" value="" autocomplete="off">
                      </div>
                    <div class="clearfix">
                        <label for="ipassword"><span><input tabindex="5" name="qenter" class="btn btn-warning large" type="submit" value="Sign into your account"></span></label>
                    </div>
                </form>
            </div>
 
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
 
            </div>
        </div>
 
 
        <!-- /.Registration -->
        <div class="content-section-a" id="section-1">
            <div class="container">
                <h2 style="text-align: center; color: darkblue;">QuizBattle Schedule</h2>
                <h3 style="text-align: center;">Every <span style="color:orangered">Saturday</span> Starts from <span style="color: red"><u>10:00 AM</span></u>  to  <span style="color: red"><u>10:00 PM</u></span></h3>
                <!--<h3 style="text-align: center;"><img src="images/point.png" width="50px" height="auto" alt="cm"> You are NEXT, login now <img src="images/point.png" width="50px" height="auto" alt="cm"></h3>-->
                <hr>
                <div class="row">
                    <div class="col-lg-10  col-sm-12 col-xs-offset-1">
                    <iframe width="100%" height="550" src="https://www.youtube.com/embed/Rma31FhIgBo" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
                <hr>
                <div class="row">
 
                    <div class="col-lg-5 col-sm-5 col-lg-offset-1">
                        <div class="fb-like" data-href="https://www.facebook.com/collegemitra/" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>
                        <div class=" panel panel-info">
                            <div class="panel-heading"><i class="fa fa-pencil-square-o"></i> Let's enter QuizBattle (If Already Registered)</div>
                            <form class="form-horizontal col-lg-offset-1 col-xs-offset-1" name="form1" id="defaultForm" method="post" action="q_login.php" role="form" onsubmit="return sign();">
                                <div class="form-group"></div>
                                <div class="form-group">
                                    <label for="email" class="col-sm-2 control-label" role="navigation">Email</label>
                                    <div class="col-sm-8 col-xs-11">
                                        <input type="email" class="form-control" title="Email" name="qemail" data-container="body" data-toggle="popover" data-placement="top" data-content="If not register then register first." id="qemail" placeholder="Enter email" value="" autocomplete="off">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-5 col-sm-5 col-xs-6 col-xs-offset-5">
                                        <button type="submit" class="form-control btn btn-success" name="qenter" id="qenter">Take Quiz</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-5 col-sm-5">
                        <div class="fb-like" data-href="https://www.facebook.com/collegemitra/" data-layout="button_count" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>
                        <div class=" panel panel-info">
                            <div class="panel-heading"><i class="fa fa-pencil-square-o"></i> Create an account for take Quiz (Only for Quiz)</div>
 
                            <form class="form-horizontal col-xs-offset-1" name="form1" id="defaultForm" method="post" action="quizb_signup.php" role="form" onsubmit="return quizreg();">
                                <input type="hidden" name="ip" value="<?php echo $user_ip ?>"/>
                                <input type="hidden" name="currentdatetime" value="<?php echo $currentdatetime ?>"/>
                                <div class="form-group"></div>
                                <div class="form-group">
                                    <label for="fname" class="col-sm-2 control-label" role="navigation">Name</label>
                                    <div class="col-sm-4 col-xs-11">
                                        <input type="text" class="form-control" id="fname" name="fname" placeholder="First Name" value="">
                                    </div>
                                    <div class="col-sm-4 col-xs-11">
                                        <input type="text" class="form-control" id="lname" name="lname" placeholder="Last Name">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="email" class="col-sm-2 control-label" role="navigation">Email</label>
                                    <div class="col-sm-8 col-xs-11">
                                        <input type="email" class="form-control" title="Email" name="email" data-container="body" data-toggle="popover" data-placement="top" data-content="Activation email goes same email ID which you enter, Please enter carefully" value="" id="email" placeholder="Enter email" autocomplete="off">
                                        <span class="email_result" id="email_result"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="email" class="col-sm-2 control-label" role="navigation">Mobile</label>
                                    <div class="col-sm-8 col-xs-11">
                                        <input type="text" class="form-control" id="mob" name="mob" placeholder=" contact number" value="" maxlength="10" autocomplete="off" onkeypress="return isNumbers(event)">
                                        <span class="mob_result" id="mob_result"></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="contact-gender" class="col-sm-2 control-label" role="navigation">Gender</label>
                                    <div class="col-sm-3">
                                        <label>
                                                <input type="radio" id="contact-gender" checked name="gen" value="male"> Male
 
 
                                            </label>
                                     
 
                                    </div>
                                    <div class="col-sm-3">
                                        <label>
                                                <input type="radio" id="contact-gender" name="gen" value="female"> Female
                                            </label>
                                     
 
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="contact-course" class="col-sm-2 control-label" role="navigation">Type</label>
                                    <div class="col-sm-8 col-xs-11">
                                        <select class="form-control" id="careertype" name="careertype">
                                            <option value="1" disabled selected>What are you?</option>
                                            <option value="Student">Student</option>
                                            <option value="Preparation">Preparation</option>
                                            <option value="Employee">Employee</option>
                                            <option value="Non Working">Non Working</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-8 col-sm-offset-2">
                                        <div class="checkbox">
                                            <label>
                                                <input type="checkbox" value="1" name="disclaimer" id="disclaimer"/><a href="tnc" target="_blank">I accept terms and conditions</a>
                                                </label>
                                         
 
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-5 col-sm-5 col-xs-6 col-xs-offset-5">
                                        <button type="submit" class="form-control btn btn-danger" name="doSubmit" id="doSubmit">Register</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.Registration -->
        <div class="content-section-b" id="section-1">
            <?php include "includes/winner_list.php"; ?>
        </div>
        <!-- /.Registration -->
        <div class="content-section-a" id="section-1">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10  col-sm-12 col-xs-offset-1">
                        <h2 class="section-heading">Quiz Instructions -</h2>
                        <ol>
                            <li>Make sure you have a good internet connection.<br><br>
                            </li>
                            <li>Shut down all Instant Messaging tools (Skype, AIM, MSN Messenger) and Email programs as they can conflict in between your test.<br><br>
                            </li>
                            <li>Please don't click the “Back” button on the browser. This will take you out of the test and you may not able to start the same test again.<br><br>
                            </li>
                            <li>There are <strong>Only 10 questions</strong>.<br><br>
                            </li>
                            <li>You will have max 20 minutes to complete your test.<br><br>
                            </li>
                            <li>You can attempt the test only once if you want to take more quiz then you have to wait for next exam.<br><br>
                            </li>
                            <li>If by chance, you are not able to complete your test, your test will be submitted automatically and you cannot take the same test again.<br><br>
                            </li>
                            <li>You need to login through your email ID, fill in your credentials if you are a registered user or create a new account to start the test.<br><br>
                            </li>
                        </ol>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-10  col-sm-12 col-xs-offset-1">
                        <h2 class="section-heading">Benefits -</h2>
                        <ol>
                            <li>On the basis of your quiz test score and minimum duration.</li><br><br>
                            <li>If your rank will vary between 1 ~ 20 then your will sure get the Paytm Balance/Phone Pe/Google Pay.<br><br>
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
 
        <div class="content-section-b" id="section-1">
            <?php include "includes/winner_prize.php"; ?>
        </div>
 
        <!-- /.container -->
        <!-- Footer -->
        <?php include "includes/landingfooter.php"; ?>
 
        <!-- Login Popup -->
        <?php include "landingsigninpopup.php"; ?>
 
        <!-- jQuery Version 1.11.0 -->
        <script src="js/jquery-1.11.0.js"></script>
 
        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>
        <script>
            $( function () {
                $( "[data-toggle='popover']" ).popover();
            } );
        </script>
 
 
        <!--Quiz Registration-->
        <script>
                 
            function quizreg() {
 
                $( '#mob' ).on( 'input', function ( event ) {
                    this.value = this.value.replace( /[^0-9]/g, '' );
                } );
 
                if ( document.getElementById( 'fname' ).value == "" ) {
                    alert( "Please Enter your First Name" );
                    document.getElementById( 'fname' ).focus();
                    return false;
                }
 
                if ( document.getElementById( 'email' ).value == "" ) {
                    alert( "Please Enter your Email ID." );
                    document.getElementById( 'email' ).focus();
                    return false;
                }
 
 
                if ( document.getElementById( 'mob' ).value == "" ) {
                    alert( "Please Enter Mobile Number.\n" )
                    document.getElementById( 'mob' ).focus();
                    return false;
                }
 
 
                if ( document.getElementById( 'careertype' ).value == "1" ) {
                    alert( "Please Select your Career type.\n" )
                    document.getElementById( 'careertype' ).focus();
                    return false;
                }
 
                if ( document.getElementById( 'disclaimer' ).checked ) {
                    var i = confirm( "Are you sure ? \n\n" );
 
                    if ( i ) {
                        return true;
                    } else {
                        return false;
                    }
 
                    return true;
                } else {
                    alert( 'Please Read Terms & Conditions.' );
                    return false;
                }
            }
        </script>
        <script>
             
            /*Numerial numbers allowed*/
            function isNumbers(evt) {
            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
                 
            function sign() {
 
 
                if ( document.getElementById( 'qemail' ).value == "" ) {
                    alert( "Please Enter your Email ID." );
                    document.getElementById( 'qemail' ).focus();
                    return false;
                }
            }
            function sign1() {
 
 
                if ( document.getElementById( 'qemail1' ).value == "" ) {
                    alert( "Please Enter your Email ID." );
                    document.getElementById( 'qemail1' ).focus();
                    return false;
                }
            }
        </script>
 
     </body>
 
</html>