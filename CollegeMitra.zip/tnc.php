<!DOCTYPE html>
<html lang="en">

<head>
    <head><title>Terms & Condition : CollegeMitra || make them easy...</title>
    <?php include "metatag.php"; ?>

    <?php include "landingtitle.php"; ?>
</head>

<body>

    <?php include "landingnav.php"; ?>
    
    <!--Common File which include common code to every page-->    
	<?php include_once("./common.php") ?>
    
    <!-- Page Content -->

    <div class="content-section-a">

        <div class="container">

            <div class="row">
                    <hr class="section-heading-spacer">
                    <div class="clearfix"></div>
                    <h1 class="section-heading">Terms <span class=" text-primary">& </span> Conditions</h1>
                    <small>Last modified: August 26, 2014</small><br>

                    <article>
                        <p class="lead text-justify">Welcome to our <a href="col" target="_blank">www.CollegeMitra.com</a>. If you continue to browse and use this website, you are agreeing to comply with and be bound by the following terms and conditions of use, which together with our privacy policy govern <a href="col" target="_blank">Collegemitra's</a> relationship with you in relation to this website. If you disagree with any part of these terms and conditions, please do not use our website.</p>
                        <p class="lead text-justify">The term 'Anuveester College Mitra Solutions Pvt Ltd.' or 'us' or 'we' refers to the owner of the website (<a href="col" target="_blank">www.collegemitra.com</a>) whose registered office is [1145/1E, Sangam Vihar, New Delhi - 110062, Delhi, India]. Our company registration number is 246491 registered in New Delhi. The term 'you' refers to the user or viewer of our website.</p>
                        <p class="lead text-justify">PLEASE READ THIS AGREEMENT CAREFULLY. By submitting your application and by your use of the Service, you agree to comply with all of the terms and conditions set out in this Agreement. <a href="col" target="_blank">Collegemitra's</a> may terminate your account at any time, with or without notice, for conduct that is in breach of this Agreement, for conduct that <a href="col" target="_blank">Collegemitra's</a> believes is harmful to its business, or for conduct where the use of the Service is harmful to any other party.</p>

<p class="lead text-justify"><a href="col" target="_blank">CollegeMitra</a> may, in its sole discretion, change or modify this Agreement at any time, with or without notice. Such changes or modifications shall be made effective for all Subscribers or Users upon posting of the modified Agreement to this web address (URL): <a href="tnc" target="_blank">http://www.collegemitra.com/terms-and-conditions/</a>. You are responsible to read this document from time to time to ensure that your use of the Service remains in compliance with this Agreement.</p>
                        <p class="lead text-justify">The use of this website is subject to the following terms of use:</p>
                        <ol><li><p class="lead text-justify">The content of the pages of this website is for your general information and use only. It is subject to change without notice.</p></li>
                            <li><p class="lead text-justify">Neither we nor any third parties provide any warranty or guarantee as to the accuracy, timeliness, performance, completeness or suitability of the information and materials found or offered on this website for any particular purpose. You acknowledge that such information and materials may contain inaccuracies or errors and we expressly exclude liability for any such inaccuracies or errors to the fullest extent permitted by law.</p></li>
                            <li><p class="lead text-justify">Your use of any information or materials on this website is entirely at your own risk, for which we shall not be liable. It shall be your own responsibility to ensure that any products, services or information available through this website meet your specific requirements.</p></li>
                            <li><p class="lead text-justify">This website contains material which is owned by or licensed to us. This material includes, but is not limited to, the design, layout, look, appearance and graphics. Reproduction is prohibited other than in accordance with the copyright notice, which forms part of these terms and conditions.</p></li>
                            <li><p class="lead text-justify">All trade marks reproduced in this website which are not the property of, or licensed to, the operator are acknowledged on the website.</p></li>
                            <li><p class="lead text-justify">Unauthorised use of this website may give rise to a claim for damages and/or be a criminal offence.</p></li>
                            <li><p class="lead text-justify">From time to time this website may also include links to other websites. These links are provided for your convenience to provide further information. They do not signify that we endorse the website(s). We have no responsibility for the content of the linked website(s).</p></li>
                            <li><p class="lead text-justify">Your use of this website and any dispute arising out of such use of the website is subject to the laws of India.</p></li>
                        </ol>
                    </article>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.content-section-b -->
    
    <div class="content-section-b">

        <div class="container">

            <div class="row">
            <hr class="section-heading-spacer">
            	<div class="clearfix"></div>
                    <h1 class="section-heading">Privacy <span class=" text-primary">Policy</span></h1>

					<article>
                        <div class="content clearfix">
                                        <h3>CollegeMitra privacy policy </h3>
                                        <p class="lead text-justify">This privacy policy sets out how <a href="col" target="_blank">Collegemitra</a> uses and protects any information that you give <a href="col" target="_blank">Collegemitra</a> when you use this website.</p>
                                        <p class="lead text-justify"><a href="col" target="_blank">Collegemitra</a> is committed to ensuring that your privacy is protected. Should we ask you to provide certain information by which you can be identified when using this website, then you can be assured that it will only be used in accordance with this privacy statement.</p>
                                        <p class="lead text-justify"><a href="col" target="_blank">Collegemitra</a> may change this policy from time to time by updating this page. You should check this page from time to time to ensure that you are happy with any changes. This policy is effective from August 26, 2014.</p>
                                        <h3>What we collect</h3>
                                        <p class="lead text-justify">We may collect the following information:</p>
                                        <ol><li>
                                                <p class"lead">name and job title</p>
                                            </li>
                                            <li>
                                                <p class"lead">contact information including email address</p>
                                            </li>
                                            <li>
                                                <p class"lead">demographic information such as postcode, preferences and interests</p>
                                            </li>
                                            <li>
                                                <p class"lead">other information relevant to users surveys and/or offers</p>
                                            </li>
                                        </ol><h3>What we do with the information we gather</h3>
                                        <p class="lead text-justify">We require this information to understand your needs and provide you with a better service, and in particular for the following reasons:</p>
                                        <ol><li>
                                                <p class"lead">Internal record keeping.</p>
                                            </li>
                                            <li>
                                                <p class"lead">We may use the information to improve our products and services.</p>
                                            </li>
                                            <li>
                                                <p class"lead">We may periodically send promotional emails about new products, special offers or other information which we think you may find interesting using the email address which you have provided.</p>
                                            </li>
                                            <li>
                                                <p class"lead">From time to time, we may also use your information to contact you for market research purposes. We may contact you by email, phone, fax or mail. We may use the information to customise the website according to your interests.</p>
                                            </li>
                                        </ol><h3>Security</h3>
                                        <p class="lead text-justify">We are committed to ensuring that your information is secure. In order to prevent unauthorised access or disclosure, we have put in place suitable physical, electronic and managerial procedures to safeguard and secure the information we collect online.</p>
                                        <h3>How we use cookies</h3>
                                        <p class="lead text-justify">A cookie is a small file which asks permission to be placed on your computer's hard drive. Once you agree, the file is added and the cookie helps analyse web traffic or lets you know when you visit a particular site. Cookies allow web applications to respond to you as an individual. The web application can tailor its operations to your needs, likes and dislikes by gathering and remembering information about your preferences.</p>
                                        <p class="lead text-justify">We use traffic log cookies to identify which pages are being used. This helps us analyse data about webpage traffic and improve our website in order to tailor it to customer needs. We only use this information for statistical analysis purposes and then the data is removed from the system.</p>
                                        <p class="lead text-justify">Overall, cookies help us provide you with a better website by enabling us to monitor which pages you find useful and which you do not. A cookie in no way gives us access to your computer or any information about you, other than the data you choose to share with us.</p>
                                        <p class="lead text-justify">You can choose to accept or decline cookies. Most web browsers automatically accept cookies, but you can usually modify your browser setting to decline cookies if you prefer. This may prevent you from taking full advantage of the website.</p>
                                        <h3>Links to other websites</h3>
                                        <p class="lead text-justify">Our website may contain links to other websites of interest. However, once you have used these links to leave our site, you should note that we do not have any control over that other website. Therefore, we cannot be responsible for the protection and privacy of any information which you provide whilst visiting such sites and such sites are not governed by this privacy statement. You should exercise caution and look at the privacy statement applicable to the website in question.</p>
                                        <h3>Controlling your personal information</h3>
                                        <p class="lead text-justify">You may choose to restrict the collection or use of your personal information in the following ways:</p>
                                        <ol><li>
                                                <p class"lead">whenever you are asked to fill in a form on the website, look for the box that you can click to indicate that you do not want the information to be used by anybody for direct marketing purposes</p>
                                            </li>
                                            <li>
                                                <p class"lead">if you have previously agreed to us using your personal information for direct marketing purposes, you may change your mind at any time by writing to or emailing us at [email address]</p>
                                            </li>
                                        </ol>
                                        <p class="lead text-justify">We will not sell, distribute or lease your personal information to third parties unless we have your permission or are required by law to do so. We may use your personal information to send you promotional information about third parties which we think you may find interesting if you tell us that you wish this to happen.</p>
                                        <p class="lead text-justify">You may request details of personal information which we hold about you under the Data Protection Act 1998. A small fee will be payable. If you would like a copy of the information held on you please write to [address].</p>
                                        <p class="lead text-justify">If you believe that any information we are holding on you is incorrect or incomplete, please write to or email us as soon as possible at the above address. We will promptly correct any information found to be incorrect.</p>
                        </div>
					</article>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.content-section-b -->
    
     <div class="content-section-a">
        <div class="container">
            <div class="row">
            <hr class="section-heading-spacer">
            	<div class="clearfix"></div>
                <h1 class="section-heading">Copyright <span class=" text-primary">notice</span></h1>
                <article>
                	<p class="lead text-justify">This website and its content is copyright of Anuveester College Mitra Solutions P L - © CollegeMitra 2014. All rights reserved.</p>
                    <p class="lead text-justify">Any redistribution or reproduction of part or all of the contents in any form is prohibited other than the following:</p>
                    <ul><li>
                    		<p class"lead">you may print or download to a local hard disk extracts for your personal and non-commercial use only</p>
                        </li>
                        <li>
                        	<p class"lead">you may copy the content to individual third parties for their personal use, but only if you acknowledge the website as the source of the material</p>
                        </li>
                    </ul>
                    <p class="lead text-justify">You may not, except with our express written permission, distribute or commercially exploit the content. Nor may you transmit it or store it in any other website or other form of electronic retrieval system.</p>
                    <p class="lead text-justify">Copyright and other relevant intellectual property rights exists on all text relating to the Company’s services and the full content of this website. </p>
                    <p class="lead text-justify">This Company’s logo is a registered trademark of this Company in India and other countries. The brand names and specific services of this Company featured on this web site are trade marked.</p> 
                </article>
            </div>
        </div>
        <!-- /.container -->
    </div>
    <!-- /.content-section-a -->
    
    <div class="content-section-b">
        <div class="container">
            <div class="row">
            <hr class="section-heading-spacer">
            	<div class="clearfix"></div>
                <h1 class="section-heading">Website <span class=" text-primary">disclaimer</span></h1>
                    <article>
                        <p class="lead text-justify">The information contained in this website is for general information purposes only. The information is provided by <a href="col" target="_blank">Collegemitra</a> and while we endeavour to keep the information up to date and correct, we make no representations or warranties of any kind, express or implied, about the completeness, accuracy, reliability, suitability or availability with respect to the website or the information, products, services, or related graphics contained on the website for any purpose. Any reliance you place on such information is therefore strictly at your own risk.</p>
                        <p class="lead text-justify">In no event will we be liable for any loss or damage including without limitation, indirect or consequential loss or damage, or any loss or damage whatsoever arising from loss of data or profits arising out of, or in connection with, the use of this website.</p>
                        <p class="lead text-justify">Through this website you are able to link to other websites which are not under the control of [business name]. We have no control over the nature, content and availability of those sites. The inclusion of any links does not necessarily imply a recommendation or endorse the views expressed within them.</p>
                        <p class="lead text-justify">Every effort is made to keep the website up and running smoothly. However, <a href="col" target="_blank">Collegemitra</a> takes no responsibility for, and will not be liable for, the website being temporarily unavailable due to technical issues beyond our control.</p>      
                    </article>
                    
            </div>
        </div>
        <!-- /.container -->
    </div>
    <!-- /.content-section-b -->      <!-- /.content-section-a -->
    
    <div class="content-section-b">
        <div class="container">
            <div class="row">
            <hr class="section-heading-spacer">
            	<div class="clearfix"></div>
                <h1 class="section-heading">Content <span class=" text-primary">disclaimer</span></h1>
                    <article>  
                        
                        <p class="lead text-justify">Neither <a href="http://www.collegemitra.com" title="collegeMitra" target="_blank">www.collegemitra.com</a> nor the authors warrant or assume any legal liability or responsibility for the accuracy, completeness, or usefulness of any information, product, simulation or any other process described, in the web based and video based lectures.</p>
           <p class="lead text-justify">It is the responsibility of the user to evaluate the accuracy, completeness and usefulness of any services or products. In no event shall the <a href="http://www.collegemitra.com" title="collegeMitra" target="_blank">Collegemitra.com</a> be liable for any cost or direct, indirect, incidental or consequential damages arising out of or in connection with the use of, or inability to use this website.</p>
           <p class="lead text-justify">Some courses may provide links ot study materials of other institutions, and <a href="http://www.collegemitra.com" title="collegeMitra" target="_blank">Collegemitra.com</a> do not guarantee the existance however.</p>
           <p class="lead text-justify">Some texts in some material may  found to be copied from a copyrighted source. <a href="http://www.collegemitra.com" title="collegeMitra" target="_blank">Collegemitra.com</a> donot take any liability for such issues. These notes are specially formatted to help students in exams.</p>
           <p class="lead text-justify">All notes are collected from the users and owners of the notes with prior notification of the purpose. No claims will be considered.</p> 
                    </article>
                    
            </div>
        </div>
        <!-- /.container -->
    </div>
    <!-- /.content-section-b -->    
  

    <!-- /.banner -->
    <?php include "includes/landingbanner.php"; ?>

    <!-- Footer -->
    <?php include "includes/landingfooter.php"; ?>
        
    <!-- Login Popup -->
    <?php include "landingsigninpopup.php"; ?>
    

    <!-- jQuery Version 1.11.0 -->
    <script src="js/jquery-1.11.0.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script> 

</body>

</html>
