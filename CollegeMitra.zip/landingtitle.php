   
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-responsive.min.css" rel="stylesheet">
    
    <!-- google Gsuite -->
    <meta name="google-site-verification" content="AxUSZ0tyNzOaBnRIxoL-hD7KpjlKDg0bfuaSp5iX3Kg" />

    <!-- Custom CSS -->
    <link href="css/landing-page.css" rel="stylesheet">

    <!-- Custom Fonts -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/v4-shims.css">
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
    
    <!--Custom Js -->
    <script type="text/javascript" src="js/bootstrapValidator.js"></script>
	<script type="text/javascript" src="js/popup.js"></script>
	<script type="text/javascript" src="js/autosearch.js"></script>
  <script defer src="https://use.fontawesome.com/releases/v5.12.0/js/all.js"></script>
  <script defer src="https://use.fontawesome.com/releases/v5.12.0/js/v4-shims.js"></script>
    
	<script type="text/javascript">
    $(document).ready(function(){
        $(".scroll-area").scrollspy({target: "#myNavbar"}) 
    });
    </script>